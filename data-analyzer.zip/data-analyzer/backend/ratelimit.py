"""Minimal per-IP sliding-window rate limiter.

In-process only, like the dataset store — behind a reverse proxy or multiple
workers you want nginx / slowapi / an API gateway instead. It exists so the
anonymous endpoints (scrape, upload, visualize) can't be used as a free proxy
or a CPU faucet in the default single-process deployment.
"""
import threading
import time
from collections import defaultdict, deque

from fastapi import HTTPException, Request

from config import (
    RATE_LIMIT_ENABLED,
    RATE_LIMIT_LIGHT,
    RATE_LIMIT_SCRAPE,
    RATE_LIMIT_UPLOAD,
    RATE_LIMIT_VISUALIZE,
    RATE_LIMIT_WINDOW_SECONDS,
)

_lock = threading.Lock()
_hits: dict[str, deque] = defaultdict(deque)


def _client_ip(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def _check(key: str, limit: int) -> None:
    if not RATE_LIMIT_ENABLED:
        return
    now = time.time()
    cutoff = now - RATE_LIMIT_WINDOW_SECONDS
    with _lock:
        bucket = _hits[key]
        while bucket and bucket[0] < cutoff:
            bucket.popleft()
        if len(bucket) >= limit:
            retry_after = int(bucket[0] + RATE_LIMIT_WINDOW_SECONDS - now) + 1
            raise HTTPException(
                429,
                f"Too many requests. Try again in {retry_after}s.",
                headers={"Retry-After": str(retry_after)},
            )
        bucket.append(now)
        if len(_hits) > 10_000:  # bound the map itself
            for stale_key in [k for k, v in _hits.items() if not v]:
                del _hits[stale_key]


def scrape(request: Request) -> None:
    """Dependency for /api/scrape. Its own bucket — chart tinkering must
    never be able to exhaust a URL paste's quota again."""
    _check(f"scrape:{_client_ip(request)}", RATE_LIMIT_SCRAPE)


def upload(request: Request) -> None:
    """Dependency for /api/upload."""
    _check(f"upload:{_client_ip(request)}", RATE_LIMIT_UPLOAD)


def visualize(request: Request) -> None:
    """Dependency for /api/visualize. Higher limit — live preview fires this
    on every option change, several times a minute during normal use."""
    _check(f"visualize:{_client_ip(request)}", RATE_LIMIT_VISUALIZE)


def light(request: Request) -> None:
    """Dependency for analyze / rows / export."""
    _check(f"light:{_client_ip(request)}", RATE_LIMIT_LIGHT)
