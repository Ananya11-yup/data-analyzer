import re

import numpy as np
import pandas as pd

from config import ANALYSIS_MAX_CORR_COLS, ANALYSIS_MAX_ROWS


def _clean_json(obj):
    """Recursively replace NaN/inf with None so json.dumps/FastAPI don't choke."""
    if isinstance(obj, dict):
        return {str(k): _clean_json(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_clean_json(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        obj = float(obj)
    if isinstance(obj, float):
        if np.isnan(obj) or np.isinf(obj):
            return None
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    if isinstance(obj, pd.Timestamp):
        return obj.isoformat()
    return obj


# Numbers that arrive as text — "1,299", "+0.88%", "$19.99", "−0.5" (with a
# unicode minus) — read as dtype=object, so select_dtypes(np.number) skips them
# and cluster / anomalies / correlation report "no numeric columns" on data the
# user clearly typed as numbers (common with scraped and pasted tables). The
# helper below converts such columns to real numerics on a COPY, for analysis
# only; the stored frame the table, export and charts use keeps the original
# strings. A column converts only when most of its non-null values actually
# parse, so text and id-like ("row0", "N/A", phone numbers) columns are left be.
_NUMERIC_DECORATION_RE = re.compile(r"[,\s%$£€¥]")
_NUMERIC_COERCE_MIN_FRAC = 0.8


def coerce_numeric_like(df: pd.DataFrame, min_frac: float = _NUMERIC_COERCE_MIN_FRAC) -> pd.DataFrame:
    """Return a frame where object columns that are numbers-in-disguise become
    real numerics; every other column is untouched. Never mutates the input — a
    copy is made only once something actually converts, so the common
    all-already-numeric case is free."""
    out = df
    for col in df.columns:
        s = df[col]
        if not pd.api.types.is_object_dtype(s):
            continue
        denom = int(s.notna().sum())
        if denom == 0:
            continue
        cleaned = (
            s.astype(str)
            .str.replace("−", "-", regex=False)   # unicode minus → ASCII "-"
            .str.replace(_NUMERIC_DECORATION_RE, "", regex=True)
            .str.strip()
        )
        parsed = pd.to_numeric(cleaned, errors="coerce")
        if int(parsed.notna().sum()) / denom >= min_frac:
            if out is df:
                out = df.copy()
            out[col] = parsed
    return out


def dataframe_preview(df: pd.DataFrame, rows: int = 50, offset: int = 0) -> list[dict]:
    window = df.iloc[offset:offset + rows].copy()
    window = window.astype(object).where(pd.notnull(window), None)
    return _clean_json(window.to_dict(orient="records"))


def build_summary(df: pd.DataFrame) -> dict:
    """Summary statistics, capped so one 100 MB upload can't monopolise a
    worker. Whenever a cap bites, the response says so rather than quietly
    reporting numbers computed on part of the data."""
    total_rows = int(df.shape[0])
    sampled = total_rows > ANALYSIS_MAX_ROWS
    work = df.sample(ANALYSIS_MAX_ROWS, random_state=0) if sampled else df

    # Numbers stored as text become usable here (describe / correlation / the
    # numeric-column list); dtypes & missing below still report the raw frame,
    # which is what the table and export actually show.
    cwork = coerce_numeric_like(work)
    numeric_df = cwork.select_dtypes(include=[np.number])

    dtypes = {str(col): str(dtype) for col, dtype in df.dtypes.items()}
    missing = {str(k): int(v) for k, v in df.isnull().sum().to_dict().items()}
    missing_pct = {str(k): float(v) for k, v in (df.isnull().mean() * 100).round(2).to_dict().items()}

    describe = {}
    if not numeric_df.empty:
        describe = numeric_df.describe().round(4).to_dict()

    correlation = {}
    corr_truncated = False
    if numeric_df.shape[1] >= 2:
        corr_cols = list(numeric_df.columns[:ANALYSIS_MAX_CORR_COLS])
        corr_truncated = len(corr_cols) < numeric_df.shape[1]
        correlation = numeric_df[corr_cols].corr(numeric_only=True).round(4).to_dict()

    value_counts = {}
    # From cwork too, so a column recovered as numeric above isn't also counted
    # as categorical here.
    cat_cols = cwork.select_dtypes(include=["object", "category", "bool"]).columns[:10]
    for col in cat_cols:
        value_counts[str(col)] = cwork[col].value_counts().head(10).to_dict()

    summary = {
        "shape": {"rows": total_rows, "columns": int(df.shape[1])},
        "columns": [str(c) for c in df.columns],
        "dtypes": dtypes,
        "missing_values": missing,
        "missing_pct": missing_pct,
        "duplicate_rows": int(work.duplicated().sum()),
        "numeric_columns": [str(c) for c in numeric_df.columns],
        "categorical_columns": [str(c) for c in cat_cols],
        "describe": describe,
        "correlation": correlation,
        "sampled": bool(sampled),
        "sample_rows": int(work.shape[0]) if sampled else total_rows,
        "correlation_truncated": bool(corr_truncated),
        "value_counts": value_counts,
    }
    return _clean_json(summary)


# ---------- Correlation (numeric methods + categorical association) ----------

CORRELATION_METHODS = ("pearson", "spearman", "kendall")
TOP_CORR_PAIRS = 15
CORR_MAX_CAT_COLS = 15          # cap categorical columns fed to Cramér's V
CORR_MAX_CAT_CARDINALITY = 50   # skip a categorical wider than this (huge crosstab)


def _cramers_v(a: pd.Series, b: pd.Series) -> float | None:
    """Bias-corrected Cramér's V (0..1) between two aligned categorical series."""
    from scipy.stats import chi2_contingency
    tab = pd.crosstab(a, b)
    if tab.shape[0] < 2 or tab.shape[1] < 2:
        return None
    n = int(tab.to_numpy().sum())
    if n == 0:
        return None
    chi2 = chi2_contingency(tab, correction=False)[0]
    phi2 = chi2 / n
    r, k = tab.shape
    phi2corr = max(0.0, phi2 - (k - 1) * (r - 1) / (n - 1))
    rcorr = r - (r - 1) ** 2 / (n - 1)
    kcorr = k - (k - 1) ** 2 / (n - 1)
    denom = min(rcorr - 1, kcorr - 1)
    if denom <= 0:
        return None
    return float(np.sqrt(phi2corr / denom))


def compute_correlation(
    df: pd.DataFrame,
    method: str = "pearson",
    max_cols: int = ANALYSIS_MAX_CORR_COLS,
) -> dict:
    """Correlation matrix over numeric columns by `method`
    (pearson/spearman/kendall) with the strongest |r| pairs, plus a separate
    Cramér's V association table for categorical columns. Text-encoded numbers
    are recovered first, matching Overview / charts / ML."""
    if method not in CORRELATION_METHODS:
        raise ValueError(f"method must be one of {CORRELATION_METHODS}")
    cwork = coerce_numeric_like(df)
    numeric = cwork.select_dtypes(include=[np.number])

    columns: list[str] = []
    matrix: dict = {}
    top_pairs: list[dict] = []
    truncated = False
    if numeric.shape[1] >= 2:
        cols = list(numeric.columns[:max_cols])
        truncated = len(cols) < numeric.shape[1]
        corr = numeric[cols].corr(method=method).round(4)
        columns = [str(c) for c in cols]
        matrix = corr.to_dict()
        for i in range(len(cols)):
            for j in range(i + 1, len(cols)):
                v = corr.iloc[i, j]
                if pd.notna(v):
                    top_pairs.append({"a": str(cols[i]), "b": str(cols[j]),
                                      "r": round(float(v), 4), "abs": round(abs(float(v)), 4)})
        top_pairs.sort(key=lambda p: p["abs"], reverse=True)
        top_pairs = top_pairs[:TOP_CORR_PAIRS]

    cat_cols = [
        c for c in cwork.select_dtypes(include=["object", "category", "bool"]).columns
        if cwork[c].nunique(dropna=True) <= CORR_MAX_CAT_CARDINALITY
    ][:CORR_MAX_CAT_COLS]
    assoc: list[dict] = []
    for i in range(len(cat_cols)):
        for j in range(i + 1, len(cat_cols)):
            c1, c2 = cat_cols[i], cat_cols[j]
            sub = cwork[[c1, c2]].dropna()
            v = _cramers_v(sub[c1], sub[c2]) if len(sub) else None
            if v is not None:
                assoc.append({"a": str(c1), "b": str(c2), "v": round(v, 4)})
    assoc.sort(key=lambda p: p["v"], reverse=True)

    return _clean_json({
        "method": method,
        "columns": columns,
        "matrix": matrix,
        "top_pairs": top_pairs,
        "truncated": bool(truncated),
        "categorical_association": assoc[:TOP_CORR_PAIRS],
    })


def query_rows(
    df: pd.DataFrame,
    search: str = "",
    sort_by: str | None = None,
    sort_dir: str = "asc",
    offset: int = 0,
    limit: int = 25,
) -> dict:
    """Search / sort / page over the FULL dataset, server-side.

    The table used to filter and sort the 50-row preview while Export shipped
    every row, so the row count and the exported order disagreed with what was
    on screen. Both now run against the same frame.
    """
    work = df
    if search:
        needle = search.lower()
        mask = np.zeros(len(work), dtype=bool)
        for col in work.columns:
            mask |= work[col].astype(str).str.lower().str.contains(needle, regex=False, na=False)
        work = work[mask]

    if sort_by is not None and sort_by in work.columns:
        work = work.sort_values(
            by=sort_by,
            ascending=(sort_dir != "desc"),
            kind="mergesort",       # stable
            na_position="last",     # nulls last in both directions
        )

    total = int(work.shape[0])
    limit = max(1, min(limit, 200))
    offset = max(0, offset)
    return {
        "rows": dataframe_preview(work, rows=limit, offset=offset),
        "total": total,
        "offset": offset,
        "limit": limit,
    }


# ---------- Interactive chart data (JSON, for client-side hover charts) ----------

CHART_DATA_MAX_POINTS = 500   # line/scatter series length cap
CHART_DATA_MAX_CATEGORIES = 25  # bar/pie category cap
CHART_DATA_MAX_BINS = 60


class ChartDataError(Exception):
    pass


def _require_column(df: pd.DataFrame, col: str | None, label: str) -> str:
    if not col or col not in df.columns:
        raise ChartDataError(f"'{label}' column is required and must exist in the dataset.")
    return col


def build_bar_data(df: pd.DataFrame, x: str, y: str | None, warnings: list[str]) -> list[dict]:
    """One bar per category. Aggregates by mean when y is given (matching
    what the static seaborn barplot does by default), else counts rows."""
    if y and y in df.columns:
        grouped = df.groupby(x, dropna=False)[y].mean(numeric_only=True)
        label = y
    else:
        grouped = df.groupby(x, dropna=False).size()
        label = "count"
    grouped = grouped.sort_values(ascending=False)
    if len(grouped) > CHART_DATA_MAX_CATEGORIES:
        warnings.append(
            f"'{x}' has {len(grouped)} distinct values; showing the "
            f"{CHART_DATA_MAX_CATEGORIES} largest."
        )
        grouped = grouped.head(CHART_DATA_MAX_CATEGORIES)
    return [{"category": str(k), "value": None if pd.isna(v) else round(float(v), 4), "label": label}
            for k, v in grouped.items()]


def build_line_data(df: pd.DataFrame, x: str, y: str, warnings: list[str]) -> list[dict]:
    work = df[[x, y]].dropna().sort_values(by=x)
    if len(work) > CHART_DATA_MAX_POINTS:
        # evenly-spaced sample rather than a head() truncation, so a long
        # series still shows its overall shape instead of just the start
        step = max(1, len(work) // CHART_DATA_MAX_POINTS)
        work = work.iloc[::step]
        warnings.append(
            f"Series has more than {CHART_DATA_MAX_POINTS} points; showing an even sample."
        )
    out = []
    for _, row in work.iterrows():
        xv, yv = row[x], row[y]
        out.append({
            "x": xv.isoformat() if isinstance(xv, pd.Timestamp) else (None if pd.isna(xv) else _to_native(xv)),
            "y": None if pd.isna(yv) else round(float(yv), 4),
        })
    return out


def build_pie_data(df: pd.DataFrame, x: str, warnings: list[str]) -> list[dict]:
    counts = df[x].value_counts()
    if counts.empty:
        raise ChartDataError(f"No values to summarize in column '{x}'.")
    if len(counts) > CHART_DATA_MAX_CATEGORIES:
        head = counts.head(CHART_DATA_MAX_CATEGORIES - 1)
        other = counts.iloc[CHART_DATA_MAX_CATEGORIES - 1:].sum()
        counts = pd.concat([head, pd.Series({"Other": other})])
        warnings.append(f"'{x}' has many values; the smallest are grouped into 'Other'.")
    total = int(counts.sum())
    return [
        {"label": str(k), "value": int(v), "pct": round(v / total * 100, 1) if total else 0}
        for k, v in counts.items()
    ]


def build_histogram_data(df: pd.DataFrame, x: str, bins: int, warnings: list[str]) -> list[dict]:
    series = pd.to_numeric(df[x], errors="coerce").dropna()
    if series.empty:
        raise ChartDataError(f"No numeric values to bin in column '{x}'.")
    bins = max(2, min(bins or 20, CHART_DATA_MAX_BINS))
    counts, edges = np.histogram(series, bins=bins)
    return [
        {
            "bin": f"{_fmt_edge(edges[i])}–{_fmt_edge(edges[i + 1])}",
            "start": round(float(edges[i]), 4),
            "end": round(float(edges[i + 1]), 4),
            "count": int(counts[i]),
        }
        for i in range(len(counts))
    ]


def _fmt_edge(v: float) -> str:
    if abs(v) >= 1000:
        return f"{v / 1000:.1f}k"
    if float(v).is_integer():
        return str(int(v))
    return f"{v:.2f}"


def _to_native(v):
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (np.floating,)):
        return round(float(v), 4)
    return v


def build_chart_data(
    df: pd.DataFrame,
    chart_type: str,
    x: str | None,
    y: str | None = None,
    bins: int | None = None,
) -> dict:
    """JSON series for the interactive SVG dashboard panels — a
    lightweight aggregation, not the full matplotlib render, so hover charts
    stay snappy even on a large dataset."""
    warnings: list[str] = []
    # Recover numbers stored as text (e.g. "1,299", "$19.99", "+0.88%") so the
    # dashboard aggregates the same columns Overview/Correlations already treat
    # as numeric — otherwise a bar/line y that looks numeric on screen silently
    # comes back empty or as counts. Column names are preserved, so the
    # _require_column checks below are unaffected.
    df = coerce_numeric_like(df)
    if chart_type == "bar":
        x = _require_column(df, x, "x")
        data = build_bar_data(df, x, y, warnings)
    elif chart_type in ("line", "area"):
        x = _require_column(df, x, "x")
        y = _require_column(df, y, "y")
        data = build_line_data(df, x, y, warnings)
    elif chart_type == "pie":
        x = _require_column(df, x, "x")
        data = build_pie_data(df, x, warnings)
    elif chart_type == "histogram":
        x = _require_column(df, x, "x")
        data = build_histogram_data(df, x, bins or 20, warnings)
    else:
        raise ChartDataError(f"'{chart_type}' does not support interactive data — use /api/visualize.")
    return _clean_json({"chart_type": chart_type, "data": data, "warnings": warnings})
