"""Tests for analysis.py — mostly the text→number recovery (coerce_numeric_like)
that Overview, Correlations, Cluster, Anomalies, the matplotlib charts and the
interactive dashboard all lean on, so a scraped/pasted table whose numbers
arrive as "$1,299" / "+0.88%" / "1,000" is treated as numeric everywhere or
nowhere — never inconsistently between screens."""
import numpy as np
import pandas as pd
import pytest

from analysis import build_chart_data, build_summary, coerce_numeric_like, compute_correlation


def test_recovers_money_percent_comma_and_unicode_minus():
    df = pd.DataFrame({
        "money": ["$1,000", "$2,500", "$3,750", "$4,100"],
        "pct": ["+0.88%", "-1.20%", "0.00%", "2.50%"],
        "signed": ["−5", "−10", "3", "8"],  # U+2212 unicode minus
    })
    out = coerce_numeric_like(df)
    assert pd.api.types.is_numeric_dtype(out["money"])
    assert out["money"].tolist() == [1000.0, 2500.0, 3750.0, 4100.0]
    assert out["pct"].tolist() == [0.88, -1.20, 0.00, 2.50]
    assert out["signed"].tolist() == [-5.0, -10.0, 3.0, 8.0]


def test_genuine_text_is_left_alone():
    df = pd.DataFrame({"colour": ["red", "green", "blue", "red"]})
    out = coerce_numeric_like(df)
    assert pd.api.types.is_object_dtype(out["colour"])
    assert out["colour"].tolist() == ["red", "green", "blue", "red"]


def test_threshold_at_and_below_80_percent():
    # 4/5 parse (0.8) -> convert, the stray text becomes NaN
    at = pd.DataFrame({"c": ["1", "2", "3", "4", "x"]})
    got = coerce_numeric_like(at)["c"]
    assert pd.api.types.is_numeric_dtype(got)
    assert got.dropna().tolist() == [1.0, 2.0, 3.0, 4.0]
    assert bool(got.isna().iloc[-1])

    # 2/5 parse (0.4) -> stay object, it's a text column with a few digits
    below = pd.DataFrame({"c": ["1", "2", "x", "y", "z"]})
    assert pd.api.types.is_object_dtype(coerce_numeric_like(below)["c"])


def test_nulls_do_not_count_toward_the_parse_fraction():
    # denom is non-null count: 2 numeric of 3 non-null = 0.67 < 0.8 -> stay object
    df = pd.DataFrame({"c": ["1", "2", None, "x"]})
    assert pd.api.types.is_object_dtype(coerce_numeric_like(df)["c"])


def test_all_null_object_column_is_skipped():
    df = pd.DataFrame({"c": [None, None, None]}, dtype=object)
    out = coerce_numeric_like(df)
    assert pd.api.types.is_object_dtype(out["c"])


def test_input_frame_is_never_mutated():
    df = pd.DataFrame({"money": ["$1", "$2", "$3"], "t": ["a", "b", "c"]})
    before = df["money"].tolist()
    coerce_numeric_like(df)
    assert pd.api.types.is_object_dtype(df["money"])  # original dtype intact
    assert df["money"].tolist() == before


def test_all_numeric_frame_returns_same_object_no_copy():
    # documented fast path: nothing converts => no copy is made
    df = pd.DataFrame({"a": [1, 2, 3], "b": [1.5, 2.5, 3.5]})
    assert coerce_numeric_like(df) is df


def test_index_is_preserved():
    df = pd.DataFrame({"money": ["$1", "$2", "$3"]}, index=[10, 20, 30])
    out = coerce_numeric_like(df)
    assert out.index.tolist() == [10, 20, 30]


def test_build_summary_counts_text_encoded_numbers_as_numeric():
    df = pd.DataFrame({
        "revenue": ["$1,000", "$2,500", "$3,750", "$4,100"],
        "region": ["N", "S", "E", "W"],
    })
    summary = build_summary(df)
    # recovered as numeric for describe / numeric-column list ...
    assert "revenue" in summary["numeric_columns"]
    assert "revenue" in summary["describe"]
    assert "revenue" not in summary["categorical_columns"]
    assert "region" in summary["categorical_columns"]
    # ... but dtypes still report the raw frame the table/export actually show
    assert summary["dtypes"]["revenue"] == "object"


def test_dashboard_bar_aggregates_text_encoded_money_numerically():
    # P3: without coercion, groupby(...)[y].mean(numeric_only=True) drops the
    # object column and the bar comes back empty / as row counts — the exact
    # screen mismatch this locks against.
    df = pd.DataFrame({
        "region": ["N", "N", "S", "S"],
        "revenue": ["$100", "$300", "$200", "$400"],
    })
    out = build_chart_data(df, "bar", x="region", y="revenue")
    bars = {b["category"]: b["value"] for b in out["data"]}
    assert all(b["label"] == "revenue" for b in out["data"])
    assert bars["N"] == 200.0 and bars["S"] == 300.0


def test_compute_correlation_methods_and_top_pairs():
    rng = np.random.default_rng(0)
    x = rng.normal(0, 1, 200)
    df = pd.DataFrame({
        "x": x,
        "y": 2 * x + rng.normal(0, 0.05, 200),  # near-perfectly correlated with x
        "z": rng.normal(0, 1, 200),             # independent
    })
    out = compute_correlation(df, method="spearman")
    assert out["method"] == "spearman"
    assert set(out["columns"]) == {"x", "y", "z"}
    top = out["top_pairs"][0]
    assert {top["a"], top["b"]} == {"x", "y"} and top["abs"] > 0.9


def test_compute_correlation_cramers_v_on_categoricals():
    # two perfectly-associated text categoricals -> Cramér's V near 1. Labels are
    # chosen so they WON'T coerce to numbers and stay categorical.
    base = ["p", "q", "r"] * 30
    mapping = {"p": "one", "q": "two", "r": "three"}
    df = pd.DataFrame({"a": base, "b": [mapping[v] for v in base]})
    assoc = compute_correlation(df, method="pearson")["categorical_association"]
    assert assoc and {assoc[0]["a"], assoc[0]["b"]} == {"a", "b"}
    assert assoc[0]["v"] > 0.9


def test_compute_correlation_rejects_unknown_method():
    with pytest.raises(ValueError):
        compute_correlation(pd.DataFrame({"x": [1, 2, 3], "y": [3, 2, 1]}), method="nope")


def test_compute_correlation_handles_fewer_than_two_numeric_columns():
    # a single numeric column -> empty numeric matrix, no crash
    out = compute_correlation(pd.DataFrame({"only": [1, 2, 3], "t": ["a", "b", "c"]}))
    assert out["columns"] == [] and out["top_pairs"] == []
