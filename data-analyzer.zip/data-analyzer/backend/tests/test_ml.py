import numpy as np
import pandas as pd
import pytest

from ml import MLError, cluster, detect_anomalies, train_model


# --- reproducible in-memory datasets (module-level so they can be reused) ---

def make_classification_df(n: int = 120) -> pd.DataFrame:
    """Two informative numerics + a categorical; a 3-way label derived from them."""
    rng = np.random.default_rng(0)
    x1 = rng.normal(0, 1, n)
    x2 = rng.normal(5, 2, n)
    color = rng.choice(["red", "green", "blue"], n)
    score = 2 * x1 + (x2 - 5) + (color == "red") * 1.5 + rng.normal(0, 0.5, n)
    label = np.where(score > 1, "high", np.where(score < -1, "low", "mid"))
    return pd.DataFrame({"x1": x1, "x2": x2, "color": color, "label": label})


def make_regression_df(n: int = 150) -> pd.DataFrame:
    rng = np.random.default_rng(1)
    x1 = rng.normal(0, 1, n)
    x2 = rng.uniform(0, 10, n)
    grp = rng.choice(["a", "b", "c"], n)
    target = 3 * x1 - 2 * x2 + (grp == "a") * 5 + rng.normal(0, 0.5, n)
    return pd.DataFrame({"x1": x1, "x2": x2, "grp": grp, "target": target})


def make_cluster_df(n: int = 150) -> pd.DataFrame:
    """Three well-separated 3-D blobs."""
    rng = np.random.default_rng(2)
    centers = np.array([[0, 0, 0], [8, 8, 8], [0, 8, 4]])
    per = n // 3
    pts = np.repeat(centers, per, axis=0) + rng.normal(0, 0.6, (3 * per, 3))
    return pd.DataFrame(pts, columns=["a", "b", "c"])


# ------------------------------------------------------------- train_model ---

def test_train_model_classification():
    out = train_model(make_classification_df(), "label")
    assert out["task"] == "classification"
    assert 0.0 <= out["metrics"]["accuracy"] <= 1.0
    assert 0.0 <= out["metrics"]["f1_macro"] <= 1.0
    assert out["feature_importances"]                      # non-empty
    assert isinstance(out["confusion_matrix"], dict)
    assert set(out["confusion_matrix"]) == {"labels", "matrix"}
    assert out["actual_vs_predicted"] is None
    assert out["classes"]
    assert out["n_features"] == 3
    assert set(out["feature_names"]) == {"x1", "x2", "color"}


def test_train_model_regression():
    out = train_model(make_regression_df(), "target")
    assert out["task"] == "regression"
    assert set(out["metrics"]) == {"r2", "mae", "rmse"}
    assert out["confusion_matrix"] is None
    assert out["classes"] is None
    assert out["actual_vs_predicted"]
    assert len(out["actual_vs_predicted"]) <= 200
    assert {"actual", "predicted"} <= out["actual_vs_predicted"][0].keys()


def test_train_model_missing_target_raises():
    with pytest.raises(MLError):
        train_model(make_regression_df(), "does_not_exist")


def test_train_model_too_few_rows_raises():
    with pytest.raises(MLError):
        train_model(make_classification_df().head(10), "label")


def test_train_model_single_class_raises():
    df = make_classification_df()
    df["label"] = "only"   # collapse to a single class
    with pytest.raises(MLError):
        train_model(df, "label")


def test_train_model_id_like_target_raises():
    # A near-unique text target (an identifier or free text) is rejected with a
    # clean MLError. It used to reach _fit_classifier, where a random split left
    # the train/test class sets disjoint and confusion_matrix raised a 500
    # ("At least one label specified must be in y_true").
    df = make_classification_df(60)
    df["label"] = [f"id{i}" for i in range(len(df))]
    with pytest.raises(MLError):
        train_model(df, "label")


def test_train_model_confusion_matrix_is_square():
    # Labels come from unique_labels(y_te, y_pred) — what actually appears in
    # evaluation — so the matrix is always square and matches its label list.
    out = train_model(make_classification_df(120), "label")
    cm = out["confusion_matrix"]
    n = len(cm["labels"])
    assert n >= 2
    assert len(cm["matrix"]) == n
    assert all(len(row) == n for row in cm["matrix"])


# ------------------------------------------------------------------ cluster ---

def test_cluster_auto_k():
    out = cluster(make_cluster_df(), k=None)
    assert out["auto_k"] is True
    assert 2 <= out["k"] <= 8
    assert sum(c["size"] for c in out["cluster_sizes"]) == out["n_rows_used"]
    assert isinstance(out["projection"], list) and out["projection"]
    assert out["explained_variance"] is None or len(out["explained_variance"]) == 2
    assert out["features"] == ["a", "b", "c"]


def test_cluster_fixed_k():
    out = cluster(make_cluster_df(), k=3)
    assert out["auto_k"] is False
    assert out["k"] == 3
    assert len(out["cluster_sizes"]) == 3


def test_cluster_too_few_numeric_cols_raises():
    df = pd.DataFrame({"only_num": range(50), "text": ["x"] * 50})
    with pytest.raises(MLError):
        cluster(df)


# ---------------------------------------------------------- detect_anomalies ---

def test_detect_anomalies_basic():
    rng = np.random.default_rng(3)
    df = pd.DataFrame({
        "a": rng.normal(0, 1, 200),
        "b": rng.normal(10, 2, 200),
        "name": [f"row{i}" for i in range(200)],   # non-numeric, ignored for fitting
    })
    df.loc[0, ["a", "b"]] = [50.0, 200.0]     # blatant outliers
    df.loc[1, ["a", "b"]] = [-40.0, -100.0]
    out = detect_anomalies(df, contamination=0.05)
    assert out["n_flagged"] >= 0
    assert 0.0 <= out["pct_flagged"] <= 100.0
    assert len(out["top_anomalies"]) <= 20
    assert out["top_anomalies"]
    assert out["features"] == ["a", "b"]
    # top anomalies carry ALL original columns, including the non-numeric one
    assert "name" in out["top_anomalies"][0]["values"]


def test_detect_anomalies_auto_contamination():
    rng = np.random.default_rng(4)
    df = pd.DataFrame({"a": rng.normal(0, 1, 100), "b": rng.normal(0, 1, 100)})
    out = detect_anomalies(df, contamination=None)
    assert 0.0 <= out["contamination"] <= 1.0
    assert 0.0 <= out["pct_flagged"] <= 100.0


def test_detect_anomalies_too_few_rows_raises():
    with pytest.raises(MLError):
        detect_anomalies(pd.DataFrame({"a": range(10), "b": range(10)}))


def test_train_model_text_encoded_money_target_is_regression():
    # P4: a target whose numbers arrive as text ("$1,234.00") is recovered by
    # coerce_numeric_like and trained as regression, instead of being treated as
    # a high-cardinality identifier and rejected by the ID-like-target guard.
    df = make_regression_df(80)
    df["target"] = [f"${v:,.2f}" for v in df["target"]]
    out = train_model(df, "target")
    assert out["task"] == "regression"
    assert out["actual_vs_predicted"]
    row = out["actual_vs_predicted"][0]
    assert "residual" in row
    assert abs(row["residual"] - (row["actual"] - row["predicted"])) < 1e-4
