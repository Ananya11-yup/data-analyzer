import time

import pandas as pd
from fastapi.testclient import TestClient

import config
import store as store_module
from main import app
from analysis import query_rows

client = TestClient(app)
DF = pd.DataFrame({"a": [3, 1, 2, None], "b": ["x", "y", "x", "z"]})


def test_store_ttl_is_sliding(monkeypatch):
    monkeypatch.setattr(store_module, "DATASET_TTL_SECONDS", 1)
    s = store_module.DatasetStore()
    key = s.put(DF, "test")
    for _ in range(3):
        time.sleep(0.5)
        assert s.get(key) is not None  # access refreshes the TTL
    time.sleep(1.2)
    assert s.get(key) is None


def test_upload_rejects_missing_filename():
    r = client.post("/api/upload", files={"file": ("", b"a,b\n1,2")})
    assert r.status_code in (400, 422)
    assert "detail" in r.json()


def test_upload_rejects_oversized_body(monkeypatch):
    monkeypatch.setattr("main.MAX_UPLOAD_BYTES", 1024)
    big = b"a,b\n" + b"1,2\n" * 5000
    r = client.post("/api/upload", files={"file": ("big.csv", big, "text/csv")})
    assert r.status_code == 413


def test_paste_analyze_rows_export_roundtrip():
    r = client.post("/api/paste", json={"text": "a,b\n1,x\n2,y\n3,x"})
    assert r.status_code == 200, r.text
    ds = r.json()["dataset_id"]

    summary = client.post("/api/analyze", json={"dataset_id": ds}).json()
    assert summary["shape"] == {"rows": 3, "columns": 2}

    rows = client.get(f"/api/rows/{ds}", params={"search": "x", "sort_by": "a", "sort_dir": "desc"}).json()
    assert rows["total"] == 2 and rows["rows"][0]["a"] == 3

    csv = client.get(f"/api/export/{ds}", params={"fmt": "csv"})
    assert csv.status_code == 200 and "a,b" in csv.text


def test_missing_dataset_returns_json_detail():
    r = client.get("/api/rows/does-not-exist")
    assert r.status_code == 404 and r.json()["detail"]


def test_query_rows_sorts_nulls_last_in_both_directions():
    asc = query_rows(DF, sort_by="a", sort_dir="asc", limit=10)["rows"]
    desc = query_rows(DF, sort_by="a", sort_dir="desc", limit=10)["rows"]
    assert asc[-1]["a"] is None and desc[-1]["a"] is None
    assert [r["a"] for r in asc[:3]] == [1, 2, 3]
    assert [r["a"] for r in desc[:3]] == [3, 2, 1]


def test_limits_endpoint_matches_config():
    data = client.get("/api/limits").json()
    assert data["max_upload_mb"] == config.MAX_UPLOAD_MB
    assert "deep" in data["palettes"]


def test_dataset_delete_lifecycle():
    ds = client.post("/api/paste", json={"text": "a,b\n1,x\n2,y"}).json()["dataset_id"]
    assert client.post("/api/analyze", json={"dataset_id": ds}).status_code == 200
    d = client.delete(f"/api/dataset/{ds}")
    assert d.status_code == 200 and d.json()["deleted"] == ds
    # gone now: analyze 404s and a second delete also 404s
    assert client.post("/api/analyze", json={"dataset_id": ds}).status_code == 404
    assert client.delete(f"/api/dataset/{ds}").status_code == 404


def test_correlation_endpoint_roundtrip():
    text = "x,y\n1,2\n2,4\n3,6\n4,8\n5,10\n6,12"  # y == 2x, perfectly linear
    ds = client.post("/api/paste", json={"text": text}).json()["dataset_id"]
    r = client.post("/api/correlation", json={"dataset_id": ds, "method": "pearson"})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["method"] == "pearson"
    assert set(body["columns"]) == {"x", "y"}
    assert body["top_pairs"][0]["abs"] > 0.99
    # invalid method is rejected by the schema pattern (422, not 500)
    bad = client.post("/api/correlation", json={"dataset_id": ds, "method": "nope"})
    assert bad.status_code == 422
