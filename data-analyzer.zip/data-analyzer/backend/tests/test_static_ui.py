"""The vanilla UI is served same-origin by FastAPI via a StaticFiles mount at
"/". These tests pin that contract: the shell HTML and its assets are served,
and — crucially — the catch-all mount did NOT shadow the /api/* routes."""
from fastapi.testclient import TestClient

from main import app

client = TestClient(app)


def test_root_serves_html_shell():
    r = client.get("/")
    assert r.status_code == 200
    assert "text/html" in r.headers.get("content-type", "")
    body = r.text
    assert "<title>Data Analyzer</title>" in body
    assert '/js/main.js' in body  # the SPA entry point is wired up


def test_static_assets_are_served():
    css = client.get("/styles.css")
    assert css.status_code == 200 and "text/css" in css.headers.get("content-type", "")
    js = client.get("/js/main.js")
    assert js.status_code == 200
    assert "javascript" in js.headers.get("content-type", "").lower()


def test_api_health_still_reachable_under_static_mount():
    # The mount lives at "/", so this guards against it swallowing the API.
    r = client.get("/api/health")
    assert r.status_code == 200 and r.json()["status"] == "ok"


def test_unknown_api_path_is_not_served_html():
    # A missing /api route must 404 as JSON, not fall through to index.html.
    r = client.get("/api/does-not-exist")
    assert r.status_code == 404
