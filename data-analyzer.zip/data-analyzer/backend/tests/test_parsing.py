import pandas as pd
import pytest
from bs4 import BeautifulSoup

from parsing import BROWSER_HEADERS, ParsingError, dedupe_columns, parse_pasted_text, _extract_repeated_cards


def test_dedupe_columns_keeps_every_column():
    df = pd.DataFrame([[1, 2], [3, 4]], columns=["a", "a"])
    out = dedupe_columns(df)
    assert list(out.columns) == ["a", "a.1"]
    # the bug this fixes: to_dict dropped one of the two 'a' columns
    assert out.to_dict(orient="records") == [{"a": 1, "a.1": 2}, {"a": 3, "a.1": 4}]


def test_paste_csv():
    df = parse_pasted_text("a,b\n1,2\n3,4")
    assert df.shape == (2, 2)


def test_paste_json():
    df = parse_pasted_text('[{"a":1,"b":2},{"a":3,"b":4}]')
    assert list(df.columns) == ["a", "b"]


def test_paste_empty_raises():
    with pytest.raises(ParsingError):
        parse_pasted_text("   ")


def test_card_extraction_names_fields():
    html = "".join(
        f'<div class="card"><h3>Item {i}</h3><span>$ {i}0.00</span>'
        f'<a href="/i/{i}">buy</a></div>' for i in range(6)
    )
    df = _extract_repeated_cards(BeautifulSoup(f"<body>{html}</body>", "html.parser"))
    assert df is not None
    assert "title" in df.columns and "href" in df.columns


class _FakeResp:
    def __init__(self, status=200, headers=None, body=b"<table><tr><td>1</td></tr></table>"):
        self.status_code = status
        self.headers = headers or {"Content-Type": "text/html"}
        self._body = body
        self.is_redirect = 300 <= status < 400
        self.is_permanent_redirect = status in (301, 308)
        self.raw = self

    def read(self, _n, decode_content=True):
        return self._body

    def raise_for_status(self):
        pass

    def close(self):
        pass


def test_redirect_to_a_blocked_host_is_refused(monkeypatch):
    """SEC-01: requests used to follow the 3xx itself, so the blocklist never
    saw the redirect target."""
    import parsing

    monkeypatch.setattr(parsing, "_robots_allows", lambda url: True)
    real_validate = parsing.validate_url
    monkeypatch.setattr(parsing, "validate_url",
                        lambda url: ("evil.test", "93.184.216.34")
                        if "evil.test" in url else real_validate(url))

    hops = {"n": 0}

    def fake_get(url, **kwargs):
        hops["n"] += 1
        return _FakeResp(302, {"Location": "http://169.254.169.254/latest/meta-data/"})

    monkeypatch.setattr(parsing.SESSION, "get", fake_get)
    with pytest.raises(ParsingError, match="not allowed"):
        parsing.scrape_url("http://evil.test/start")
    assert hops["n"] == 1  # stopped at the first hop, never fetched metadata


def test_non_html_content_type_is_rejected(monkeypatch):
    import parsing

    monkeypatch.setattr(parsing, "_robots_allows", lambda url: True)
    monkeypatch.setattr(parsing, "validate_url", lambda url: ("example.test", "93.184.216.34"))
    monkeypatch.setattr(parsing.SESSION, "get",
                        lambda url, **kw: _FakeResp(200, {"Content-Type": "image/png"}, b"\x89PNG"))
    with pytest.raises(ParsingError, match="not an HTML page"):
        parsing.scrape_url("http://example.test/logo.png")


def test_brotli_decoder_is_installed_when_advertised():
    """REL-03/CFG-04: advertising 'br' without the decoder returned binary to
    the HTML parser and blamed JavaScript for the garbage."""
    import parsing

    if "br" in parsing.BROWSER_HEADERS["Accept-Encoding"]:
        import brotli  # noqa: F401


def test_user_agent_does_not_self_identify_as_a_bot():
    """Regression: an earlier version's User-Agent literally announced
    'DataAnalyzerBot' to every site it visited. robots.txt compliance
    (already checked separately) is the real consent mechanism — declaring
    "I am a bot" on top of that just gets silently throttled or hung by
    Cloudflare/Akamai/PerimeterX-style bot detection on most real sites,
    which is indistinguishable from a slow site from the client side."""
    ua = BROWSER_HEADERS["User-Agent"].lower()
    assert "bot" not in ua
    assert "crawler" not in ua
    assert "spider" not in ua
    assert "mozilla" in ua  # looks like an actual browser
