"""Regression test for the bug where chart tinkering and URL scraping shared
one rate-limit bucket: burning through visualize calls (live preview fires
one per option change) would 429 an unrelated scrape right after."""
import importlib

import config
import ratelimit


def _fresh_request(ip="1.2.3.4"):
    class FakeClient:
        host = ip

    class FakeRequest:
        client = FakeClient()
        headers = {}

    return FakeRequest()


def test_visualize_and_scrape_use_independent_buckets(monkeypatch):
    monkeypatch.setattr(config, "RATE_LIMIT_ENABLED", True)
    monkeypatch.setattr(config, "RATE_LIMIT_VISUALIZE", 3)
    monkeypatch.setattr(config, "RATE_LIMIT_SCRAPE", 3)
    importlib.reload(ratelimit)
    ratelimit._hits.clear()

    req = _fresh_request()

    # Exhaust the visualize bucket (simulates rapid chart-option changes).
    for _ in range(3):
        ratelimit.visualize(req)

    import pytest
    with pytest.raises(Exception):
        ratelimit.visualize(req)

    # Scrape must be completely unaffected — this is the exact bug that was
    # reported: paste a URL right after tinkering with charts and get 429.
    ratelimit.scrape(req)
    ratelimit.scrape(req)
    ratelimit.scrape(req)

    importlib.reload(ratelimit)  # restore real config-derived state for later tests


def test_upload_bucket_is_also_independent(monkeypatch):
    monkeypatch.setattr(config, "RATE_LIMIT_ENABLED", True)
    monkeypatch.setattr(config, "RATE_LIMIT_UPLOAD", 2)
    monkeypatch.setattr(config, "RATE_LIMIT_VISUALIZE", 2)
    importlib.reload(ratelimit)
    ratelimit._hits.clear()

    req = _fresh_request("5.6.7.8")
    ratelimit.upload(req)
    ratelimit.upload(req)

    import pytest
    with pytest.raises(Exception):
        ratelimit.upload(req)

    ratelimit.visualize(req)
    ratelimit.visualize(req)

    importlib.reload(ratelimit)
