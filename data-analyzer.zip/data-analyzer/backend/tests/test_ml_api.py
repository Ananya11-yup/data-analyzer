"""End-to-end round-trips for the /api/ml/* endpoints via TestClient.

The pure functions are unit-tested in test_ml.py; here we only prove the
endpoints load the dataset, wire the request models, and turn an MLError into
a clean 400 (rather than a 500)."""
import numpy as np
import pandas as pd
from fastapi.testclient import TestClient

from main import app

client = TestClient(app)


def _paste(df: pd.DataFrame) -> str:
    """Ingest a DataFrame through /api/paste and return its dataset_id."""
    text = df.to_csv(index=False)
    r = client.post("/api/paste", json={"text": text})
    assert r.status_code == 200, r.text
    return r.json()["dataset_id"]


def _ml_dataset(n: int = 90) -> pd.DataFrame:
    rng = np.random.default_rng(0)
    x1 = rng.normal(0, 1, n)
    x2 = rng.normal(5, 2, n)
    grp = rng.choice(["a", "b", "c"], n)
    score = 2 * x1 + (x2 - 5) + rng.normal(0, 0.4, n)
    label = np.where(score > 0.5, "high", np.where(score < -0.5, "low", "mid"))
    return pd.DataFrame({"x1": x1, "x2": x2, "grp": grp, "label": label})


def test_ml_train_classification_roundtrip():
    ds = _paste(_ml_dataset())
    r = client.post("/api/ml/train", json={"dataset_id": ds, "target": "label"})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["task"] == "classification"
    assert 0.0 <= body["metrics"]["accuracy"] <= 1.0
    assert body["feature_importances"]
    assert isinstance(body["confusion_matrix"], dict)


def test_ml_train_regression_roundtrip():
    ds = _paste(_ml_dataset())
    r = client.post("/api/ml/train", json={"dataset_id": ds, "target": "x1"})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["task"] == "regression"
    assert set(body["metrics"]) == {"r2", "mae", "rmse"}


def test_ml_train_bad_target_returns_400():
    ds = _paste(_ml_dataset())
    r = client.post("/api/ml/train", json={"dataset_id": ds, "target": "nope"})
    assert r.status_code == 400 and r.json()["detail"]


def test_ml_cluster_roundtrip():
    ds = _paste(_ml_dataset())
    r = client.post("/api/ml/cluster", json={"dataset_id": ds})
    assert r.status_code == 200, r.text
    body = r.json()
    assert 2 <= body["k"] <= 8
    assert sum(c["size"] for c in body["cluster_sizes"]) == body["n_rows_used"]
    assert isinstance(body["projection"], list)


def test_ml_anomalies_roundtrip():
    ds = _paste(_ml_dataset())
    r = client.post("/api/ml/anomalies", json={"dataset_id": ds, "contamination": 0.1})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["n_flagged"] >= 0
    assert 0.0 <= body["pct_flagged"] <= 100.0
    assert len(body["top_anomalies"]) <= 20


def test_ml_train_missing_dataset_returns_404():
    r = client.post("/api/ml/train", json={"dataset_id": "nope", "target": "label"})
    assert r.status_code == 404 and r.json()["detail"]
