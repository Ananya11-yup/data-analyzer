import numpy as np
import pandas as pd
import pytest
from fastapi.testclient import TestClient

from analysis import ChartDataError, build_chart_data
from main import app

client = TestClient(app)


@pytest.fixture
def df():
    rng = np.random.default_rng(0)
    return pd.DataFrame({
        "region": ["North", "South", "East", "West"] * 25,
        "revenue": rng.normal(1000, 200, 100),
        "date": pd.date_range("2024-01-01", periods=100, freq="D"),
    })


def test_bar_data_aggregates_mean_like_the_static_chart_does(df):
    out = build_chart_data(df, "bar", x="region", y="revenue")
    assert out["chart_type"] == "bar"
    assert len(out["data"]) == 4
    assert {"category", "value", "label"} <= out["data"][0].keys()


def test_bar_data_without_y_counts_rows(df):
    out = build_chart_data(df, "bar", x="region", y=None)
    assert all(d["label"] == "count" for d in out["data"])
    assert sum(d["value"] for d in out["data"]) == 100


def test_line_data_sorted_and_capped(df):
    big = pd.DataFrame({"x": range(2000), "y": np.random.default_rng(1).normal(size=2000)})
    out = build_chart_data(big, "line", x="x", y="y")
    assert len(out["data"]) <= 500
    xs = [d["x"] for d in out["data"]]
    assert xs == sorted(xs)
    assert any("even sample" in w for w in out["warnings"])


def test_pie_data_groups_long_tail(df):
    wide = pd.DataFrame({"cat": [f"c{i}" for i in range(100)]})
    out = build_chart_data(wide, "pie", x="cat")
    assert len(out["data"]) <= 25
    assert any(d["label"] == "Other" for d in out["data"])
    assert any("grouped into 'Other'" in w for w in out["warnings"])


def test_histogram_data_bins_and_counts(df):
    out = build_chart_data(df, "histogram", x="revenue", bins=10)
    assert len(out["data"]) == 10
    assert sum(d["count"] for d in out["data"]) == 100


def test_unsupported_chart_type_raises():
    with pytest.raises(ChartDataError):
        build_chart_data(pd.DataFrame({"a": [1]}), "heatmap", x="a")


def test_missing_column_raises_clean_error(df):
    with pytest.raises(ChartDataError, match="required"):
        build_chart_data(df, "bar", x=None)


def test_endpoint_roundtrip():
    ds = client.post("/api/paste", json={"text": "region,revenue\nNorth,100\nSouth,200\nNorth,150"}).json()["dataset_id"]
    r = client.post("/api/chart-data", json={"dataset_id": ds, "chart_type": "bar", "x": "region", "y": "revenue"})
    assert r.status_code == 200, r.text
    data = r.json()["data"]
    assert len(data) == 2


def test_endpoint_rejects_unsupported_type():
    ds = client.post("/api/paste", json={"text": "a,b\n1,2"}).json()["dataset_id"]
    r = client.post("/api/chart-data", json={"dataset_id": ds, "chart_type": "heatmap", "x": "a"})
    assert r.status_code == 400


def test_endpoint_missing_dataset_is_404():
    r = client.post("/api/chart-data", json={"dataset_id": "nope", "chart_type": "bar", "x": "a"})
    assert r.status_code == 404
