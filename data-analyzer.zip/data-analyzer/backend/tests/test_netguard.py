import pytest

from netguard import BlockedHostError, is_forbidden_ip, validate_url
import ipaddress


@pytest.mark.parametrize("addr", [
    "127.0.0.1", "10.0.0.5", "172.17.0.1", "172.31.255.254", "192.168.1.1",
    "169.254.169.254", "100.64.0.1", "0.0.0.0", "::1", "fc00::1", "fe80::1",
    "::ffff:127.0.0.1",
])
def test_private_and_ipv6_ranges_are_blocked(addr):
    assert is_forbidden_ip(ipaddress.ip_address(addr))


@pytest.mark.parametrize("addr", ["93.184.216.34", "8.8.8.8", "2606:4700::1111"])
def test_public_addresses_pass(addr):
    assert not is_forbidden_ip(ipaddress.ip_address(addr))


@pytest.mark.parametrize("url", [
    "http://127.0.0.1:8000/x",       # plain loopback
    "http://2130706433/",            # decimal-encoded 127.0.0.1
    "http://[::1]/",                 # IPv6 loopback
    "http://172.17.0.1:8000/",       # docker host gateway
    "http://169.254.169.254/latest/meta-data/",
    "http://localhost/",
    "ftp://example.com/",
])
def test_blocked_urls(url):
    with pytest.raises(BlockedHostError):
        validate_url(url)


def test_public_literal_is_allowed():
    host, ip = validate_url("http://93.184.216.34/page")
    assert host == "93.184.216.34" and ip == "93.184.216.34"
