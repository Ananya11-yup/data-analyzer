import warnings

import numpy as np
import pandas as pd
import pytest

from charts import ChartError, generate_chart


@pytest.fixture
def df():
    rng = np.random.default_rng(0)
    return pd.DataFrame({
        "cat": ["a", "b", "c", "d"] * 12,
        "num": rng.normal(50, 10, 48),
        "num2": rng.normal(5, 1, 48),
        "grp": ["x", "y"] * 24,
    })


@pytest.mark.parametrize("chart_type,kwargs", [
    ("bar", {"x": "cat", "y": "num"}),
    ("line", {"x": "num2", "y": "num"}),
    ("scatter", {"x": "num2", "y": "num"}),
    ("histogram", {"x": "num"}),
    ("kde", {"x": "num"}),
    ("box", {"x": "cat", "y": "num"}),
    ("violin", {"x": "cat", "y": "num"}),
    ("count", {"x": "cat"}),
    ("area", {"x": "num2", "y": "num"}),
    ("heatmap", {}),
    ("pie", {"x": "cat"}),
    ("pairplot", {}),
])
def test_every_chart_type_renders(df, chart_type, kwargs):
    for theme in ("light", "dark"):
        out = generate_chart(df, chart_type=chart_type, theme=theme, **kwargs)
        assert out["image"].startswith("data:image/png;base64,")
        assert out["thumbnail"].startswith("data:image/png;base64,")


def test_pairplot_with_numeric_hue_no_longer_fails(df):
    # REL-08: df[cols + [hue]] duplicated the label -> "Data must be 1-dimensional"
    out = generate_chart(df, chart_type="pairplot", theme="light", hue="num2")
    assert out["image"]


def test_palette_without_hue_emits_no_seaborn_deprecation(df):
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        generate_chart(df, chart_type="bar", theme="light", x="cat", y="num", palette="viridis")
    assert not [w for w in caught if "palette without assigning hue" in str(w.message)]


def test_log_scale_on_non_positive_data_warns_instead_of_lying(df):
    data = df.copy()
    data.loc[0, "num"] = -5
    data.loc[1, "num"] = 0
    out = generate_chart(data, chart_type="scatter", theme="light", x="num2", y="num", log_scale=True)
    assert any("Log scale skipped" in w for w in out["warnings"])


def test_chart_size_is_honoured(df):
    small = generate_chart(df, chart_type="bar", theme="light", x="cat", y="num",
                           width=6, height=4, dpi=80)
    big = generate_chart(df, chart_type="bar", theme="light", x="cat", y="num",
                         width=16, height=9, dpi=150)
    assert small["width_px"] == 480 and big["width_px"] == 2400
    assert len(big["image"]) > len(small["image"])


def test_missing_required_axis_is_a_chart_error(df):
    with pytest.raises(ChartError):
        generate_chart(df, chart_type="line", theme="light", x="num2")


def test_many_categories_are_capped(df):
    wide = pd.DataFrame({"cat": [f"c{i}" for i in range(200)], "num": range(200)})
    out = generate_chart(wide, chart_type="bar", theme="light", x="cat", y="num")
    assert any("most frequent" in w for w in out["warnings"])


def test_concurrent_renders_keep_their_own_theme(df):
    from concurrent.futures import ThreadPoolExecutor
    themes = ["light", "dark"] * 8
    with ThreadPoolExecutor(max_workers=8) as pool:
        results = list(pool.map(
            lambda t: generate_chart(df, chart_type="bar", theme=t, x="cat", y="num"), themes
        ))
    assert all(r["image"] for r in results)


def test_high_cardinality_numeric_hue_is_dropped_not_hung(df):
    """Reported bug: picking the same continuous numeric column as both X and
    Hue used to sail through unfiltered (numeric columns were exempt from the
    category cap), so seaborn tried to build one legend entry per distinct
    value. On real data (hundreds/thousands of uniques) that doesn't error —
    it just churns for a very long time, which looks exactly like "the chart
    isn't generating"."""
    import time

    wide = pd.DataFrame({
        "population": np.random.default_rng(1).integers(1, 5_000_000, 500),
        "value": np.random.default_rng(2).normal(0, 1, 500),
    })
    start = time.monotonic()
    out = generate_chart(
        wide, chart_type="kde", theme="light", x="population", hue="population"
    )
    elapsed = time.monotonic() - start
    assert elapsed < 5, f"took {elapsed:.1f}s — hue cardinality guard did not kick in"
    assert any("too many to color by" in w for w in out["warnings"])


def test_bar_with_text_encoded_numeric_y_renders(df):
    # P3: a y column whose numbers arrive as text ("$1,000") is recovered and
    # plotted, matching the dashboard / Overview behaviour instead of erroring
    # out or drawing an empty axis.
    data = df.copy()
    data["price"] = [f"${v:,.0f}" for v in data["num"]]
    out = generate_chart(data, chart_type="bar", theme="light", x="cat", y="price")
    assert out["image"].startswith("data:image/png;base64,")


def test_low_cardinality_numeric_hue_is_kept(df):
    # a numeric column with only a few distinct values (e.g. a 1-5 rating)
    # is a legitimate, useful hue and must not be dropped
    small = df.copy()
    small["rating"] = (small.index % 4) + 1  # 4 distinct values
    out = generate_chart(small, chart_type="scatter", theme="light", x="num", y="num2", hue="rating")
    assert not any("too many to color by" in w for w in out["warnings"])
