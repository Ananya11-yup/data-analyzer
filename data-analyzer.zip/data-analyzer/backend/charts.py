"""Chart rendering.

Two structural fixes over the previous version:

* No pyplot in the render path. Figures are built with `Figure` +
  `FigureCanvasAgg`, so nothing is registered in pyplot's global figure
  manager and nothing leaks between requests.
* Style is applied under a render lock with `rc_context`, never with a bare
  `sns.set_theme()`. FastAPI runs sync endpoints in a threadpool, so a
  light-theme request used to be able to land between a dark-theme request's
  `set_theme` and its `savefig` and come out with the wrong background.

Everything else here is about charts that are actually readable: real figure
sizing, tick labels that don't overlap, thousands separators, legends outside
the axes, and a cap on how many categories get drawn.
"""
import base64
import io
import threading

import matplotlib

matplotlib.use("Agg")  # noqa: E402
import matplotlib.pyplot as plt  # only for colormaps / pairplot cleanup
import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
from matplotlib.ticker import FuncFormatter

from config import (
    CHART_DEFAULT_DPI,
    CHART_DEFAULT_HEIGHT_IN,
    CHART_DEFAULT_WIDTH_IN,
    CHART_MAX_DPI,
    CHART_MAX_HEIGHT_IN,
    CHART_MAX_WIDTH_IN,
    CHART_MIN_DPI,
    CHART_MIN_HEIGHT_IN,
    CHART_MIN_WIDTH_IN,
)

from analysis import coerce_numeric_like


class ChartError(Exception):
    pass


_RENDER_LOCK = threading.RLock()

MAX_CATEGORIES = 30
MAX_PIE_SLICES = 10
MAX_HUE_LEVELS = 12

# Matplotlib theme for the server-rendered chart PNGs (slate ink, indigo accent,
# cool-gray grid). This is the chart-image palette; it is separate from the
# vanilla UI's own CSS tokens (web/styles.css) and the theme-aware SVG charts in
# web/js/svg.js, which render the interactive Dashboard/Correlations screens.
LIGHT = {
    "figure_bg": "#ffffff",
    "axes_bg": "#ffffff",
    "text": "#0f172a",
    "muted": "#64748b",
    "grid": "#e2e8f0",
    "palette": "deep",
    "seaborn_style": "whitegrid",
}

DARK = {
    "figure_bg": "#1e293b",
    "axes_bg": "#1e293b",
    "text": "#f1f5f9",
    "muted": "#94a3b8",
    "grid": "#334155",
    "palette": "mako",
    "seaborn_style": "darkgrid",
}

VALID_CHART_TYPES = {
    "bar", "line", "scatter", "histogram", "box", "violin", "area",
    "kde", "count", "heatmap", "pie", "pairplot",
}

# Single source of truth for palettes — /api/palettes serves this list to the
# UI, so the two can no longer drift.
VALID_PALETTES = [
    "deep", "pastel", "muted", "Blues", "mako", "viridis", "coolwarm",
    "rocket", "flare", "crest", "magma", "cubehelix", "Set2", "husl",
]

CHART_TYPES_NEEDING_Y = {"line", "scatter", "area"}
CHART_TYPES_IGNORING_Y = {"histogram", "kde", "count", "pie", "heatmap", "pairplot"}


def _theme_config(theme: str) -> dict:
    return DARK if theme == "dark" else LIGHT


def _safe_palette(pal: str | None, cfg: dict) -> str:
    if not pal:
        return cfg["palette"]
    if pal not in VALID_PALETTES:
        return cfg["palette"]
    try:
        sns.color_palette(pal, 2)
        return pal
    except (ValueError, TypeError):
        return cfg["palette"]


def _clamp(value, low, high, default):
    if value is None:
        return default
    try:
        return max(low, min(float(value), high))
    except (TypeError, ValueError):
        return default


def _fmt_number(value, _pos=None) -> str:
    if value is None:
        return ""
    a = abs(value)
    if a >= 1_000_000_000:
        return f"{value / 1_000_000_000:.1f}B"
    if a >= 1_000_000:
        return f"{value / 1_000_000:.1f}M"
    if a >= 1_000:
        return f"{value / 1_000:.1f}k"
    if a >= 1 or value == 0:
        return f"{value:,.2f}".rstrip("0").rstrip(".")
    return f"{value:.3g}"


def _rc(cfg: dict, base_font: float) -> dict:
    return {
        "figure.facecolor": cfg["figure_bg"],
        "axes.facecolor": cfg["axes_bg"],
        "axes.edgecolor": cfg["grid"],
        "axes.labelcolor": cfg["text"],
        "axes.titlecolor": cfg["text"],
        "axes.titlesize": base_font + 3,
        "axes.titleweight": "600",
        "axes.labelsize": base_font,
        "axes.grid": True,
        "grid.color": cfg["grid"],
        "grid.alpha": 0.55,
        "grid.linewidth": 0.8,
        "text.color": cfg["text"],
        "xtick.color": cfg["muted"],
        "ytick.color": cfg["muted"],
        "xtick.labelsize": base_font - 1,
        "ytick.labelsize": base_font - 1,
        "legend.fontsize": base_font - 1,
        "legend.frameon": True,
        "legend.facecolor": cfg["axes_bg"],
        "legend.edgecolor": cfg["grid"],
        "font.size": base_font,
        "savefig.facecolor": cfg["figure_bg"],
        "figure.autolayout": False,
    }


def _prepare_hue(df: pd.DataFrame, hue: str | None, warnings: list[str]) -> str | None:
    """Guard against a runaway legend.

    `_limit_categories` used to skip numeric columns outright, so picking a
    high-cardinality numeric column as Hue (e.g. the same column as X) sailed
    through unfiltered: seaborn then tries to give every distinct value —
    potentially thousands — its own legend colour. It doesn't error, it just
    churns for a very long time, which reads as "the chart isn't generating".
    Any hue, numeric or categorical, with too many distinct values is dropped
    with a clear warning instead of silently hanging.
    """
    if not hue or hue not in df.columns:
        return hue
    nunique = df[hue].nunique(dropna=True)
    if nunique > MAX_HUE_LEVELS:
        warnings.append(
            f"'{hue}' has {nunique} distinct values, too many to color by — "
            f"showing without grouping. Pick a column with {MAX_HUE_LEVELS} or "
            "fewer categories for Hue."
        )
        return None
    return hue


def _limit_categories(df: pd.DataFrame, col: str | None, warnings: list[str]) -> pd.DataFrame:
    """Keep charts legible: draw at most MAX_CATEGORIES bars/boxes."""
    if not col or col not in df.columns:
        return df
    series = df[col]
    if pd.api.types.is_numeric_dtype(series):
        return df
    counts = series.value_counts()
    if len(counts) <= MAX_CATEGORIES:
        return df
    keep = counts.head(MAX_CATEGORIES).index
    warnings.append(
        f"'{col}' has {len(counts)} distinct values; showing the {MAX_CATEGORIES} most frequent."
    )
    return df[series.isin(keep)]


def _style_axes(ax, cfg: dict, rotate_x: bool, numeric_y: bool, numeric_x: bool) -> None:
    ax.set_facecolor(cfg["axes_bg"])
    for spine_name, spine in ax.spines.items():
        spine.set_color(cfg["grid"])
        spine.set_visible(spine_name in ("left", "bottom"))
    ax.tick_params(colors=cfg["muted"], length=3)
    ax.xaxis.label.set_color(cfg["text"])
    ax.yaxis.label.set_color(cfg["text"])
    ax.title.set_color(cfg["text"])
    if numeric_y:
        ax.yaxis.set_major_formatter(FuncFormatter(_fmt_number))
    if numeric_x:
        ax.xaxis.set_major_formatter(FuncFormatter(_fmt_number))
    if rotate_x:
        for label in ax.get_xticklabels():
            label.set_rotation(35)
            label.set_ha("right")
            label.set_rotation_mode("anchor")
    legend = ax.get_legend()
    if legend:
        # Outside the plotting area: an overlapping legend was hiding data.
        legend.set_frame_on(True)
        legend.get_frame().set_facecolor(cfg["axes_bg"])
        legend.get_frame().set_edgecolor(cfg["grid"])
        for text in legend.get_texts():
            text.set_color(cfg["text"])
        title = legend.get_title()
        if title:
            title.set_color(cfg["text"])


def _needs_rotation(df: pd.DataFrame, col: str | None) -> bool:
    if not col or col not in df.columns:
        return False
    series = df[col]
    if pd.api.types.is_numeric_dtype(series):
        return False
    uniques = series.astype(str).unique()
    if len(uniques) > 6:
        return True
    return any(len(u) > 10 for u in uniques[:50])


def _fig_to_base64(fig, dpi: float) -> str:
    FigureCanvasAgg(fig)
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=dpi, facecolor=fig.get_facecolor(), bbox_inches="tight")
    buf.seek(0)
    return "data:image/png;base64," + base64.b64encode(buf.read()).decode("utf-8")


def _thumbnail(fig) -> str:
    """Small companion image so the history strip doesn't decode a 1 MB PNG
    into a 90x64 thumbnail."""
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=24, facecolor=fig.get_facecolor(), bbox_inches="tight")
    buf.seek(0)
    return "data:image/png;base64," + base64.b64encode(buf.read()).decode("utf-8")


def _require(value, name):
    if not value:
        raise ChartError(f"'{name}' axis is required for this chart type.")


def _check_log_scale(values: pd.Series | np.ndarray, warnings: list[str]) -> bool:
    """Matplotlib does NOT raise for non-positive data under a log scale — it
    silently masks those points at draw time, which is how the old try/except
    ValueError branch ended up unreachable. Check the data instead."""
    arr = pd.to_numeric(pd.Series(np.asarray(values).ravel()), errors="coerce").dropna()
    if arr.empty:
        return False
    if (arr <= 0).any():
        warnings.append(
            "Log scale skipped: the plotted values include zero or negative "
            "numbers, which a log axis cannot show."
        )
        return False
    return True


def generate_chart(
    df: pd.DataFrame,
    chart_type: str,
    theme: str,
    x: str | None = None,
    y: str | None = None,
    hue: str | None = None,
    title: str | None = None,
    palette: str | None = None,
    bins: int | None = None,
    orientation: str = "vertical",
    log_scale: bool = False,
    donut: bool = False,
    width: float | None = None,
    height: float | None = None,
    dpi: int | None = None,
) -> dict:
    if chart_type not in VALID_CHART_TYPES:
        raise ChartError(
            f"Unsupported chart type: '{chart_type}'. Choose one of: {sorted(VALID_CHART_TYPES)}"
        )
    for col in (x, y, hue):
        if col and col not in df.columns:
            raise ChartError(f"Column not found: '{col}'")
    if chart_type in CHART_TYPES_NEEDING_Y:
        _require(x, "x")
        _require(y, "y")
    elif chart_type not in ("heatmap", "pairplot"):
        _require(x, "x")

    warnings: list[str] = []
    if y and chart_type in CHART_TYPES_IGNORING_Y:
        y = None  # these chart types genuinely ignore y; don't pretend otherwise

    cfg = _theme_config(theme)
    pal = _safe_palette(palette, cfg)
    bins = int(max(2, min(bins, 200))) if bins else 30

    w = _clamp(width, CHART_MIN_WIDTH_IN, CHART_MAX_WIDTH_IN, CHART_DEFAULT_WIDTH_IN)
    h = _clamp(height, CHART_MIN_HEIGHT_IN, CHART_MAX_HEIGHT_IN, CHART_DEFAULT_HEIGHT_IN)
    render_dpi = int(_clamp(dpi, CHART_MIN_DPI, CHART_MAX_DPI, CHART_DEFAULT_DPI))
    base_font = 10.5 if w >= 9 else 9.5

    # Recover numbers stored as text (e.g. "1,299", "$19.99", "+0.88%") so the
    # matplotlib charts plot the same columns the interactive dashboard and the
    # Overview/Correlations screens already treat as numeric. A no-op unless a
    # column actually converts; column names (used as axis labels) are kept.
    df = coerce_numeric_like(df)

    plot_df = df
    if chart_type in ("bar", "count", "box", "violin"):
        plot_df = _limit_categories(plot_df, x, warnings)
    hue = _prepare_hue(plot_df, hue, warnings)
    if hue:
        plot_df = _limit_categories(plot_df, hue, warnings)
    if plot_df.empty:
        raise ChartError("No rows left to plot after filtering.")

    with _RENDER_LOCK:
        with sns.axes_style(cfg["seaborn_style"]), matplotlib.rc_context(_rc(cfg, base_font)):
            if chart_type == "pairplot":
                return _pairplot(plot_df, hue, pal, cfg, title, w, h, render_dpi, warnings)

            fig = Figure(figsize=(w, h), dpi=render_dpi, facecolor=cfg["figure_bg"])
            ax = fig.add_subplot(111)
            numeric_x = bool(x and pd.api.types.is_numeric_dtype(plot_df[x]))
            numeric_y = True

            try:
                if chart_type == "bar":
                    if orientation == "horizontal":
                        _bar(ax, plot_df, x=y, y=x, hue=hue, pal=pal, horizontal=True)
                        numeric_x, numeric_y = True, False
                    else:
                        _bar(ax, plot_df, x=x, y=y, hue=hue, pal=pal, horizontal=False)
                elif chart_type == "line":
                    sns.lineplot(data=plot_df, x=x, y=y, hue=hue, palette=pal if hue else None,
                                 color=None if hue else sns.color_palette(pal, 1)[0],
                                 marker="o", markersize=5, linewidth=2, ax=ax)
                elif chart_type == "scatter":
                    sns.scatterplot(data=plot_df, x=x, y=y, hue=hue, palette=pal if hue else None,
                                    color=None if hue else sns.color_palette(pal, 1)[0],
                                    s=55, alpha=0.85, edgecolor="none", ax=ax)
                elif chart_type == "histogram":
                    sns.histplot(data=plot_df, x=x, hue=hue, palette=pal if hue else None,
                                 color=None if hue else sns.color_palette(pal, 1)[0],
                                 bins=bins, kde=True, ax=ax)
                    numeric_x = True
                elif chart_type == "kde":
                    sns.kdeplot(data=plot_df, x=x, hue=hue, palette=pal if hue else None,
                                color=None if hue else sns.color_palette(pal, 1)[0],
                                fill=True, alpha=0.4, linewidth=1.5, ax=ax)
                    numeric_x = True
                elif chart_type == "box":
                    _cat(sns.boxplot, ax, plot_df, x, y, hue, pal)
                elif chart_type == "violin":
                    _cat(sns.violinplot, ax, plot_df, x, y, hue, pal)
                elif chart_type == "count":
                    _cat(sns.countplot, ax, plot_df, x, None, hue, pal)
                elif chart_type == "area":
                    frame = plot_df[[x, y]].dropna().sort_values(by=x)
                    color = sns.color_palette(pal, 1)[0]
                    ax.fill_between(frame[x], frame[y], alpha=0.35, color=color)
                    ax.plot(frame[x], frame[y], color=color, linewidth=2)
                    ax.set_xlabel(x)
                    ax.set_ylabel(y)
                    numeric_x = pd.api.types.is_numeric_dtype(frame[x])
                elif chart_type == "heatmap":
                    numeric_df = plot_df.select_dtypes(include="number")
                    if numeric_df.shape[1] < 2:
                        raise ChartError("Need at least 2 numeric columns for a heatmap.")
                    if numeric_df.shape[1] > 25:
                        numeric_df = numeric_df.iloc[:, :25]
                        warnings.append("Heatmap limited to the first 25 numeric columns.")
                    cmap = pal if pal in plt.colormaps() else "coolwarm"
                    corr = numeric_df.corr(numeric_only=True)
                    annot = corr.shape[0] <= 12
                    sns.heatmap(corr, annot=annot, fmt=".2f", cmap=cmap, ax=ax, square=True,
                                linewidths=0.4, linecolor=cfg["figure_bg"], vmin=-1, vmax=1,
                                annot_kws={"size": base_font - 2},
                                cbar_kws={"label": "correlation", "shrink": 0.8})
                    ax.grid(False)
                    numeric_x = numeric_y = False
                elif chart_type == "pie":
                    numeric_x = numeric_y = False
                    _pie(ax, plot_df, x, pal, cfg, donut, base_font, warnings)

                if log_scale and chart_type not in ("heatmap", "pie", "pairplot"):
                    axis_values = _log_candidate_values(plot_df, chart_type, x, y, orientation)
                    if _check_log_scale(axis_values, warnings):
                        if chart_type == "bar" and orientation == "horizontal":
                            ax.set_xscale("log")
                        else:
                            ax.set_yscale("log")

                if chart_type not in ("pie", "heatmap"):
                    rotate = _needs_rotation(plot_df, x if orientation == "vertical" else None)
                    _style_axes(ax, cfg, rotate, numeric_y, numeric_x)
                    legend = ax.get_legend()
                    if legend and hue:
                        ax.legend(title=hue, loc="upper left", bbox_to_anchor=(1.01, 1.0),
                                  borderaxespad=0, frameon=True)
                        _style_axes(ax, cfg, rotate, numeric_y, numeric_x)
                else:
                    ax.title.set_color(cfg["text"])

                if title:
                    ax.set_title(title, color=cfg["text"], pad=12)

                fig.tight_layout(pad=1.2)
            except ChartError:
                raise
            except Exception as exc:  # noqa: BLE001 — any plotting failure becomes a clean 400
                raise ChartError(f"Could not generate '{chart_type}' chart: {exc}") from exc

            image = _fig_to_base64(fig, render_dpi)
            thumb = _thumbnail(fig)
            fig.clf()

    return {
        "image": image,
        "thumbnail": thumb,
        "warnings": warnings,
        "width_px": int(w * render_dpi),
        "height_px": int(h * render_dpi),
    }


def _log_candidate_values(df: pd.DataFrame, chart_type: str, x, y, orientation: str):
    if chart_type in ("histogram", "kde", "count"):
        return np.array([1.0])  # y is a count/density: always positive
    if chart_type == "bar" and orientation == "horizontal":
        col = x if not y else y
    else:
        col = y or x
    if col and col in df.columns:
        return df[col]
    return np.array([1.0])


def _bar(ax, df, x, y, hue, pal, horizontal: bool):
    kwargs = dict(data=df, x=x, y=y, ax=ax, errorbar=None)
    if hue:
        sns.barplot(hue=hue, palette=pal, **kwargs)
    else:
        # Passing palette without hue is deprecated in seaborn 0.13 and removed
        # in 0.14. Assigning hue to the category axis keeps the colours.
        cat = y if horizontal else x
        sns.barplot(hue=cat, palette=pal, legend=False, **kwargs)


def _cat(fn, ax, df, x, y, hue, pal):
    kwargs = dict(data=df, x=x, ax=ax)
    if y:
        kwargs["y"] = y
    if hue:
        fn(hue=hue, palette=pal, **kwargs)
    else:
        fn(hue=x, palette=pal, legend=False, **kwargs)


def _pie(ax, df, x, pal, cfg, donut, base_font, warnings):
    counts = df[x].value_counts()
    if counts.empty:
        raise ChartError(f"No values to plot in column '{x}'.")
    if len(counts) > MAX_PIE_SLICES:
        head = counts.head(MAX_PIE_SLICES)
        other = counts.iloc[MAX_PIE_SLICES:].sum()
        counts = pd.concat([head, pd.Series({"Other": other})])
        warnings.append(
            f"'{x}' has many values; the smallest are grouped into 'Other'."
        )
    colors = sns.color_palette(pal, len(counts))
    wedgeprops = {"edgecolor": cfg["figure_bg"], "linewidth": 1.5}
    if donut:
        wedgeprops["width"] = 0.42
    total = counts.sum()
    wedges, _texts, autotexts = ax.pie(
        counts.values,
        labels=None,
        autopct=lambda p: f"{p:.1f}%" if p >= 3 else "",
        colors=colors,
        startangle=90,
        counterclock=False,
        pctdistance=0.78 if donut else 0.65,
        wedgeprops=wedgeprops,
        textprops={"color": cfg["figure_bg"] if not donut else cfg["text"],
                   "fontsize": base_font - 1, "fontweight": "600"},
    )
    for t in autotexts:
        t.set_color("#ffffff" if not donut else cfg["text"])
    ax.legend(
        wedges,
        [f"{label} · {value:,} ({value / total:.0%})" for label, value in counts.items()],
        loc="center left", bbox_to_anchor=(1.0, 0.5), frameon=False,
        labelcolor=cfg["text"], fontsize=base_font - 1,
    )
    if donut:
        ax.text(0, 0, f"{total:,}\ntotal", ha="center", va="center",
                color=cfg["text"], fontsize=base_font + 1, fontweight="600")
    ax.set_ylabel("")
    ax.grid(False)
    ax.axis("equal")


def _pairplot(df, hue, pal, cfg, title, w, h, dpi, warnings) -> dict:
    numeric_df = df.select_dtypes(include=[np.number])
    if numeric_df.shape[1] < 2:
        raise ChartError("Need at least 2 numeric columns for a pair plot.")
    cols = list(numeric_df.columns[:5])
    if numeric_df.shape[1] > 5:
        warnings.append("Pair plot limited to the first 5 numeric columns.")
    use_hue = hue if hue and hue in df.columns else None
    if use_hue and df[use_hue].nunique() > 12:
        warnings.append(f"Hue '{use_hue}' has too many groups for a pair plot; ignored.")
        use_hue = None

    # A numeric hue column is already inside `cols`, so the old
    # `df[cols + [use_hue]]` produced a duplicated label and seaborn raised
    # "Data must be 1-dimensional". De-duplicate and pass vars= explicitly.
    selection = list(dict.fromkeys(cols + ([use_hue] if use_hue else [])))
    try:
        grid = sns.pairplot(
            df[selection].dropna(how="all"),
            vars=cols,
            hue=use_hue,
            palette=pal if use_hue else None,
            corner=True,
            diag_kind="hist",
            height=max(1.6, min(w / max(2, len(cols)), 2.6)),
            plot_kws={"s": 24, "alpha": 0.75, "edgecolor": "none"},
        )
    except Exception as exc:
        raise ChartError(f"Could not generate pair plot: {exc}") from exc

    fig = grid.figure
    fig.set_dpi(dpi)
    fig.patch.set_facecolor(cfg["figure_bg"])
    for a in grid.axes.flat:
        if a is None:
            continue
        a.set_facecolor(cfg["axes_bg"])
        a.tick_params(colors=cfg["muted"], labelsize=8)
        a.xaxis.label.set_color(cfg["text"])
        a.yaxis.label.set_color(cfg["text"])
        for spine in a.spines.values():
            spine.set_color(cfg["grid"])
    if grid.legend is not None:
        for text in grid.legend.get_texts():
            text.set_color(cfg["text"])
        if grid.legend.get_title():
            grid.legend.get_title().set_color(cfg["text"])
    if title:
        fig.suptitle(title, color=cfg["text"], y=1.01, fontsize=13, fontweight="600")

    image = _fig_to_base64(fig, dpi)
    thumb = _thumbnail(fig)
    plt.close(fig)  # pairplot is the one seaborn API that still uses pyplot
    return {
        "image": image,
        "thumbnail": thumb,
        "warnings": warnings,
        "width_px": int(fig.get_figwidth() * dpi),
        "height_px": int(fig.get_figheight() * dpi),
    }
