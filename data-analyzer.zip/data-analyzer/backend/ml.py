"""Lightweight ML helpers (scikit-learn) for the data-analyzer backend.

Three pure functions — train_model, cluster, detect_anomalies — each take a
DataFrame and return a plain, JSON-safe dict (everything is run through
analysis._clean_json, so NaN/inf and numpy scalars never reach FastAPI).
Preconditions raise MLError with a human-readable message; callers turn that
into a 4xx rather than a 500. Row caps mirror analysis.py: a safety valve so
one big upload can't tie up a worker, not a product limit.
"""
import numpy as np
import pandas as pd

from sklearn.cluster import KMeans
from sklearn.compose import ColumnTransformer
from sklearn.decomposition import PCA
from sklearn.ensemble import (
    IsolationForest,
    RandomForestClassifier,
    RandomForestRegressor,
)
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    mean_absolute_error,
    mean_squared_error,
    r2_score,
    silhouette_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.utils.multiclass import unique_labels

from analysis import _clean_json, coerce_numeric_like

# Per-call row caps — keep one request bounded in time and memory.
TRAIN_MAX_ROWS = 50_000
CLUSTER_MAX_ROWS = 20_000
ANOMALY_MAX_ROWS = 50_000

# Feature-engineering guards.
MAX_CATEGORY_CARDINALITY = 50    # drop a categorical wider than this (one-hot explodes)
CLASSIFICATION_MAX_CLASSES = 20  # integer target with <= this many uniques => classify
CLASSIFICATION_MAX_CLASSES_HARD = 100  # reject a classification target wider than this outright

# Output-size caps.
TOP_FEATURES = 15
AVP_SAMPLE = 200          # actual-vs-predicted points returned (regression)
PROJECTION_SAMPLE = 1500  # PCA scatter points returned (cluster)
TOP_ANOMALIES = 20

class MLError(Exception):
    pass


def _round6(x) -> float:
    return round(float(x), 6)


def _is_integer_like(s: pd.Series) -> bool:
    """True for an int column, or a float column holding only whole numbers."""
    if pd.api.types.is_integer_dtype(s):
        return True
    if pd.api.types.is_float_dtype(s):
        vals = s.dropna().to_numpy()
        return vals.size > 0 and bool(np.all(np.mod(vals, 1) == 0))
    return False


# ---------------------------------------------------------------- train_model

def train_model(df: pd.DataFrame, target: str) -> dict:
    """Fit a RandomForest on `target`, auto-picking classification vs
    regression, and report held-out metrics plus feature importances."""
    warnings: list[str] = []

    if target not in df.columns:
        raise MLError(f"Target column '{target}' is not in the dataset.")

    # Recover numbers stored as text ("$1,299", "+0.88%", "1,000") before task
    # detection, so a money/percent target trains as regression instead of being
    # rejected as a 240-distinct "identifier", and text-encoded number features
    # are used numerically — matching Overview, charts, cluster and anomalies.
    df = coerce_numeric_like(df)

    work = df[df[target].notna()].copy()
    if len(work) < 30:
        raise MLError(
            f"Not enough rows with a value in '{target}' to train a model "
            f"(need at least 30)."
        )

    # Task detection: non-numeric (incl. bool) target, or an integer-like one
    # with few distinct values, is classification; anything else regression.
    y_all = work[target]
    numeric_target = (
        pd.api.types.is_numeric_dtype(y_all) and not pd.api.types.is_bool_dtype(y_all)
    )
    if not numeric_target:
        task = "classification"
    elif _is_integer_like(y_all) and y_all.nunique() <= CLASSIFICATION_MAX_CLASSES:
        task = "classification"
    else:
        task = "regression"

    feature_cols = [c for c in work.columns if c != target]

    # Cap rows for speed (after the null-target drop, before splitting).
    if len(work) > TRAIN_MAX_ROWS:
        work = work.sample(TRAIN_MAX_ROWS, random_state=0)
        warnings.append(f"Sampled {TRAIN_MAX_ROWS} rows for training speed.")
    n_rows_used = int(len(work))

    y = work[target]
    X = work[feature_cols]

    # Split features by type; bool is treated as categorical.
    numeric_features = [
        c for c in feature_cols
        if pd.api.types.is_numeric_dtype(X[c]) and not pd.api.types.is_bool_dtype(X[c])
    ]
    categorical_features = [c for c in feature_cols if c not in numeric_features]

    # Drop very-wide categoricals — one-hot would blow up the feature space.
    kept_cat = []
    for c in categorical_features:
        n = int(X[c].nunique(dropna=True))
        if n > MAX_CATEGORY_CARDINALITY:
            warnings.append(
                f"Dropped categorical feature '{c}' ({n} distinct values — "
                f"too wide after one-hot)."
            )
        else:
            kept_cat.append(c)
    categorical_features = kept_cat

    used_features = numeric_features + categorical_features
    if not used_features:
        raise MLError("No usable feature columns to train on.")
    X = X[used_features]

    # Preprocess: median-impute numerics; most-frequent-impute + one-hot cats.
    transformers = []
    if numeric_features:
        transformers.append(("num", SimpleImputer(strategy="median"), numeric_features))
    if categorical_features:
        transformers.append((
            "cat",
            Pipeline([
                ("impute", SimpleImputer(strategy="most_frequent")),
                ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
            ]),
            categorical_features,
        ))
    pre = ColumnTransformer(transformers, remainder="drop")

    if task == "classification":
        result = _fit_classifier(X, y, pre, n_rows_used, used_features, warnings)
    else:
        result = _fit_regressor(X, y, pre, n_rows_used, used_features, warnings)
    return _clean_json(result)


def _importances(model: Pipeline) -> list[dict]:
    """Top features by RandomForest importance, using post-encoding names
    (get_feature_names_out already maps one-hot columns to readable labels)."""
    est = model.named_steps["model"]
    names = model.named_steps["pre"].get_feature_names_out()
    imp = est.feature_importances_
    order = np.argsort(imp)[::-1][:TOP_FEATURES]
    return [{"feature": str(names[i]), "importance": _round6(imp[i])} for i in order]


def _fit_classifier(X, y, pre, n_rows_used, used_features, warnings) -> dict:
    if y.nunique() < 2:
        raise MLError("Need at least 2 classes in the target to train a classifier.")

    # Reject identifier / free-text targets before training. Too many classes
    # (or nearly one class per row) can't be classified: the model is useless
    # and, with singleton classes, a random split can leave the train and test
    # label sets disjoint -- which used to crash confusion_matrix with a 500.
    n_classes = int(y.nunique())
    if n_classes > CLASSIFICATION_MAX_CLASSES_HARD or (
        n_classes > CLASSIFICATION_MAX_CLASSES and n_classes > 0.5 * n_rows_used
    ):
        raise MLError(
            f"Target '{y.name}' has {n_classes} distinct values across {n_rows_used} "
            f"rows — that looks like an identifier or free text, not categories to "
            f"classify. Pick a column with fewer, repeating categories, or a numeric "
            f"column to predict."
        )

    # Stratify only when every class can spare a member for the test split.
    strat = y if int(y.value_counts().min()) >= 2 else None
    try:
        X_tr, X_te, y_tr, y_te = train_test_split(
            X, y, test_size=0.25, random_state=0, stratify=strat
        )
    except ValueError:
        warnings.append("Could not stratify the split; used a random split instead.")
        X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.25, random_state=0)

    model = Pipeline([
        ("pre", pre),
        ("model", RandomForestClassifier(
            n_estimators=200, random_state=0, n_jobs=-1, class_weight="balanced"
        )),
    ])
    model.fit(X_tr, y_tr)
    y_pred = model.predict(X_te)

    # classes_ is the full set the model learned (from y_tr); the confusion
    # matrix must use the labels that actually appear in evaluation, or a class
    # present in y_tr but absent from y_te (or vice-versa) makes it inconsistent
    # — and an empty intersection raises "At least one label ... must be in
    # y_true". unique_labels(y_te, y_pred) is exactly that safe, sorted union.
    classes = model.named_steps["model"].classes_
    eval_labels = unique_labels(y_te, y_pred)
    cm = confusion_matrix(y_te, y_pred, labels=eval_labels)
    metrics = {
        "accuracy": _round6(accuracy_score(y_te, y_pred)),
        "f1_macro": _round6(f1_score(y_te, y_pred, average="macro")),
    }
    return {
        "task": "classification",
        "target": str(y.name),
        "n_rows_used": n_rows_used,
        "n_features": len(used_features),
        "feature_names": [str(c) for c in used_features],
        "metrics": metrics,
        "feature_importances": _importances(model),
        "confusion_matrix": {
            "labels": [str(l) for l in eval_labels],
            "matrix": cm.astype(int).tolist(),
        },
        "actual_vs_predicted": None,
        "classes": [str(l) for l in classes],
        "warnings": warnings,
    }


def _fit_regressor(X, y, pre, n_rows_used, used_features, warnings) -> dict:
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.25, random_state=0)
    model = Pipeline([
        ("pre", pre),
        ("model", RandomForestRegressor(n_estimators=200, random_state=0, n_jobs=-1)),
    ])
    model.fit(X_tr, y_tr)
    y_pred = model.predict(X_te)

    metrics = {
        "r2": _round6(r2_score(y_te, y_pred)),
        "mae": _round6(mean_absolute_error(y_te, y_pred)),
        "rmse": _round6(np.sqrt(mean_squared_error(y_te, y_pred))),  # avoid deprecated squared=
    }
    actual = y_te.to_numpy()[:AVP_SAMPLE]
    pred = y_pred[:AVP_SAMPLE]
    avp = [
        {"actual": _round6(a), "predicted": _round6(p), "residual": _round6(a - p)}
        for a, p in zip(actual, pred)
    ]
    return {
        "task": "regression",
        "target": str(y.name),
        "n_rows_used": n_rows_used,
        "n_features": len(used_features),
        "feature_names": [str(c) for c in used_features],
        "metrics": metrics,
        "feature_importances": _importances(model),
        "confusion_matrix": None,
        "actual_vs_predicted": avp,
        "classes": None,
        "warnings": warnings,
    }


# -------------------------------------------------------------------- cluster

def cluster(df: pd.DataFrame, k: int | None = None) -> dict:
    """KMeans over the numeric columns, with an auto-k silhouette search, a
    per-cluster profile, and a 2-D PCA projection for plotting."""
    warnings: list[str] = []

    # Recover numbers stored as text (e.g. "1,299", "+0.88%") so a scraped or
    # pasted table that looks numeric on screen isn't rejected as non-numeric.
    numeric = coerce_numeric_like(df).select_dtypes(include=[np.number])
    if numeric.shape[1] < 2:
        raise MLError("Need at least 2 numeric columns to find clusters.")
    numeric = numeric.dropna()
    if len(numeric) < 10:
        raise MLError("Not enough complete numeric rows to cluster (need at least 10).")

    if len(numeric) > CLUSTER_MAX_ROWS:
        numeric = numeric.sample(CLUSTER_MAX_ROWS, random_state=0)
        warnings.append(f"Sampled {CLUSTER_MAX_ROWS} rows to fit the clustering.")
    n_rows_used = int(len(numeric))
    features = [str(c) for c in numeric.columns]

    X = StandardScaler().fit_transform(numeric)
    upper = min(8, n_rows_used - 1)  # KMeans needs n_clusters < n_samples

    if k is None:
        auto_k = True
        best_k, best_score, best_labels = None, -np.inf, None
        for kk in range(2, upper + 1):
            lbls = KMeans(n_clusters=kk, random_state=0, n_init=10).fit_predict(X)
            if len(set(lbls)) < 2:
                continue
            score = silhouette_score(X, lbls)
            if score > best_score:
                best_k, best_score, best_labels = kk, score, lbls
        if best_labels is None:  # degenerate data — fall back to k=2
            best_k = 2
            best_labels = KMeans(n_clusters=2, random_state=0, n_init=10).fit_predict(X)
        k_used, labels = best_k, best_labels
    else:
        auto_k = False
        k_used = int(min(max(int(k), 2), upper))
        labels = KMeans(n_clusters=k_used, random_state=0, n_init=10).fit_predict(X)

    try:
        silhouette = _round6(silhouette_score(X, labels)) if len(set(labels)) >= 2 else None
    except Exception:
        silhouette = None

    # Cluster sizes over ALL used rows (not just the projection sample).
    uniq, counts = np.unique(labels, return_counts=True)
    cluster_sizes = [{"cluster": int(c), "size": int(s)} for c, s in zip(uniq, counts)]

    # Per-cluster mean of each numeric feature.
    prof = numeric.copy()
    prof["__cluster__"] = labels
    means = prof.groupby("__cluster__")[list(numeric.columns)].mean()
    profile = []
    for c in sorted(means.index):
        row = {"cluster": int(c)}
        for feat in numeric.columns:
            row[str(feat)] = _round6(means.loc[c, feat])
        profile.append(row)

    # 2-D PCA projection of the scaled data (sampled for plotting).
    explained = None
    projection: list[dict] = []
    try:
        pca = PCA(n_components=2, random_state=0)
        coords = pca.fit_transform(X)
        explained = [_round6(v) for v in pca.explained_variance_ratio_]
        if n_rows_used > PROJECTION_SAMPLE:
            sel = np.sort(
                np.random.RandomState(0).choice(n_rows_used, PROJECTION_SAMPLE, replace=False)
            )
        else:
            sel = np.arange(n_rows_used)
        projection = [
            {"x": _round6(coords[i, 0]), "y": _round6(coords[i, 1]), "cluster": int(labels[i])}
            for i in sel
        ]
    except Exception:
        warnings.append("Could not compute a 2-D projection.")

    return _clean_json({
        "k": int(k_used),
        "n_rows_used": n_rows_used,
        "features": features,
        "silhouette": silhouette,
        "auto_k": auto_k,
        "cluster_sizes": cluster_sizes,
        "profile": profile,
        "projection": projection,
        "explained_variance": explained,
        "warnings": warnings,
    })


# ----------------------------------------------------------- detect_anomalies

def detect_anomalies(df: pd.DataFrame, contamination: float | None = None) -> dict:
    """IsolationForest over the numeric columns; returns the flagged fraction
    and the most anomalous rows (carrying all original columns)."""
    warnings: list[str] = []

    # Same text→number recovery as cluster(), so a column of "$1,299"-style
    # values counts as a feature instead of being silently ignored.
    numeric = coerce_numeric_like(df).select_dtypes(include=[np.number])
    if numeric.shape[1] < 1:
        raise MLError("Need at least 1 numeric column to detect anomalies.")
    numeric = numeric[numeric.notna().all(axis=1)]  # drop rows with any null feature
    if len(numeric) < 20:
        raise MLError(
            "Not enough complete numeric rows to detect anomalies (need at least 20)."
        )

    if len(numeric) > ANOMALY_MAX_ROWS:
        numeric = numeric.sample(ANOMALY_MAX_ROWS, random_state=0)
        warnings.append(f"Sampled {ANOMALY_MAX_ROWS} rows to fit the detector.")
    n_rows_used = int(len(numeric))
    features = [str(c) for c in numeric.columns]

    # "auto" lets IsolationForest pick the cut; an explicit value is clamped.
    if contamination is None:
        contam_param = "auto"
    else:
        contam_param = float(min(max(float(contamination), 0.001), 0.5))

    clf = IsolationForest(random_state=0, n_estimators=200, contamination=contam_param)
    Xv = numeric.to_numpy()
    clf.fit(Xv)
    scores = clf.decision_function(Xv)  # lower = more anomalous
    preds = clf.predict(Xv)             # -1 = anomaly

    flagged = preds == -1
    n_flagged = int(flagged.sum())
    pct_flagged = _round6(n_flagged / n_rows_used * 100)

    # For "auto", report the fraction actually flagged; otherwise the value used.
    if contamination is None:
        contamination_eff = _round6(n_flagged / n_rows_used)
    else:
        contamination_eff = float(contam_param)

    if hasattr(clf, "offset_"):
        threshold = _round6(clf.offset_)
    elif n_flagged:
        threshold = _round6(scores[flagged].max())
    else:
        threshold = _round6(scores.min())

    # Most anomalous rows (lowest score), with every ORIGINAL column.
    order = np.argsort(scores)[:TOP_ANOMALIES]
    idx = numeric.index
    top_anomalies = []
    for pos in order:
        orig = idx[pos]
        try:
            index_out = int(orig)
        except (TypeError, ValueError):
            index_out = str(orig)
        row = df.loc[orig]
        if isinstance(row, pd.DataFrame):  # duplicate index label — take the first
            row = row.iloc[0]
        top_anomalies.append({
            "index": index_out,
            "score": _round6(scores[pos]),
            "values": {str(k): v for k, v in row.to_dict().items()},
        })

    return _clean_json({
        "n_rows_used": n_rows_used,
        "features": features,
        "n_flagged": n_flagged,
        "pct_flagged": pct_flagged,
        "threshold": threshold,
        "contamination": contamination_eff,
        "top_anomalies": top_anomalies,
        "warnings": warnings,
    })

