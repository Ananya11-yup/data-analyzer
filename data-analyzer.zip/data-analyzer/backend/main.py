import io
import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import Depends, FastAPI, File, HTTPException, Query, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from analysis import build_chart_data, build_summary, ChartDataError, compute_correlation, dataframe_preview, query_rows
from charts import (
    CHART_TYPES_IGNORING_Y,
    CHART_TYPES_NEEDING_Y,
    ChartError,
    VALID_CHART_TYPES,
    VALID_PALETTES,
    generate_chart,
)
from config import (
    ALLOWED_UPLOAD_EXT,
    CHART_DEFAULT_DPI,
    CHART_DEFAULT_HEIGHT_IN,
    CHART_DEFAULT_WIDTH_IN,
    CHART_MAX_DPI,
    CHART_MAX_HEIGHT_IN,
    CHART_MAX_WIDTH_IN,
    CHART_MIN_DPI,
    CHART_MIN_HEIGHT_IN,
    CHART_MIN_WIDTH_IN,
    CORS_ORIGINS,
    MAX_SCRAPE_BYTES,
    MAX_UPLOAD_BYTES,
    MAX_UPLOAD_MB,
    SCRAPE_WORST_CASE_SECONDS,
    UPLOAD_CHUNK_BYTES,
)
from parsing import ParsingError, dedupe_columns, parse_pasted_text, parse_upload, scrape_url
from ml import MLError, cluster, detect_anomalies, train_model
from ratelimit import light, scrape as scrape_limit, upload as upload_limit, visualize as visualize_limit
from store import assert_single_worker_safe, store

logger = logging.getLogger("data-analyzer")

PREVIEW_ROWS = 50


@asynccontextmanager
async def lifespan(_app: FastAPI):
    assert_single_worker_safe()
    store.start_sweeper()
    yield
    store.stop_sweeper()


app = FastAPI(title="Data Analyzer API", version="2.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)


@app.exception_handler(Exception)
async def unhandled_exception_handler(_request: Request, exc: Exception):
    """Never leak a stack trace to the client; never return an un-parseable
    body the UI can't show a message from."""
    logger.exception("Unhandled error", exc_info=exc)
    return JSONResponse(status_code=500, content={"detail": "Something went wrong on the server."})


# ---------- Schemas ----------

class ScrapeRequest(BaseModel):
    url: str = Field(min_length=4, max_length=2048)


class PasteRequest(BaseModel):
    text: str = Field(min_length=1, max_length=20_000_000)


class AnalyzeRequest(BaseModel):
    dataset_id: str


class VisualizeRequest(BaseModel):
    dataset_id: str
    chart_type: str
    theme: str = "light"
    x: str | None = None
    y: str | None = None
    hue: str | None = None
    title: str | None = Field(default=None, max_length=200)
    palette: str | None = None
    bins: int | None = Field(default=None, ge=2, le=200)
    orientation: str = "vertical"
    log_scale: bool = False
    donut: bool = False
    width: float | None = Field(default=None, ge=CHART_MIN_WIDTH_IN, le=CHART_MAX_WIDTH_IN)
    height: float | None = Field(default=None, ge=CHART_MIN_HEIGHT_IN, le=CHART_MAX_HEIGHT_IN)
    dpi: int | None = Field(default=None, ge=CHART_MIN_DPI, le=CHART_MAX_DPI)


class ChartDataRequest(BaseModel):
    dataset_id: str
    chart_type: str  # bar | line | area | pie | histogram
    x: str | None = None
    y: str | None = None
    bins: int | None = Field(default=None, ge=2, le=60)


class MLTrainRequest(BaseModel):
    dataset_id: str
    target: str = Field(min_length=1)


class MLClusterRequest(BaseModel):
    dataset_id: str
    k: int | None = Field(default=None, ge=2, le=8)


class MLAnomalyRequest(BaseModel):
    dataset_id: str
    contamination: float | None = Field(default=None, gt=0.0, le=0.5)


class CorrelationRequest(BaseModel):
    dataset_id: str
    method: str = Field(default="pearson", pattern="^(pearson|spearman|kendall)$")


def _ingest_response(df, source: str) -> dict:
    if df is None or df.empty:
        raise HTTPException(400, "Parsed dataset is empty.")
    df = dedupe_columns(df)
    dataset_id = store.put(df, source)
    return {
        "dataset_id": dataset_id,
        "source": source,
        "preview": dataframe_preview(df, rows=PREVIEW_ROWS),
        "preview_rows": min(PREVIEW_ROWS, int(df.shape[0])),
        "shape": {"rows": int(df.shape[0]), "columns": int(df.shape[1])},
        "columns": [str(c) for c in df.columns],
    }


def _load(dataset_id: str):
    df = store.get(dataset_id)
    if df is None:
        raise HTTPException(404, "Dataset not found or expired. Please re-upload.")
    return df


# ---------- Ingest ----------

@app.post("/api/scrape", dependencies=[Depends(scrape_limit)])
def api_scrape(req: ScrapeRequest):
    try:
        df = scrape_url(req.url.strip())
    except ParsingError as exc:
        raise HTTPException(400, str(exc)) from exc
    return _ingest_response(df, source=f"scrape:{req.url.strip()}")


@app.post("/api/upload", dependencies=[Depends(upload_limit)])
async def api_upload(file: UploadFile = File(...)):
    if not file.filename:
        raise HTTPException(400, "A filename is required.")
    name = file.filename.lower()
    ext = "." + name.rsplit(".", 1)[-1] if "." in name else ""
    if ext not in ALLOWED_UPLOAD_EXT:
        raise HTTPException(400, f"Unsupported file type '{ext}'. Allowed: {sorted(ALLOWED_UPLOAD_EXT)}")

    # Stream and abort as soon as the limit is passed. Reading the whole body
    # first meant a 2 GB POST was fully allocated before being rejected.
    chunks: list[bytes] = []
    total = 0
    while True:
        chunk = await file.read(UPLOAD_CHUNK_BYTES)
        if not chunk:
            break
        total += len(chunk)
        if total > MAX_UPLOAD_BYTES:
            del chunks
            raise HTTPException(413, f"File exceeds the {MAX_UPLOAD_MB} MB limit.")
        chunks.append(chunk)
    raw = b"".join(chunks)
    del chunks
    if not raw:
        raise HTTPException(400, "The uploaded file is empty.")

    try:
        df = parse_upload(file.filename, raw)
    except ParsingError as exc:
        raise HTTPException(400, str(exc)) from exc
    return _ingest_response(df, source=f"upload:{file.filename}")


@app.post("/api/paste", dependencies=[Depends(light)])
def api_paste(req: PasteRequest):
    try:
        df = parse_pasted_text(req.text)
    except ParsingError as exc:
        raise HTTPException(400, str(exc)) from exc
    return _ingest_response(df, source="paste")


# ---------- Analyse / rows ----------

@app.post("/api/analyze", dependencies=[Depends(light)])
def api_analyze(req: AnalyzeRequest):
    return build_summary(_load(req.dataset_id))


@app.get("/api/rows/{dataset_id}", dependencies=[Depends(light)])
def api_rows(
    dataset_id: str,
    search: str = Query("", max_length=200),
    sort_by: str | None = None,
    sort_dir: str = Query("asc", pattern="^(asc|desc)$"),
    offset: int = Query(0, ge=0),
    limit: int = Query(25, ge=1, le=200),
):
    """Search / sort / page the full dataset server-side, so the table on
    screen and the exported file always agree."""
    df = _load(dataset_id)
    if sort_by and sort_by not in df.columns:
        raise HTTPException(400, f"Unknown column '{sort_by}'.")
    return query_rows(df, search=search.strip(), sort_by=sort_by, sort_dir=sort_dir,
                      offset=offset, limit=limit)


# ---------- Correlation ----------

@app.post("/api/correlation", dependencies=[Depends(light)])
def api_correlation(req: CorrelationRequest):
    """Correlation matrix by method (pearson/spearman/kendall) with the
    strongest |r| pairs, plus a Cramér's V association table for the
    categorical columns. Text-encoded numbers are recovered first."""
    return compute_correlation(_load(req.dataset_id), method=req.method)


# ---------- Visualise ----------

@app.post("/api/visualize", dependencies=[Depends(visualize_limit)])
def api_visualize(req: VisualizeRequest):
    if req.chart_type not in VALID_CHART_TYPES:
        raise HTTPException(400, f"Unsupported chart type '{req.chart_type}'. Choose one of: {sorted(VALID_CHART_TYPES)}")
    if req.theme not in ("light", "dark"):
        raise HTTPException(400, "theme must be 'light' or 'dark'.")
    if req.orientation not in ("vertical", "horizontal"):
        raise HTTPException(400, "orientation must be 'vertical' or 'horizontal'.")

    df = _load(req.dataset_id)
    try:
        result = generate_chart(
            df,
            chart_type=req.chart_type,
            theme=req.theme,
            x=req.x,
            y=req.y,
            hue=req.hue,
            title=req.title,
            palette=req.palette,
            bins=req.bins,
            orientation=req.orientation,
            log_scale=req.log_scale,
            donut=req.donut,
            width=req.width,
            height=req.height,
            dpi=req.dpi,
        )
    except ChartError as exc:
        raise HTTPException(400, str(exc)) from exc
    return {**result, "chart_type": req.chart_type, "theme": req.theme}


CHART_DATA_TYPES = {"bar", "line", "area", "pie", "histogram"}


@app.post("/api/chart-data", dependencies=[Depends(light)])
def api_chart_data(req: ChartDataRequest):
    """Lightweight JSON aggregation for the interactive dashboard panels —
    no matplotlib render, just pandas groupby/value_counts/histogram, so
    hover charts stay snappy even on a large dataset."""
    if req.chart_type not in CHART_DATA_TYPES:
        raise HTTPException(400, f"'{req.chart_type}' isn't an interactive chart type. Choose one of: {sorted(CHART_DATA_TYPES)}")
    df = _load(req.dataset_id)
    try:
        return build_chart_data(df, chart_type=req.chart_type, x=req.x, y=req.y, bins=req.bins)
    except ChartDataError as exc:
        raise HTTPException(400, str(exc)) from exc


# ---------- Machine learning ----------

@app.post("/api/ml/train", dependencies=[Depends(light)])
def api_ml_train(req: MLTrainRequest):
    """Fit a RandomForest on the chosen target column, auto-detecting
    classification vs regression, and return held-out metrics, the top
    feature importances, and a confusion matrix / actual-vs-predicted sample."""
    df = _load(req.dataset_id)
    try:
        return train_model(df, req.target)
    except MLError as exc:
        raise HTTPException(400, str(exc)) from exc


@app.post("/api/ml/cluster", dependencies=[Depends(light)])
def api_ml_cluster(req: MLClusterRequest):
    """KMeans over the numeric columns (auto-picking k by silhouette when it
    isn't given), with per-cluster sizes/profile and a 2-D PCA projection."""
    df = _load(req.dataset_id)
    try:
        return cluster(df, k=req.k)
    except MLError as exc:
        raise HTTPException(400, str(exc)) from exc


@app.post("/api/ml/anomalies", dependencies=[Depends(light)])
def api_ml_anomalies(req: MLAnomalyRequest):
    """IsolationForest over the numeric columns; returns the flagged fraction
    and the most anomalous rows."""
    df = _load(req.dataset_id)
    try:
        return detect_anomalies(df, contamination=req.contamination)
    except MLError as exc:
        raise HTTPException(400, str(exc)) from exc


# ---------- Export / metadata ----------

@app.get("/api/export/{dataset_id}", dependencies=[Depends(light)])
def api_export(dataset_id: str, fmt: str = "csv"):
    df = _load(dataset_id)
    if fmt == "json":
        payload = df.to_json(orient="records")
        media_type, filename = "application/json", f"{dataset_id}.json"
    elif fmt == "csv":
        buf = io.StringIO()
        df.to_csv(buf, index=False)
        payload = buf.getvalue()
        media_type, filename = "text/csv", f"{dataset_id}.csv"
    else:
        raise HTTPException(400, "fmt must be 'csv' or 'json'.")

    return StreamingResponse(
        iter([payload]),
        media_type=media_type,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.delete("/api/dataset/{dataset_id}", dependencies=[Depends(light)])
def api_delete_dataset(dataset_id: str):
    """Drop a dataset from the in-memory store now (the UI's Reset), instead of
    waiting for its sliding 1-hour TTL. 404 if it was already gone."""
    if not store.delete(dataset_id):
        raise HTTPException(404, "Dataset not found or already gone.")
    return {"deleted": dataset_id}


@app.get("/api/limits")
def api_limits():
    """The UI reads this so its timeouts, size hints and chart-size
    sliders always match the server instead of hard-coding stale numbers."""
    return {
        "max_upload_mb": MAX_UPLOAD_MB,
        "max_scrape_mb": round(MAX_SCRAPE_BYTES / (1024 * 1024), 1),
        "scrape_worst_case_seconds": SCRAPE_WORST_CASE_SECONDS,
        "preview_rows": PREVIEW_ROWS,
        "palettes": VALID_PALETTES,
        "chart_types": sorted(VALID_CHART_TYPES),
        "chart_types_needing_y": sorted(CHART_TYPES_NEEDING_Y),
        "chart_types_ignoring_y": sorted(CHART_TYPES_IGNORING_Y),
        "chart_size": {
            "min_width": CHART_MIN_WIDTH_IN, "max_width": CHART_MAX_WIDTH_IN,
            "default_width": CHART_DEFAULT_WIDTH_IN,
            "min_height": CHART_MIN_HEIGHT_IN, "max_height": CHART_MAX_HEIGHT_IN,
            "default_height": CHART_DEFAULT_HEIGHT_IN,
            "min_dpi": CHART_MIN_DPI, "max_dpi": CHART_MAX_DPI, "default_dpi": CHART_DEFAULT_DPI,
        },
    }


@app.get("/api/health")
def health():
    return {"status": "ok", **store.stats()}


# ---------- Static UI (served same-origin, so the browser makes no cross-origin
# request and CORS never enters the picture) ----------
#
# The vanilla single-page UI lives in <repo>/web and is mounted LAST, at "/",
# so every /api/* route above keeps priority; only non-API paths ("/",
# "/styles.css", "/js/…") fall through to the static files. The app uses a
# hash router (#/overview, #/table, …), so the server only ever serves
# index.html and its assets — no SPA history-fallback is needed. Mounting is
# guarded so the API still boots if the web/ dir is absent (e.g. API-only use).
_WEB_DIR = Path(__file__).resolve().parent.parent / "web"
if _WEB_DIR.is_dir():
    app.mount("/", StaticFiles(directory=str(_WEB_DIR), html=True), name="web")
else:  # pragma: no cover - only in an API-only checkout
    logger.warning("web/ directory not found at %s; UI will not be served.", _WEB_DIR)
