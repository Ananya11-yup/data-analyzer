"""In-memory dataset store keyed by dataset_id.

Single-process only by design: with more than one uvicorn worker the dataset
created on worker A is invisible to worker B, which shows up as random 404s.
`assert_single_worker_safe()` is called at startup so that failure mode is a
loud warning instead of an unreproducible bug report.
"""
import os
import threading
import time
import uuid
import warnings
from typing import Optional

import pandas as pd

from config import DATASET_TTL_SECONDS, STORE_SWEEP_INTERVAL_SECONDS


class DatasetStore:
    def __init__(self):
        self._lock = threading.Lock()
        self._data: dict[str, dict] = {}
        self._stop = threading.Event()
        self._sweeper: threading.Thread | None = None

    # --- lifecycle ---

    def start_sweeper(self) -> None:
        if self._sweeper and self._sweeper.is_alive():
            return
        self._stop.clear()
        self._sweeper = threading.Thread(target=self._sweep_loop, daemon=True, name="store-sweeper")
        self._sweeper.start()

    def stop_sweeper(self) -> None:
        self._stop.set()

    def _sweep_loop(self) -> None:
        while not self._stop.wait(STORE_SWEEP_INTERVAL_SECONDS):
            self.evict_expired()

    # --- api ---

    def put(self, df: pd.DataFrame, source: str) -> str:
        dataset_id = str(uuid.uuid4())
        now = time.time()
        with self._lock:
            self._data[dataset_id] = {
                "df": df,
                "source": source,
                "created_at": now,
                "last_access": now,
            }
        return dataset_id

    def get(self, dataset_id: str) -> Optional[pd.DataFrame]:
        """Fetch and refresh the TTL. Expiry is checked inside the same lock
        acquisition as the read, so an entry cannot expire between the two."""
        now = time.time()
        with self._lock:
            entry = self._data.get(dataset_id)
            if entry is None:
                return None
            if now - entry["last_access"] > DATASET_TTL_SECONDS:
                del self._data[dataset_id]
                return None
            entry["last_access"] = now  # sliding TTL: active work never expires
            return entry["df"]

    def delete(self, dataset_id: str) -> bool:
        """Drop one dataset immediately (Reset / explicit delete) instead of
        waiting for its TTL to lapse. True if an entry was actually removed."""
        with self._lock:
            return self._data.pop(dataset_id, None) is not None

    def evict_expired(self) -> int:
        now = time.time()
        with self._lock:
            expired = [
                k for k, v in self._data.items()
                if now - v["last_access"] > DATASET_TTL_SECONDS
            ]
            for k in expired:
                del self._data[k]
        return len(expired)

    def stats(self) -> dict:
        with self._lock:
            return {"datasets": len(self._data), "ttl_seconds": DATASET_TTL_SECONDS}

    def purge_all(self) -> None:
        with self._lock:
            self._data.clear()


def assert_single_worker_safe() -> None:
    workers = os.environ.get("WEB_CONCURRENCY") or os.environ.get("UVICORN_WORKERS")
    try:
        count = int(workers) if workers else 1
    except ValueError:
        count = 1
    if count > 1:
        warnings.warn(
            f"DatasetStore is in-memory but {count} workers are configured. "
            "Datasets will 404 at random. Run a single worker, or move the "
            "store behind Redis/SQLite before scaling out.",
            RuntimeWarning,
            stacklevel=2,
        )


store = DatasetStore()
