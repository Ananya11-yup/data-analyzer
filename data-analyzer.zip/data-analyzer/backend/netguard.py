"""SSRF protection for the scrape path.

Three things the naive version got wrong and this module fixes:

1. Blocking by string prefix ("127.", "10.") misses 172.16/12, CGNAT, every
   IPv6 form and every alternative literal encoding (2130706433, 0x7f.0.0.1,
   127.1). Here every candidate is parsed with the ipaddress module instead.
2. Validating the hostname and then letting requests resolve it again is a
   TOCTOU hole (DNS rebinding). Here we resolve once, validate *every* returned
   address, and pin the connection to the address we validated.
3. Redirects were followed by requests itself, so the blocklist never saw the
   redirect target. Callers here follow hops manually and re-validate each one.
"""
import ipaddress
import socket
import threading
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse

from config import (
    BLOCKED_HOST_EXACT,
    BLOCKED_HOST_SUFFIXES,
    SCRAPE_DNS_TIMEOUT_SECONDS,
)


class BlockedHostError(Exception):
    """Host resolves to an address we refuse to fetch."""


class ResolutionError(Exception):
    """Host could not be resolved (transient/DNS problem, not a policy block)."""


_resolver_pool = ThreadPoolExecutor(max_workers=8, thread_name_prefix="dns")

# host -> ip, consulted by the patched getaddrinfo below. Thread-local so
# concurrent scrapes never see each other's pins.
_pins = threading.local()
_real_getaddrinfo = socket.getaddrinfo


def _patched_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    pinned = getattr(_pins, "map", None)
    if pinned:
        ip = pinned.get(str(host).lower())
        if ip:
            # Feed the already-validated literal back to urllib3. TLS still sees
            # the real hostname via SNI because the URL is left untouched.
            return _real_getaddrinfo(ip, port, family, type, proto, flags)
    return _real_getaddrinfo(host, port, family, type, proto, flags)


socket.getaddrinfo = _patched_getaddrinfo


class pin_host:
    """Context manager: force `host` to resolve to `ip` on this thread only."""

    def __init__(self, host: str, ip: str):
        self._host = host.lower()
        self._ip = ip

    def __enter__(self):
        if not hasattr(_pins, "map") or _pins.map is None:
            _pins.map = {}
        self._previous = _pins.map.get(self._host)
        _pins.map[self._host] = self._ip
        return self

    def __exit__(self, *exc):
        if self._previous is None:
            _pins.map.pop(self._host, None)
        else:
            _pins.map[self._host] = self._previous
        return False


def is_forbidden_ip(ip: ipaddress._BaseAddress) -> bool:
    if isinstance(ip, ipaddress.IPv6Address) and ip.ipv4_mapped:
        ip = ip.ipv4_mapped
    if isinstance(ip, ipaddress.IPv4Address):
        # 100.64.0.0/10 CGNAT is not covered by is_private on older Pythons.
        if ip in ipaddress.ip_network("100.64.0.0/10"):
            return True
    return bool(
        ip.is_private
        or ip.is_loopback
        or ip.is_link_local
        or ip.is_reserved
        or ip.is_multicast
        or ip.is_unspecified
    )


def _resolve_all(host: str) -> list[str]:
    def _lookup():
        infos = _real_getaddrinfo(host, None, 0, socket.SOCK_STREAM)
        return [info[4][0] for info in infos]

    try:
        return _resolver_pool.submit(_lookup).result(timeout=SCRAPE_DNS_TIMEOUT_SECONDS)
    except TimeoutError:
        raise ResolutionError(f"DNS lookup for '{host}' timed out.")
    except socket.gaierror as exc:
        raise ResolutionError(f"Could not resolve host '{host}'.") from exc


def validate_url(url: str) -> tuple[str, str]:
    """Validate a URL and return (hostname, validated_ip_to_pin).

    Raises BlockedHostError for policy refusals and ResolutionError for DNS
    problems, so callers can tell a blocked host from an unreachable one.
    """
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise BlockedHostError("URL must start with http:// or https://")
    host = (parsed.hostname or "").strip().lower().rstrip(".")
    if not host:
        raise BlockedHostError("Invalid URL: no hostname.")
    if host in BLOCKED_HOST_EXACT or host.endswith(BLOCKED_HOST_SUFFIXES):
        raise BlockedHostError("This host is not allowed (SSRF protection).")

    # Literal address in any encoding (decimal, hex, short form, IPv6).
    try:
        literal = ipaddress.ip_address(host)
    except ValueError:
        literal = None
    if literal is not None:
        if is_forbidden_ip(literal):
            raise BlockedHostError("This address is not allowed (SSRF protection).")
        return host, str(literal)

    addresses = _resolve_all(host)
    if not addresses:
        raise ResolutionError(f"Could not resolve host '{host}'.")
    parsed_addrs = []
    for addr in addresses:
        try:
            parsed_addrs.append(ipaddress.ip_address(addr.split("%", 1)[0]))
        except ValueError:
            continue
    if not parsed_addrs:
        raise ResolutionError(f"Could not resolve host '{host}'.")
    # Reject if ANY answer is internal — a mixed public/private response is the
    # classic rebinding trick.
    for ip in parsed_addrs:
        if is_forbidden_ip(ip):
            raise BlockedHostError("This host is not allowed (SSRF protection).")
    # Prefer IPv4. Many consumer machines (Windows especially) publish/return an
    # AAAA record first but have no working IPv6 route, so pinning the
    # first-returned address — often IPv6 — dead-hangs until the connect timeout.
    # Every address here already passed the SSRF checks above; we only choose
    # which validated one to connect to. An IPv6-only host still returns IPv6.
    ordered = sorted(parsed_addrs, key=lambda a: a.version)  # 4 before 6
    return host, str(ordered[0])
