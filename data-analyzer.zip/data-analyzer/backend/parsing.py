import io
import json
import re
import time
import urllib.robotparser
from collections import defaultdict
from urllib.parse import urljoin, urlparse

import pandas as pd
import requests
from bs4 import BeautifulSoup
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from config import (
    MAX_SCRAPE_BYTES,
    SCRAPE_TOTAL_BUDGET_SECONDS,
    RESPECT_ROBOTS_TXT,
    SCRAPE_CONNECT_TIMEOUT_SECONDS,
    SCRAPE_MAX_REDIRECTS,
    SCRAPE_MAX_RETRIES,
    SCRAPE_READ_TIMEOUT_SECONDS,
)
from netguard import BlockedHostError, ResolutionError, pin_host, validate_url

try:  # brotli is in requirements.txt; degrade honestly if it is missing
    import brotli  # noqa: F401

    _BROTLI = True
except ImportError:  # pragma: no cover
    _BROTLI = False

_ACCEPT_ENCODING = "gzip, deflate, br" if _BROTLI else "gzip, deflate"

# A real, current browser UA. robots.txt compliance (checked below) is the
# actual polite/consent mechanism; a User-Agent that announces itself as a
# bot doesn't make scraping more ethical, it just gets silently throttled or
# hung by Cloudflare/Akamai/PerimeterX-style bot detection on most real
# e-commerce and news sites — which looks identical to "the site is slow"
# from here, but is really "the site is refusing us specifically".
BROWSER_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": _ACCEPT_ENCODING,
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
}

HTML_CONTENT_TYPES = (
    "text/html",
    "application/xhtml+xml",
    "application/xml",
    "text/xml",
    "text/plain",
)

JS_HINT = (
    "This site likely renders its content with JavaScript after load, so a "
    "plain fetch only sees an empty shell — try 'Upload File' or 'Paste Data' "
    "instead."
)


class ParsingError(Exception):
    pass


# ---------- Shared session (built once, so pooling actually happens) ----------

def _build_session() -> requests.Session:
    session = requests.Session()
    retry = Retry(
        total=SCRAPE_MAX_RETRIES,
        backoff_factor=0.8,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=("GET", "HEAD"),
        redirect=0,  # we follow redirects ourselves, re-validating each hop
        raise_on_redirect=False,
    )
    adapter = HTTPAdapter(max_retries=retry, pool_connections=10, pool_maxsize=20)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    session.headers.update(BROWSER_HEADERS)
    return session


SESSION = _build_session()


# ---------- Column hygiene ----------

def dedupe_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Make column labels unique and string-typed (a, a.1, a.2 …).

    Duplicate labels silently lose data in `to_dict(orient="records")` and
    collide as table column keys in the UI, so they are fixed once, here,
    at ingest — the stored frame, the preview and the column list then agree.
    """
    seen: dict[str, int] = {}
    out = []
    for raw in df.columns:
        name = str(raw).strip() or "column"
        if name in seen:
            seen[name] += 1
            name = f"{name}.{seen[name]}"
            while name in seen:
                seen[name] = seen.get(name, 0) + 1
                name = f"{name}.{seen[name]}"
        seen.setdefault(name, 0)
        out.append(name)
    df = df.copy()
    df.columns = out
    return df


# ---------- Upload / Paste ----------

def parse_upload(filename: str, raw: bytes) -> pd.DataFrame:
    name = (filename or "").lower()
    try:
        if name.endswith(".csv"):
            return dedupe_columns(pd.read_csv(io.BytesIO(raw)))
        if name.endswith(".tsv"):
            return dedupe_columns(pd.read_csv(io.BytesIO(raw), sep="\t"))
        if name.endswith((".xlsx", ".xls")):
            return dedupe_columns(pd.read_excel(io.BytesIO(raw)))
    except Exception as exc:
        raise ParsingError(f"Could not parse '{filename}': {exc}") from exc
    raise ParsingError("Unsupported file type. Use .csv, .tsv, .xlsx or .xls")


def parse_pasted_text(text: str) -> pd.DataFrame:
    text = (text or "").strip()
    if not text:
        raise ParsingError("Pasted data is empty.")

    if text[0] in "[{":
        try:
            obj = json.loads(text)
            df = pd.DataFrame(obj)
            if not df.empty:
                return dedupe_columns(df)
        except Exception:
            pass

    first_line = text.splitlines()[0]
    sep = "\t" if "\t" in first_line else ("," if "," in first_line else None)
    try:
        if sep:
            return dedupe_columns(pd.read_csv(io.StringIO(text), sep=sep))
        return dedupe_columns(pd.read_csv(io.StringIO(text), sep=r"\s+", engine="python"))
    except Exception as exc:
        raise ParsingError(f"Could not parse pasted data: {exc}") from exc


# ---------- Scraping ----------

def _robots_allows(url: str) -> bool:
    if not RESPECT_ROBOTS_TXT:
        return True
    parsed = urlparse(url)
    robots_url = f"{parsed.scheme}://{parsed.netloc}/robots.txt"
    try:
        host, ip = validate_url(robots_url)
    except (BlockedHostError, ResolutionError):
        return True
    try:
        with pin_host(host, ip):
            resp = SESSION.get(robots_url, timeout=(SCRAPE_CONNECT_TIMEOUT_SECONDS, 8),
                               allow_redirects=False)
        if resp.status_code >= 400:
            return True  # no robots.txt published = no restriction
        parser = urllib.robotparser.RobotFileParser()
        parser.parse(resp.text.splitlines())
        return parser.can_fetch(BROWSER_HEADERS["User-Agent"], url)
    except requests.RequestException:
        return True  # never fail a scrape because robots.txt was unreachable


def _check_content_type(resp: requests.Response) -> None:
    ctype = (resp.headers.get("Content-Type") or "").split(";")[0].strip().lower()
    if ctype and not any(ctype.startswith(t) for t in HTML_CONTENT_TYPES):
        raise ParsingError(
            f"That URL returned '{ctype}', not an HTML page. Point at a page "
            "with a table on it, or use 'Upload File' for data files."
        )


def _fetch(url: str) -> bytes:
    """Fetch a URL, following redirects manually and re-validating every hop,
    under one overall time budget."""
    current = url
    deadline = time.monotonic() + SCRAPE_TOTAL_BUDGET_SECONDS
    for _ in range(SCRAPE_MAX_REDIRECTS + 1):
        remaining = deadline - time.monotonic()
        if remaining <= 1:
            raise ParsingError(f"Gave up after {SCRAPE_TOTAL_BUDGET_SECONDS}s. {JS_HINT}")
        try:
            host, ip = validate_url(current)
        except BlockedHostError as exc:
            raise ParsingError(str(exc)) from exc
        except ResolutionError as exc:
            raise ParsingError(
                f"{exc} Check the address, or try again in a moment."
            ) from exc

        try:
            with pin_host(host, ip):
                resp = SESSION.get(
                    current,
                    timeout=(
                        min(SCRAPE_CONNECT_TIMEOUT_SECONDS, remaining),
                        min(SCRAPE_READ_TIMEOUT_SECONDS, remaining),
                    ),
                    stream=True,
                    allow_redirects=False,
                )
                if resp.is_redirect or resp.is_permanent_redirect:
                    location = resp.headers.get("Location")
                    resp.close()
                    if not location:
                        raise ParsingError("The site redirected without a target.")
                    current = urljoin(current, location)
                    continue

                resp.raise_for_status()
                _check_content_type(resp)
                content = resp.raw.read(MAX_SCRAPE_BYTES + 1, decode_content=True)
                resp.close()
                if len(content) > MAX_SCRAPE_BYTES:
                    raise ParsingError(
                        f"Page is larger than the {MAX_SCRAPE_BYTES // (1024 * 1024)} MB scrape cap."
                    )
                if not content.strip():
                    raise ParsingError(f"That page returned an empty body. {JS_HINT}")
                return content
        except requests.ConnectTimeout as exc:
            raise ParsingError(
                "Couldn't connect to the site in time. It may be down, blocking "
                "automated requests, or unreachable from this network — check the "
                "URL, or use 'Upload File' / 'Paste Data' instead."
            ) from exc
        except requests.ReadTimeout as exc:
            raise ParsingError(
                "The site took too long to send the page. Large sites often load "
                "their listings with JavaScript after the page loads, which a "
                "plain HTTP fetch can't execute — try a specific search/category "
                "URL, or use 'Upload File' / 'Paste Data' instead."
            ) from exc
        except requests.RequestException as exc:
            raise ParsingError(f"Failed to fetch URL: {exc}") from exc

    raise ParsingError("Too many redirects.")


# ---------- Card / listing heuristic ----------

_PRICE_RE = re.compile(r"^[^\d]{0,3}[\d][\d,.\s]*[^\d]{0,4}$")


def _card_fields(el) -> dict:
    """Pull named fields out of one repeated card, falling back to positional
    text only for whatever is left over."""
    row: dict[str, str] = {}

    heading = el.find(["h1", "h2", "h3", "h4", "h5"])
    link = el.find("a", href=True)
    title = None
    if heading and heading.get_text(strip=True):
        title = heading.get_text(strip=True)
    elif link and link.get_text(strip=True):
        title = link.get_text(strip=True)
    if title:
        row["title"] = title[:300]
    if link:
        row["href"] = link["href"][:500]

    texts = [t.strip() for t in el.stripped_strings if t.strip()]
    texts = [t for t in texts if t != title]

    price = next((t for t in texts if _PRICE_RE.match(t) and any(c.isdigit() for c in t)), None)
    if price:
        row["value"] = price[:80]
        texts = [t for t in texts if t != price]

    for i, val in enumerate(texts[:6]):
        row[f"text_{i + 1}"] = val[:200]
    return row


def _extract_repeated_cards(soup: BeautifulSoup) -> pd.DataFrame | None:
    """Heuristic fallback for card/listing pages with no <table> markup.

    Groups elements sharing a tag+class signature and treats the largest
    repeating group as a list of items. Output is best-effort: `title`, `href`
    and `value` are named; anything else lands in text_N and may not mean the
    same thing on every row.
    """
    groups: dict[tuple, list] = defaultdict(list)
    for tag in soup.find_all(["article", "li", "div", "section", "tr"], limit=6000):
        classes = tag.get("class")
        if not classes:
            continue
        if len(tag.get_text(strip=True)) < 3:
            continue
        groups[(tag.name, tuple(sorted(classes)))].append(tag)

    candidates = [g for g in groups.values() if len(g) >= 5]
    if not candidates:
        return None
    best = max(candidates, key=len)

    rows = [f for f in (_card_fields(el) for el in best[:500]) if f]
    if len(rows) < 3:
        return None
    df = pd.DataFrame(rows).dropna(axis=1, how="all")
    # Drop columns that are populated on fewer than a third of rows — those are
    # the ragged positional fields that made the old output unusable.
    keep = [c for c in df.columns if df[c].notna().mean() >= 0.34]
    if keep:
        df = df[keep]
    return dedupe_columns(df) if not df.empty else None


def scrape_url(url: str) -> pd.DataFrame:
    if not _robots_allows(url):
        raise ParsingError(
            "This site's robots.txt asks automated clients not to fetch that "
            "page. Try 'Upload File' or 'Paste Data' instead."
        )
    content = _fetch(url)

    # 1) Real HTML <table> elements.
    try:
        tables = pd.read_html(io.BytesIO(content))
        if tables:
            best = max(tables, key=lambda t: t.shape[0] * t.shape[1])
            if best.shape[0] >= 1:
                return dedupe_columns(best)
    except ValueError:
        pass  # "No tables found" — expected, fall through
    except ImportError:
        raise ParsingError("No HTML parser backend is installed on the server (lxml).")
    except Exception:
        pass  # malformed markup, bad encoding — the fallbacks below still work

    try:
        soup = BeautifulSoup(content, "lxml")
    except Exception:
        soup = BeautifulSoup(content, "html.parser")

    # 2) Repeated "card" structures.
    card_df = _extract_repeated_cards(soup)
    if card_df is not None:
        return card_df

    # 3) Generic text/link extraction.
    rows = []
    for tag in soup.find_all(["h1", "h2", "h3", "p", "li", "a"]):
        text = tag.get_text(strip=True)
        if not text:
            continue
        rows.append({
            "tag": tag.name,
            "text": text[:500],
            "href": tag.get("href") if tag.name == "a" else None,
        })
    if not rows:
        raise ParsingError(f"No tables or extractable text/links found on this page. {JS_HINT}")
    return dedupe_columns(pd.DataFrame(rows))
