"""Central configuration. Every value here is env-overridable and documented
in .env.example — nothing security-relevant is hidden in the source only.
"""
import os


def _int_env(name: str, default: int, minimum: int = 1) -> int:
    try:
        return max(minimum, int(os.environ.get(name, str(default))))
    except (TypeError, ValueError):
        return default


# --- Upload limits ---
# Generous local default. The body is still streamed and aborted the moment
# this is passed, so a large cap costs nothing until a file actually uses it.
MAX_UPLOAD_MB = _int_env("UPLOAD_MAX_MB", 500)
MAX_UPLOAD_BYTES = MAX_UPLOAD_MB * 1024 * 1024
UPLOAD_CHUNK_BYTES = 1 << 20  # 1 MiB streaming chunk

# --- Scrape limits ---
# (connect_timeout, read_timeout) per attempt.
SCRAPE_CONNECT_TIMEOUT_SECONDS = _int_env("SCRAPE_CONNECT_TIMEOUT", 8)
SCRAPE_READ_TIMEOUT_SECONDS = _int_env("SCRAPE_READ_TIMEOUT", 130)
SCRAPE_MAX_RETRIES = _int_env("SCRAPE_MAX_RETRIES", 1, minimum=0)
SCRAPE_MAX_REDIRECTS = _int_env("SCRAPE_MAX_REDIRECTS", 4, minimum=0)
SCRAPE_DNS_TIMEOUT_SECONDS = _int_env("SCRAPE_DNS_TIMEOUT", 5)
MAX_SCRAPE_BYTES = _int_env("SCRAPE_MAX_BYTES", 5 * 1024 * 1024)
# Hard ceiling on one scrape, redirects and retries included. Without it the
# theoretical worst case is redirects x retries x per-attempt timeout, which is
# minutes — long enough that the browser gives up while the server works on.
SCRAPE_TOTAL_BUDGET_SECONDS = _int_env("SCRAPE_TOTAL_BUDGET", 150)
RESPECT_ROBOTS_TXT = os.environ.get("RESPECT_ROBOTS_TXT", "true").lower() != "false"

# Worst-case server time for a scrape; the UI uses /api/limits to set its
# own timeout above this, so the browser never gives up before the server does.
SCRAPE_WORST_CASE_SECONDS = min(
    SCRAPE_TOTAL_BUDGET_SECONDS,
    (SCRAPE_MAX_REDIRECTS + 1)
    * (SCRAPE_MAX_RETRIES + 1)
    * (SCRAPE_CONNECT_TIMEOUT_SECONDS + SCRAPE_READ_TIMEOUT_SECONDS),
)

# --- Dataset store ---
DATASET_TTL_SECONDS = _int_env("DATASET_TTL_SECONDS", 60 * 60)  # sliding, 1 hour
STORE_SWEEP_INTERVAL_SECONDS = _int_env("STORE_SWEEP_INTERVAL", 120)

# --- Analysis guards (a safety valve, not a product limit: they only bite on
#     very large data so one upload can't hang a worker; both env-overridable) ---
ANALYSIS_MAX_ROWS = _int_env("ANALYSIS_MAX_ROWS", 2_000_000)
ANALYSIS_MAX_CORR_COLS = _int_env("ANALYSIS_MAX_CORR_COLS", 200)

# --- Chart size bounds (inches / dpi) ---
CHART_MIN_WIDTH_IN, CHART_MAX_WIDTH_IN = 4.0, 20.0
CHART_MIN_HEIGHT_IN, CHART_MAX_HEIGHT_IN = 3.0, 14.0
CHART_DEFAULT_WIDTH_IN, CHART_DEFAULT_HEIGHT_IN = 10.0, 6.0
CHART_MIN_DPI, CHART_MAX_DPI, CHART_DEFAULT_DPI = 72, 200, 110

# --- Rate limiting (per client IP, sliding window, per process) ---
# OFF by default: this app ships to run on localhost for a single user, where
# per-IP throttling only gets in the way. Set RATE_LIMIT_ENABLED=true (and see
# the per-endpoint buckets below) BEFORE exposing it beyond localhost.
RATE_LIMIT_ENABLED = os.environ.get("RATE_LIMIT_ENABLED", "false").lower() == "true"
RATE_LIMIT_WINDOW_SECONDS = _int_env("RATE_LIMIT_WINDOW", 60)
# Separate buckets per endpoint. These used to share one "heavy" bucket, so
# clicking through chart options (which calls /api/visualize on every change
# during live preview) burned the same quota as /api/scrape — a few minutes
# of chart tinkering could 429 a completely unrelated URL paste right after.
RATE_LIMIT_SCRAPE = _int_env("RATE_LIMIT_SCRAPE", 20)      # network fetch, abuse-prone
RATE_LIMIT_UPLOAD = _int_env("RATE_LIMIT_UPLOAD", 20)      # disk + parse cost
RATE_LIMIT_VISUALIZE = _int_env("RATE_LIMIT_VISUALIZE", 90)  # local render, live-preview calls this a lot
RATE_LIMIT_LIGHT = _int_env("RATE_LIMIT_LIGHT", 120)       # analyze / rows / export

ALLOWED_UPLOAD_EXT = {".csv", ".xlsx", ".xls", ".tsv"}

# --- CORS ---
# The UI is now served same-origin by this app (StaticFiles mount at "/"), so
# browser requests to /api are same-origin and CORS never engages for the normal
# setup. This list still matters only for an alternate-origin client — e.g.
# opening web/index.html straight off disk (Origin "null") or pointing a dev
# server elsewhere at this API — so the mechanism is kept intact and unchanged.
_raw_origins = os.environ.get(
    "CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173"
)
CORS_ORIGINS = [o.strip() for o in _raw_origins.split(",") if o.strip()]
# credentials + wildcard is rejected by every browser; drop it rather than ship
# a config that silently never works.
CORS_ORIGINS = [o for o in CORS_ORIGINS if o != "*"] or ["http://localhost:5173"]

# Hostnames refused before DNS even runs. IP-range blocking is done properly in
# netguard.py with the ipaddress module — never by string prefix.
BLOCKED_HOST_EXACT = {
    "localhost",
    "localhost.localdomain",
    "metadata.google.internal",
    "metadata.goog",
    "instance-data",
}
BLOCKED_HOST_SUFFIXES = (".localhost", ".local", ".internal")
