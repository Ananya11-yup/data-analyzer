# Fix log

Every finding from `data-analyzer-error-report.xlsx` (48 items), plus the chart
and UI work requested alongside it.

Verification: `cd backend && python -m pytest -q` → **57 passed**.
`cd frontend && npx tsc -b && npx vite build` → **0 errors**.
`cd frontend && npm test` → **21 passed** (Vitest + Testing Library).
CI (`.github/workflows/ci.yml`) runs all three on every push/PR.

---

## Security

| ID | Status | What changed |
|----|--------|--------------|
| SEC-01 | Fixed | `allow_redirects=False`. `_fetch` follows hops itself (max 4) and re-runs `validate_url` on every `Location`. Test: `test_redirect_to_a_blocked_host_is_refused` asserts the metadata endpoint is never fetched. |
| SEC-02 | Fixed | String-prefix blocklist deleted. `netguard.is_forbidden_ip` uses `ipaddress`: private, loopback, link-local, reserved, multicast, unspecified, `100.64.0.0/10`, IPv6 `fc00::/7`, `fe80::/10`, and IPv4-mapped `::ffff:` forms. `172.17.0.1` now refused. |
| SEC-03 | Fixed | `socket.getaddrinfo` (all records, not `gethostbyname`'s first), every address validated, then the connection is **pinned** to the validated IP via a thread-local resolver hook — so validation and connection cannot resolve differently. |
| SEC-04 | Fixed | Hostnames are parsed as IP literals first (`ipaddress.ip_address`), which catches `2130706433`, `0x7f.0.0.1`, `127.1`, `[::1]` in any encoding. No hostname text is ever prefix-matched, so `0.example.com` is no longer falsely blocked. |
| SEC-05 | Fixed | `[o.strip() for o in raw.split(',') if o.strip()]`, and `"*"` is dropped because it is invalid with `allow_credentials=True`. |
| SEC-06 | Partly fixed | Per-IP sliding-window rate limiting added (`ratelimit.py`): 20/min heavy, 120/min light. **Authentication is still out of scope** — README says so explicitly. |
| SEC-07 | Fixed | `robots.txt` fetched and honoured before every scrape (`RESPECT_ROBOTS_TXT`), and the spoofed Chrome UA replaced with an honest, contactable one. |
| SEC-08 | Fixed | `Content-Type` checked before parsing; a non-HTML body raises a specific `ParsingError` instead of feeding binary to `read_html`. Test: `test_non_html_content_type_is_rejected`. |

## Reliability

| ID | Status | What changed |
|----|--------|--------------|
| REL-01 | Fixed | Upload is streamed 1 MiB at a time and aborted with **413** the moment the running total passes the cap — nothing is allocated past the limit. Test: `test_upload_rejects_oversized_body`. |
| REL-02 | Fixed | No pyplot in the render path: `Figure` + `FigureCanvasAgg`. `sns.set_theme` (process-wide) replaced with scoped `sns.axes_style` + `rc_context` under a render lock. Test: `test_concurrent_renders_keep_their_own_theme` (8 threads, alternating themes). |
| REL-03 | Fixed | `brotli` added to requirements; `Accept-Encoding` advertises `br` only when the decoder actually imports. Test asserts the two can't drift apart. |
| REL-04 | Fixed | Client timeouts come from `/api/limits`, and the server now enforces a hard 75 s total scrape budget (`SCRAPE_TOTAL_BUDGET`), so the browser can no longer give up on work the server continues. Upload uses `timeout: 0` plus an abort control instead of a blunt 3-minute cutoff. |
| REL-05 | Mitigated | Sliding TTL, single-lock reads, background sweeper — and a startup `RuntimeWarning` when more than one worker is configured. A real fix is Redis/SQLite; the limitation is now loud instead of silent. |
| REL-06 | Fixed | `read_html` is wrapped for `ValueError`, `ImportError` **and** any other parser exception, and falls through to BeautifulSoup rather than escaping as a 500. A global exception handler also converts anything unhandled into a JSON `{"detail": ...}` 500. |
| REL-07 | Fixed | The unreachable `except ValueError` is gone. `_check_log_scale` inspects the data: any value ≤ 0 skips the log axis and returns a warning the UI renders. Test: `test_log_scale_on_non_positive_data_warns_instead_of_lying`. |
| REL-08 | Fixed | `list(dict.fromkeys(...))` de-duplicates the selection and `vars=` is passed explicitly, so a numeric hue no longer produces a duplicated label. Test: `test_pairplot_with_numeric_hue_no_longer_fails`. |
| REL-09 | Fixed | `dedupe_columns()` runs at ingest for every source (`a`, `a.1`, `a.2`), so the stored frame, the preview and the column list agree. Test asserts both columns survive `to_dict`. |
| REL-10 | Fixed | Expiry is checked inside the same lock acquisition as the read; `last_access` refreshes on every hit (sliding TTL, so a long session is never evicted mid-work); bulk eviction moved to a background thread. Test: `test_store_ttl_is_sliding`. |
| REL-11 | Fixed | `build_summary` samples above `ANALYSIS_MAX_ROWS` (200k) and caps the correlation matrix at `ANALYSIS_MAX_CORR_COLS` (50). The response carries `sampled` / `correlation_truncated`, and the UI says so. |
| REL-12 | Fixed | `if not file.filename: raise HTTPException(400, ...)` before anything else. Test: `test_upload_rejects_missing_filename`. |
| REL-13 | Fixed | `getaddrinfo` runs in a pool with an explicit timeout, and "couldn't resolve" is now a distinct message from "host blocked". |
| REL-14 | Fixed | One module-level `Session` with the adapters mounted once (`pool_connections=10, pool_maxsize=20`), so pooling is actually realised and sockets aren't left to the GC. |
| REL-15 | Fixed | Cards are extracted into **named** fields (`title`, `href`, `value`) with positional `text_N` only for leftovers; columns populated on under a third of rows are dropped, so the frame is no longer ragged. The scan is also restricted to container tags with a limit instead of `find_all(True)`. |

## Frontend

| ID | Status | What changed |
|----|--------|--------------|
| FE-01 | Fixed | Chart sections gate on `ingested` alone; `numericColumns` falls back to `ingested.columns`. The summary error now renders with a **Retry** button instead of removing the charting half of the app. |
| FE-02 | Fixed | `unwrap()` reads the error `Blob` back as text and JSON-parses it, so export failures show the backend's real message. |
| FE-03 | Fixed | New `GET /api/rows/{id}`: search, sort and paging all run server-side over the **full** dataset. The header reads "Showing 1–25 of 10,000 row(s)", so the table and the export can no longer disagree. |
| FE-04 | Fixed | Sorting moved server-side (stable mergesort, `na_position="last"` in both directions), eliminating the invalid JS comparator entirely. Test: `test_query_rows_sorts_nulls_last_in_both_directions`. |
| FE-05 | Fixed | The lightbox is a real dialog: Escape closes, focus moves in and is trapped, focus is restored to the trigger, body scroll is locked, background is `aria-hidden`. Plus wheel-zoom, drag-to-pan, ±/0 keys and a zoom readout. |
| FE-06 | Fixed | `isThemeMode()` validates the stored value at runtime in both `ThemeContext` and the `index.html` pre-mount script; anything else falls back to `system`. |
| FE-07 | Fixed | The backend returns a small `thumbnail` next to the full image, and the history strip renders that — no more decoding a 1 MB bitmap into a 90×64 tile. |
| FE-08 | Fixed | `ErrorBoundary` wraps the whole app *and* each section (input, table, summary, builder, visualization), so one render bug no longer blanks the page or loses the dataset. |
| FE-09 | Fixed | Generate is disabled until required axes are filled, with inline field errors; the Y selector is hidden for chart types the backend ignores it for (`histogram`, `kde`, `count`, `pie`, `heatmap`, `pairplot`). |
| FE-10 | Fixed | IDs use `crypto.randomUUID()`. Form state is lifted into `App`, so selecting a history entry repopulates the form and Regenerate always matches what is on screen. |
| FE-11 | Fixed | `formatNumber` uses `Intl.NumberFormat`, exponential notation below 1e-4 / above 1e9, compact notation for large values, and the exact raw value in each cell's `title`. |
| FE-12 | Fixed | Keys are index-based, and duplicate labels no longer reach the frontend (REL-09). |
| FE-13 | Fixed | Dedicated `exportError` state rendered inside the Data Table card, next to the buttons that produced it, plus a toast. |
| FE-14 | Fixed | Roving tabindex on the chart-type radiogroup: one tab stop, Arrow/Home/End move selection, `aria-checked` kept in sync. |
| FE-15 | Fixed | `VALID_PALETTES` is now the single source of truth and is served via `/api/limits`; the frontend renders whatever the server sends, so the lists cannot drift. |
| FE-16 | Fixed | Descriptive statistics formatted and right-aligned with tabular numerals; value-count list keyed on index and drawn with proportional bars. |
| FE-17 | Fixed | Every request takes an `AbortSignal`; the upload tab shows a **Cancel** button while in flight. |
| FE-18 | Partly fixed | Fonts load non-blocking (`media="print"` → `all`) with real system-font fallback stacks, so a blocked/slow CDN no longer delays paint. Self-hosting the .woff2 files is still the full fix and needs the binaries. |

## Config & docs

| ID | Status | What changed |
|----|--------|--------------|
| CFG-01 | Fixed | README rewritten against the actual values, and `/api/limits` now feeds the UI the real numbers so the two cannot drift again. |
| CFG-02 | Fixed | `node_modules/` (88 MB) and `tsconfig.tsbuildinfo` removed; `.gitignore` added covering `node_modules/`, `dist/`, `*.tsbuildinfo`, `__pycache__/`, `.env`, `venv/`. |
| CFG-03 | Fixed | 57 backend tests (`netguard`, `parsing`, `charts`, `store`, API round-trip; `pytest.ini` turns `FutureWarning` into an error) + 21 frontend tests (Vitest + Testing Library: number formatting, theme validation, server-side search/sort, roving-tabindex chart picker, required-axis gating) + a GitHub Actions workflow (`.github/workflows/ci.yml`) that runs both suites plus `tsc -b` and `vite build` on every push/PR. No ESLint config yet — the type checker and both test suites are the safety net for now. |
| CFG-04 | Fixed | `brotli` in requirements (see REL-03). |
| CFG-05 | Fixed | The malformed `uvicorn main:app --reload -` line and its stray duplicate are gone. |
| CFG-06 | Fixed | `.env.example` now documents every env-read setting with defaults and a production suggestion. |
| CFG-07 | Fixed | When no hue is set, `hue=<category>` + `legend=False` replaces bare `palette=`, so seaborn 0.14 won't break bar/box/violin/count. Test asserts the FutureWarning is gone. |

---

## Charts: appearance and sizing

- **Size is now yours.** Width (4–20″), height (3–14″) and DPI (72–200) are
  request parameters with sliders and presets (Wide 16:9, Standard 4:3, Square,
  Slim). Default is 10×6 at 110 DPI instead of a fixed 8×5 at 150.
- **Readable axes.** Tick labels rotate 35° when categories are long or
  numerous; values use thousands/M/B formatting; numeric columns get tabular
  alignment.
- **Legends outside the plot** instead of sitting on top of the data.
- **Category caps:** at most 30 bars/boxes (most frequent kept), 25 heatmap
  columns, 10 pie slices with the rest grouped into "Other" — each reported as
  a warning rather than silently truncated.
- **Better defaults per type:** heatmap is square with a ±1 scale and annotates
  only when it fits; pie/donut gets a legend with counts and shares plus a
  centre total; pair plot uses `corner=True` with a sane per-panel size.
- **Theme fidelity:** figure, axes, grid, spines, ticks, title and legend all
  take their colours from the same token set as the UI.

## UI: interactivity

- **Live preview** — charts re-render automatically (debounced, previous
  request aborted) as you change type, axes, palette or size. Toggleable.
- **Data table** — server-side search across every row, sortable headers with
  `aria-sort`, page-size selector, first/prev/numbered/next/last paging,
  double-click a cell to copy its exact value.
- **Chart viewer** — fit-width / actual-size toggle, zoom, copy-to-clipboard,
  PNG download, and a lightbox with wheel-zoom and drag-to-pan.
- **Upload** — drag-and-drop zone with client-side type/size validation,
  progress bar and a working Cancel.
- **Summary** — collapsible sections, colour-scaled correlation matrix,
  missing-value bars, value-count bars.
- **Theme** — segmented light / dark / system control instead of a
  cycle-through button.
- **Feedback** — toast stack for success and failure, retry buttons on
  recoverable errors, contained error boundaries, `prefers-reduced-motion`
  respected, and the universal `*` CSS transition scoped down to the elements
  that need it.

---

## Round 3 fixes (reported after deployment)

| Issue | Root cause | Fix |
|-------|-----------|-----|
| **"API getting limit" — scraping a URL failed right after using the chart builder** | `/api/scrape`, `/api/upload` and `/api/visualize` all shared one rate-limit bucket (`RATE_LIMIT_HEAVY = 20/min`). Live chart preview calls `/api/visualize` on nearly every option change, so a couple minutes of chart tinkering could exhaust the bucket, and the very next URL paste — a completely unrelated request — got 429'd. | Each endpoint now has its own bucket (`ratelimit.py`: `scrape()`, `upload()`, `visualize()`), and `/api/visualize`'s limit was raised to 90/min since interactive use legitimately calls it often. New test `tests/test_ratelimit.py` proves the buckets are independent; also verified live against a running server (burned the visualize bucket to 429, confirmed the next scrape call still reached its own SSRF check instead of inheriting the 429). |
| **"Generate Chart looks stuck on one chart"** | The button was `disabled` whenever a required axis (X/Y) was empty — which happens automatically on some chart-type switches (Y gets cleared for types that ignore it). A click on a disabled button produces zero feedback, so it looked exactly like Generate was broken. | Button is now always clickable. Clicking with a missing field scrolls to and briefly shakes the empty selector, and shows a clear red "Still need X axis / Y axis" message instead of doing nothing. (Also fixed a related jsdom-exposed bug: `scrollIntoView` needs to be called with optional chaining on the method itself, not just the element, since some environments don't implement it.) |
| **"Charts should look like a BI dashboard, not one at a time"** | The app only ever showed a single chart. | New `Dashboard.tsx` view (now the default): auto-builds up to 6 panels — bar, line/count, pie/donut, correlation heatmap, histogram, box — picked from whichever numeric/categorical columns the dataset actually has, rendered in parallel via the existing `/api/visualize`. Styled with dark uppercase panel headers and a KPI strip (rows, columns, numeric/categorical column counts, duplicate rows, avg. missing %) to match the requested reference layout. A Dashboard / Single Chart toggle switches between this and the original one-chart-at-a-time builder, which is still there for full control (palette, size, hue, log scale, etc.). Verified live: all 6 panel specs render correctly against the backend (see `/tmp/dash_*.png` during development — bar and donut confirmed legible at dashboard panel size).

Verification: backend 59/59 pytest, frontend 24/24 vitest, `tsc -b` clean, `vite build` clean, plus the live end-to-end checks above.

---

## Round 4 fixes (reported after deployment)

| Issue | Root cause | Fix |
|-------|-----------|-----|
| **"Some charts just don't generate"** (screenshot: X=Population, Hue=Population) | `_limit_categories()` — the function that caps chart cardinality — exempted numeric columns entirely, so a high-cardinality numeric column picked as **Hue** (especially the same column as X) sailed through unfiltered. Seaborn then tries to give every distinct value its own legend colour: on real data (hundreds/thousands of unique values) that doesn't error, it just churns for a very long time. Looks exactly like "not generating". | New `_prepare_hue()` in `charts.py`: any Hue column — numeric or categorical — with more than 12 distinct values is dropped with a clear warning ("too many to color by — showing without grouping"), rather than silently hanging. Verified live: reproduced the screenshot's exact scenario (600-value numeric column as both X and Hue) — was pathological before, now renders in 0.13s with the warning shown. New tests `test_high_cardinality_numeric_hue_is_dropped_not_hung` (asserts <5s) and `test_low_cardinality_numeric_hue_is_kept` (a legitimate 4-value numeric hue, e.g. a 1–5 rating, is never dropped). |
| **Dashboard charts should have hover / be interactive** | The dashboard only ever rendered static matplotlib PNGs — no way to see an exact value without regenerating with different options. | New `/api/chart-data` endpoint (`analysis.py`: `build_bar_data`, `build_line_data`, `build_pie_data`, `build_histogram_data`) returns lightweight pre-aggregated JSON instead of an image. New `InteractiveChart.tsx` renders it with **Recharts** — hover tooltips, click-highlight, animated entry — for bar, line, area, pie/donut and histogram panels. Heatmap and box plots stay as matplotlib images (no good interactive equivalent that's worth the complexity here). **Theme switching is free for interactive panels** — colours are applied client-side from the cached JSON, no re-fetch; only the static image panels re-render server-side on a theme flip (verified by test: `fetchChartData` call count stays flat across a theme change, `visualize` call count doubles for the two static panels). Recharts is lazy-loaded (`React.lazy`) since the dashboard is opt-in — the main bundle stays at 243 KB; the 433 KB chart-library chunk only downloads once someone actually opens the dashboard. |
| **Dashboard should be its own screen, and let you add more charts** | Dashboard was an inline card sharing the scrolling page with the data table, summary, and single-chart builder. No way to add extra panels. | Dashboard is now a **full-screen overlay** (`position: fixed`, scroll-locked, own header with dataset name + Close, Escape to dismiss) opened via a dedicated "📊 Open Full Dashboard" button — the original single-chart builder is still on the normal page underneath for full manual control (palette, size, hue, log scale, etc.), unchanged. A **"+ Add Chart"** button opens an inline form (chart type, X, Y) and appends a new panel — interactive types fetch through `/api/chart-data`, everything else through `/api/visualize` — without refetching the other panels. Every user-added panel gets a **✕ remove** button; the 6 automatic panels don't (they regenerate from the dataset). |

Verification: backend 71/71 pytest (10 new for `/api/chart-data`, 2 new for the hue-cardinality fix), frontend 26/26 vitest (5 new for Dashboard's full-screen/interactive/add-panel behavior), `tsc -b` clean, `vite build` clean with the recharts chunk correctly code-split, plus the live end-to-end checks above (including literally reproducing the reported screenshot's scenario against a running server).

---

## Round 5 fix (Windows deployment)

| Issue | Root cause | Fix |
|-------|-----------|-----|
| **`WinError 10013` on backend startup, then `/api/*` 404s in the browser** | Not an app bug. On Windows 10/11 with Hyper-V or WSL2 installed, Windows reserves blocks of ports for its own NAT and port 8000 commonly falls inside one of those reserved ranges — binding to it is refused with a permissions error, not "already in use". The 404s in the browser console were a downstream symptom: the frontend's dev proxy had nothing to forward to since the backend never came up. | Moved the default port to **8010** (`frontend/vite.config.ts`, `start.bat`, `stop.bat`, README) and made it a single `BACKEND_PORT` variable instead of hardcoded in four places — the frontend's Vite proxy now reads `BACKEND_PORT` from the environment instead of a hardcoded `localhost:8000`. `start.bat` now does a real health check (`/api/health`, 10×1s retries) after launching both servers, and if it still fails, prints the actual diagnosis and two concrete fixes: change the one `BACKEND_PORT` line and re-run, or (as Administrator) `net stop winnat && net start winnat` to reset Windows' port reservations — plus the command to list which ports are currently excluded. |

---

## Round 6 fix (scrape timeouts on real sites)

| Issue | Root cause | Fix |
|-------|-----------|-----|
| **Scrape times out ("site took too long to respond") on real sites even after the port fix** | An earlier round (SEC-07) replaced a spoofed Chrome User-Agent with an honest one that literally announced `DataAnalyzerBot/1.1`. robots.txt compliance (already checked separately, unchanged) is the actual consent mechanism — but declaring "I am a bot" in the UA string on top of that gets silently throttled or hung by Cloudflare/Akamai/PerimeterX-style bot detection on most real e-commerce and news sites. From the client side that's indistinguishable from "the site is just slow", which is exactly the generic message that showed. | Reverted to a real, current Chrome User-Agent string, robots.txt compliance untouched. New test `test_user_agent_does_not_self_identify_as_a_bot` pins this so it can't regress back silently. **Caveat, stated plainly:** this sandbox's network egress is restricted to a small domain allowlist (verified: even `https://example.com` returns `403 host_not_allowed` here), so this could not be tested against an arbitrary live external site from here the way the SSRF/rate-limit/chart fixes in earlier rounds were — only against the local test server. If the same timeout still happens after this fix, it's worth checking separately whether it's this app or a general network/firewall condition: try the same URL directly in a browser first, and if it loads fine there but still times out here, the target site is genuinely JS-rendered (no `<table>` markup in the raw HTML) and needs 'Upload File' / 'Paste Data' instead. |

---

## Round 7 fix (shipped timeout defaults were still the old ones)

| Issue | Root cause | Fix |
|-------|-----------|-----|
| **Scrape still times out even on the "fixed" zip** | The User-Agent fix (round 6) was real and correct, but a separate, older problem was still there: `config.py`'s actual code defaults were never bumped — `SCRAPE_READ_TIMEOUT` defaulted to 20s and `SCRAPE_TOTAL_BUDGET` to 75s. `.env.example` matched those same stale values and didn't even have a `SCRAPE_TOTAL_BUDGET` line at all. Since `start.bat` auto-copies `.env.example` → `.env` on first run, every fresh install got the tight timeouts regardless of the UA fix — pasting a manual override in chat only helped until someone re-extracted the zip. | Bumped the actual defaults: `SCRAPE_READ_TIMEOUT` 20→**40s**, `SCRAPE_TOTAL_BUDGET` 75→**120s**, in both `config.py` (what applies with no `.env` at all) and `.env.example` (what a fresh install copies). No more manual `.env` surgery needed after unzipping. |

Verification: backend 72/72 pytest, confirmed the loaded config values directly (`SCRAPE_READ_TIMEOUT_SECONDS=40`, `SCRAPE_TOTAL_BUDGET_SECONDS=120`, `SCRAPE_WORST_CASE_SECONDS=120` correctly capped).

---

## Round 8 fix (2-minute single request still got cut off at 40s)

| Issue | Root cause | Fix |
|-------|-----------|-----|
| **A single slow response (~2 min) still timed out even after the total budget was raised to 120s** | `_fetch()` sets each attempt's read timeout to `min(SCRAPE_READ_TIMEOUT_SECONDS, remaining_budget)` — the *smaller* of the two. Round 7 raised the total budget but left the per-attempt read timeout at 40s, so a single genuinely-slow response was still killed at 40s regardless of how much total budget was left unused. Total budget bounds the whole multi-redirect fetch; it was never a substitute for the per-request read timeout. | `SCRAPE_READ_TIMEOUT` 40s → **130s** (just over 2 minutes), `SCRAPE_TOTAL_BUDGET` 120s → **150s** (so the budget doesn't itself clip the read timeout back down below 130s on the first attempt). Verified by directly simulating the `_fetch()` math: `min(130, 150) = 130`s actually available for one slow response, comfortably covering a 2-minute site. |

Verification: backend 72/72 pytest, frontend 26/26 vitest, clean `tsc -b` and `vite build`.

---

## Round 9 — UI rewrite: React retired, vanilla JS served by the backend (2026-09-23)

Not a defect fix — a deliberate migration. The React 18 + TypeScript + Vite +
Recharts frontend was **replaced** with a dependency-free, single-page vanilla
JS UI and **deleted** entirely. Historical entries above still describe the
React app that existed at the time; they are left intact as a record. What
changed now:

| Area | Change |
|------|--------|
| **Frontend stack** | The whole `frontend/` tree (React sources, `vite.config.ts`, `package.json`/lock, `node_modules`, Vitest tests, `tsconfig`) is gone. The UI is now `web/`: `index.html` + `styles.css` + ES modules under `web/js/` (hash router, shared state, one module per screen) and hand-rolled, theme-aware **SVG** charts. No Node, no npm, no build step. |
| **Serving / CORS** | The backend mounts `web/` as `StaticFiles` at `/` (after every `/api` route, so routes keep priority). The UI is same-origin with the API, so credentialed CORS no longer has to allow a separate dev origin — CORS only matters now for opening the files off disk. `config.py` / `.env.example` CORS comments annotated accordingly; the mechanism and defaults are unchanged. |
| **Screens** | Expanded from the single-page React app to **eight** screens: Import, Overview, Data Table, Charts (Matplotlib), Interactive Dashboard (`/api/chart-data`), Correlations (heatmap from `analyze.correlation`), Machine Learning (Predict/Cluster/Anomalies), Reports (printable). The Dashboard and Correlations screens exercise two endpoints the React UI never called. |
| **Carried-over correctness** | `api.js` flattens Pydantic 422 `detail` arrays into a readable message (the React UI showed `[object Object]`); cluster **k** is capped to 2–8 to match the backend `Field(ge=2, le=8)`; regression `actual_vs_predicted` and cluster `profile`/`explained_variance` — present in responses but ignored before — are now rendered. |
| **Tooling** | `start.bat` is backend-only now (Python detect, venv + dependency self-heal, `.env` copy, free-port pick, health check, WinError-10013 guidance all kept; Node/npm/Vite detection, the frontend install and the `npm run dev` window removed; it opens `http://localhost:<port>/`). `stop.bat` no longer kills a Frontend window or frees port 5173. |
| **Untouched** | All backend analysis/ML/scrape logic, SSRF (`netguard.py`), robots.txt handling and the streamed-upload abort are unchanged — only a static mount was added. Still localhost-only, no auth. |

Verification: backend **92/93 pytest** (added `tests/test_static_ui.py` — 4 tests pinning that `/` serves the shell, `/styles.css` and `/js/main.js` serve, and the mount did not shadow `/api/health` or turn a missing `/api/*` route into HTML). The 1 remaining failure is the pre-existing sandbox DNS artifact (`test_blocked_urls[http://2130706433/]` — the decimal-encoded loopback is still refused, via `ResolutionError` from a timed-out lookup rather than the asserted `BlockedHostError`), unrelated to this change.
