DATA ANALYZER

Upload a spreadsheet, scrape a table from a URL, or paste tabular text, then explore it: searchable table, statistical summary, charts, an interactive dashboard, correlations, and a machine-learning workbench (prediction, clustering, anomaly detection).

This project has two ways to use it. Both share the same analysis code.

1. Streamlit app (pure Python, recommended). Start it with streamlit_app.py. It has login, a saved workspace, and the interactive Plotly dashboard.
2. Web UI (FastAPI backend plus a JavaScript frontend in the web folder). Start it with uvicorn.


-----------------------------------------------------------
HOW TO RUN
-----------------------------------------------------------

Requirements: Python 3.11 or 3.12. Very new Python versions (3.14 and above) do not have prebuilt packages for pydantic-core and lxml, so the install fails. If you have 3.14 installed, install 3.12 from python.org next to it. It does not remove your current Python.

The first install downloads about 100 MB (scikit-learn, scipy, plotly and others) and can take a few minutes. It only happens once.

OPTION A: Streamlit app

Windows, easiest:
  Double-click run_website.bat
  It creates backend\venv, installs the requirements, and starts the app.

Windows, with automatic port selection and browser opening:
  Double-click start.bat
  (that one starts the FastAPI web UI, see Option B)

Mac or Linux, easiest:
  bash run_website.sh

Any system, manual steps (run these inside the data-analyzer folder):
  python -m venv backend/venv
  Windows:    backend\venv\Scripts\activate
  Mac/Linux:  source backend/venv/bin/activate
  pip install -r backend/requirements.txt
  streamlit run streamlit_app.py

Your browser opens at http://localhost:8501


LOGIN (Streamlit app)

The app asks for a username and password. Users live in .streamlit/secrets.toml:

  [users]
  admin = "change-me"

Change the password before using the app for real. To store a hashed password instead of plain text, run:

  python make_password.py

Paste the line it prints as the value, for example:  admin = "pbkdf2$...$..."

A template is in .streamlit/secrets.toml.example. You can also set the APP_USERS environment variable instead.


OPTION B: Web UI (FastAPI plus JavaScript)

Windows, easiest:
  Double-click start.bat
  It creates the virtual environment, installs the requirements, picks a free port, and opens your browser. Double-click stop.bat to stop it.

Any system, manual steps:
  cd backend
  python -m venv venv
  Windows:    venv\Scripts\activate
  Mac/Linux:  source venv/bin/activate
  pip install -r requirements.txt
  uvicorn main:app --reload --port 8010

Then open http://localhost:8010
The backend serves both the API and the web pages from the same address. There is no npm and no build step.

Run exactly one worker. The dataset store lives in memory, so using --workers 2 causes random 404 errors.

If the port will not bind on Windows (error WinError 10013), Windows has reserved that port. Use another one, for example --port 8020, and open that address.


RUN THE TESTS

  cd backend
  python -m pytest -q


-----------------------------------------------------------
WHAT IS INSIDE
-----------------------------------------------------------

data-analyzer
  streamlit_app.py       Streamlit app: login, import, tables, charts, ML, reports
  dashboard_pro.py       Interactive dashboard for the Streamlit app
  make_password.py       Creates a hashed password for secrets.toml
  run_website.bat / .sh  One-step start for the Streamlit app
  start.bat / stop.bat   One-step start and stop for the web UI
  .streamlit             Streamlit settings and login users
  backend
    main.py              FastAPI app and routes
    parsing.py           Scrape, upload and paste turned into a table
    netguard.py          Protection against unsafe URLs when scraping
    analysis.py          Summary statistics, search, sort, paging
    charts.py            Theme-aware chart drawing
    ml.py                Train, cluster and anomaly detection
    store.py             In-memory dataset store with expiry
    ratelimit.py         Optional per-IP rate limiter
    config.py            Every limit, all changeable by environment variable
    tests                Automated tests
    requirements.txt     Python packages
  web
    index.html           Page shell
    styles.css           Design tokens and styles
    js                   Router, state, API client, SVG charts, one file per screen


-----------------------------------------------------------
THE INTERACTIVE DASHBOARD
-----------------------------------------------------------

Streamlit app (dashboard_pro.py)
  Hover any bar, slice or histogram bin to see exact values.
  Line and area charts show all series together at the cursor, and support zoom, pan, a range slider, and 1m / 6m / 1y / All buttons on date axes.
  Click a bar to filter the whole dashboard: KPIs, insights, other panels, data quality and anomaly scan all follow. Shift-click selects several bars. The panel you clicked keeps showing everything. Use the Clear button to remove the filter.
  Pie slices cannot be clicked for filtering; use the Drill into list instead.
  Filters, KPI targets, saved dashboards and PDF export are all still available.

Web UI (Dashboard tab)
  Tooltips that follow the cursor, fading of the marks you are not pointing at, and a crosshair on line charts.
  The builder previews live as you change any control. Pin to dashboard keeps a chart.
  Each panel can switch chart type and expand to full width. Pinned panels stay when you change tabs.


-----------------------------------------------------------
SCREENS (WEB UI)
-----------------------------------------------------------

1. Import: upload a file, scrape a URL, paste text, or load a sample.
2. Overview: rows, columns, missing values, column types, numeric summary.
3. Data Table: search, sort and page through the full dataset. Export as CSV or JSON.
4. Charts: Matplotlib and Seaborn chart builder with download.
5. Dashboard: interactive panels described above.
6. Correlations: heatmap and strongest pairs.
7. Machine Learning: Predict (random forest), Cluster (k-means), Anomalies (isolation forest).
8. Reports: one printable page. Use Print to save as PDF.


-----------------------------------------------------------
LIMITS AND SECURITY
-----------------------------------------------------------

Defaults, all changeable in backend/.env (see backend/.env.example): 500 MB upload limit, 5 MB scrape page limit, 2,000,000 rows analysed, datasets expire after 1 hour without use. Rate limiting is off by default.

Scraping blocks private, loopback and link-local addresses and re-checks every redirect. It also follows robots.txt.

The web UI has no login. Do not expose it beyond your own computer or a trusted network without adding authentication and turning on rate limiting (RATE_LIMIT_ENABLED=true).

The Streamlit app has a login, but change the default password in .streamlit/secrets.toml first.
