"""Create a hashed password for .streamlit/secrets.toml:  python make_password.py"""
import getpass, hashlib, os
pw = getpass.getpass("New password: ")
salt = os.urandom(16)
print("pbkdf2$%s$%s" % (salt.hex(), hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, 200_000).hex()))
