@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
title Data Analyzer - Launcher

REM Backend port. The launcher verifies the preferred port is actually free and,
REM if it's taken (a leftover server still running, or a Windows-reserved range
REM that throws WinError 10013), automatically falls back to the next free port
REM in the candidate list. The health check and the browser both follow whichever
REM port is chosen, so you normally never have to touch this. Put your favourite
REM port first if you care.
set PREFERRED_PORT=8010
set PORT_CANDIDATES=%PREFERRED_PORT% 8020 8090 8000 5050 5001

echo ============================================
echo  Data Analyzer - one-click start
echo ============================================
echo.

REM ---- pick a Python version this project's packages actually have
REM      prebuilt installers for. Very new Pythons (3.14+) often don't have
REM      wheels yet for packages like pydantic-core/lxml, so pip falls back
REM      to compiling them from source and fails without a Rust/C toolchain.
set "PYEXE="
set "PYLABEL="

where py >nul 2>nul
if not errorlevel 1 (
    for %%V in (3.12 3.11 3.13) do (
        if not defined PYEXE (
            py -%%V --version >nul 2>nul
            if not errorlevel 1 (
                set "PYEXE=py -%%V"
                set "PYLABEL=%%V"
            )
        )
    )
)
if not defined PYEXE (
    where python >nul 2>nul
    if errorlevel 1 (
        echo [ERROR] Python not found on PATH.
        echo         Install Python 3.11 or 3.12 from https://python.org
        echo         Check "Add python.exe to PATH" during install, then re-run this file.
        pause
        exit /b 1
    )
    for /f "tokens=2 delims= " %%v in ('python --version 2^>^&1') do set "PYVER=%%v"
    echo !PYVER! | findstr /b /r "3\.14 3\.15 3\.16 3\.17" >nul
    if not errorlevel 1 (
        echo [ERROR] Found Python !PYVER!, which is too new for this project.
        echo         Some packages ^(pydantic-core, lxml^) don't ship prebuilt
        echo         installers for it yet and fail to compile from source.
        echo.
        echo         Fix: install Python 3.12 from https://python.org/downloads
        echo         ^(this installs alongside your current Python, it will not
        echo         remove it^) and re-run this file - it will pick 3.12
        echo         automatically via the "py" launcher.
        pause
        exit /b 1
    )
    set "PYEXE=python"
    set "PYLABEL=!PYVER!"
)

echo [INFO] Using Python !PYLABEL!
echo.

set VENV_PY=backend\venv\Scripts\python.exe
set VENV_PIP=backend\venv\Scripts\pip.exe

if not exist "%VENV_PY%" (
    echo [SETUP] Creating backend virtual environment...
    !PYEXE! -m venv backend\venv
    if errorlevel 1 (
        echo [ERROR] Could not create the virtual environment.
        pause
        exit /b 1
    )
)

REM Only (re)install if a marker import is actually missing, so a healthy
REM venv skips the slow pip step (and the network entirely - it starts fine
REM offline once set up) - but a half-installed one (e.g. sklearn added later)
REM self-heals instead of failing at runtime.
"%VENV_PY%" -c "import fastapi, pandas, matplotlib, seaborn, sklearn" >nul 2>nul
if not errorlevel 1 (
    echo [OK] Backend dependencies already present.
) else (
    echo.
    echo [SETUP] Installing backend dependencies.
    echo         First run only - downloads pandas / matplotlib / seaborn /
    echo         scikit-learn etc, can take a few minutes depending on your
    echo         connection. You will see progress below. Do not close this window.
    echo.
    "%VENV_PY%" -m pip install --upgrade pip --disable-pip-version-check -q
    "%VENV_PIP%" install -r backend\requirements.txt --disable-pip-version-check
    if errorlevel 1 (
        echo.
        echo [ERROR] pip install failed - see the message above.
        echo         If it mentions "failed to run custom build command" or a
        echo         Rust/cargo error, your Python version is too new for one of
        echo         these pinned packages - see the note in README.md, or run
        echo         this file again after installing Python 3.11/3.12.
        echo         Otherwise: check your internet connection, or try running
        echo         this file as Administrator.
        pause
        exit /b 1
    )
    echo.
    echo [OK] Backend dependencies installed.
    echo.
)

if not exist "backend\.env" (
    echo [SETUP] Creating backend\.env from .env.example...
    copy /y "backend\.env.example" "backend\.env" >nul
)

REM ---- pick a backend port that is actually free. The preferred port is tried
REM      first; if it is held (a leftover server, or a Windows-reserved range
REM      that would throw WinError 10013) we fall back to the next free
REM      candidate. This uses the same loopback bind uvicorn does, so a pass
REM      here means uvicorn will bind too.
set "BACKEND_PORT="
for %%P in (%PORT_CANDIDATES%) do (
    if not defined BACKEND_PORT (
        powershell -NoProfile -Command "try { $l=[System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback,%%P); $l.Start(); $l.Stop(); exit 0 } catch { exit 1 }" >nul 2>nul
        if not errorlevel 1 set "BACKEND_PORT=%%P"
    )
)

if not defined BACKEND_PORT (
    echo [ERROR] Could not find a free port for the backend.
    echo         Tried: %PORT_CANDIDATES%
    echo         Close whatever is using those ports, or add a free one to
    echo         PORT_CANDIDATES near the top of this file, then re-run.
    pause
    exit /b 1
)

if not "%BACKEND_PORT%" == "%PREFERRED_PORT%" (
    echo [INFO] Port %PREFERRED_PORT% was busy - using %BACKEND_PORT% instead.
)

echo [START] Launching Data Analyzer on http://localhost:%BACKEND_PORT% ...
start "Data Analyzer - Backend" cmd /k "cd /d "%~dp0backend" && venv\Scripts\python.exe -m uvicorn main:app --reload --port %BACKEND_PORT%"

echo.
echo Waiting for the server to come up...
set BACKEND_OK=0
for /l %%i in (1,1,10) do (
    if !BACKEND_OK! == 0 (
        timeout /t 1 /nobreak >nul
        powershell -NoProfile -Command "try { (Invoke-WebRequest -Uri 'http://localhost:%BACKEND_PORT%/api/health' -UseBasicParsing -TimeoutSec 2).StatusCode } catch { exit 1 }" >nul 2>nul
        if not errorlevel 1 set BACKEND_OK=1
    )
)
if !BACKEND_OK! == 0 (
    echo.
    echo ============================================
    echo  [WARNING] Backend did not respond on port %BACKEND_PORT%
    echo  within 10 seconds.
    echo ============================================
    echo.
    echo  Check the "Data Analyzer - Backend" window for the actual error.
    echo  The launcher already picked a free port ^(%BACKEND_PORT%^), so this is
    echo  usually a real startup error there ^(a bad .env value, a broken import^),
    echo  not a port clash.
    echo.
    echo  If that window shows "WinError 10013" or "access forbidden" anyway,
    echo  Windows has reserved this port range for its own use ^(common with
    echo  Hyper-V / WSL2^). Fix by either:
    echo.
    echo    1. Adding a known-free port to PORT_CANDIDATES near the top of this
    echo       file, then re-run start.bat.
    echo.
    echo    2. OR, as Administrator, resetting Windows' port reservations:
    echo         net stop winnat
    echo         net start winnat
    echo       then re-run start.bat with the original port.
    echo.
    echo  You can see which ports Windows has reserved with:
    echo    netsh interface ipv4 show excludedportrange protocol=tcp
    echo.
    pause
    exit /b 1
)

echo [OK] Backend is responding.
echo Opening the app in your browser...
timeout /t 2 /nobreak >nul
start "" "http://localhost:%BACKEND_PORT%/"

echo.
echo ============================================
echo  The server is running in its own window ^(it serves the UI at /^).
echo  Close that window, or run stop.bat, to stop everything.
echo ============================================
pause
