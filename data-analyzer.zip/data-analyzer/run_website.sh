#!/usr/bin/env bash
cd "$(dirname "$0")"
[ -d .venv ] || python3 -m venv .venv
.venv/bin/python -m pip install -q -r backend/requirements.txt
.venv/bin/python -m streamlit run streamlit_app.py
