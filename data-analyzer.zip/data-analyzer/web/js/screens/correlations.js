// screens/correlations.js — Pearson correlation heatmap (diverging −1..+1) plus
// the strongest pairs, read straight from the /analyze summary.

import { el, fmtNum, screenHead, panel, emptyState } from '../ui.js';
import * as api from '../api.js';
import { state, setSummary } from '../state.js';
import { heatmap } from '../svg.js';

async function ensureSummary() {
  if (state.summary) return state.summary;
  const s = await api.analyze(state.dataset.id);
  setSummary(s);
  return s;
}

function topPairs(corr, labels) {
  const out = [];
  for (let i = 0; i < labels.length; i++) {
    for (let j = i + 1; j < labels.length; j++) {
      const r = Number(corr[labels[i]][labels[j]]);
      if (Number.isFinite(r)) out.push({ a: labels[i], b: labels[j], r });
    }
  }
  return out.sort((x, y) => Math.abs(y.r) - Math.abs(x.r)).slice(0, 12);
}

export async function render(outlet) {
  const s = await ensureSummary();
  const corr = s.correlation || {};
  const labels = Object.keys(corr);

  if (labels.length < 2) {
    outlet.appendChild(el('div', { class: 'screen' }, [
      screenHead('Correlations', 'Pairwise Pearson correlation across numeric columns.'),
      emptyState('Not enough numeric columns', 'Correlation needs at least two numeric columns. Import a richer dataset to see the heatmap.'),
    ]));
    return;
  }

  const matrix = labels.map((r) => labels.map((c) => Number(corr[r][c])));
  const heatHost = el('div', { class: 'chart-host' });
  heatmap(heatHost, { rows: labels, cols: labels, matrix }, { diverging: true, valueFmt: (v) => fmtNum(v, 2) });

  const pairs = topPairs(corr, labels);
  const pairList = el('div', { class: 'pair-list' }, pairs.map((p) => {
    const strength = Math.min(1, Math.abs(p.r));
    return el('div', { class: 'pair-row' }, [
      el('div', { class: 'pair-names' }, [el('span', { class: 'strong', text: p.a }), el('span', { class: 'pair-x', text: '×' }), el('span', { class: 'strong', text: p.b })]),
      el('div', { class: 'meter' }, [el('span', { class: `meter-fill ${p.r < 0 ? 'neg' : 'pos'}`, style: `width:${(strength * 100).toFixed(0)}%` })]),
      el('div', { class: `pair-val ${p.r < 0 ? 'neg' : 'pos'}`, text: fmtNum(p.r, 2) }),
    ]);
  }));

  const note = s.correlation_truncated
    ? el('p', { class: 'warn', text: 'Showing a subset of columns — the correlation matrix was truncated for readability on this wide dataset.' })
    : null;

  outlet.appendChild(el('div', { class: 'screen' }, [
    screenHead('Correlations', `Pairwise Pearson r across ${labels.length} numeric columns. Teal = positive, coral = negative.`),
    note,
    el('div', { class: 'corr-layout' }, [
      panel('Heatmap', [heatHost]),
      panel('Strongest relationships', [pairs.length ? pairList : emptyState('No pairs', 'No finite correlations to rank.')]),
    ]),
  ]));
}
