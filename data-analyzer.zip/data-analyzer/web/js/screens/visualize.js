// screens/visualize.js — the matplotlib chart builder. Sends /visualize, shows
// the returned PNG, and keeps a thumbnail history (Reports reads the same list).
// Chart-type list, palettes and size bounds all come from /limits.

import { el, $, clear, toast, setBusy, screenHead, panel, emptyState } from '../ui.js';
import * as api from '../api.js';
import { state, addHistory, removeHistory, getTheme } from '../state.js';

const opt = (v, label, sel) => el('option', { value: v, selected: sel ? true : null }, [label ?? v]);
const needsY = (ct) => (state.limits.chart_types_needing_y || []).includes(ct);
const ignoresY = (ct) => (state.limits.chart_types_ignoring_y || []).includes(ct);

function selectField(label, options, value) {
  const sel = el('select', { class: 'select' }, options.map((o) => opt(o, o, o === value)));
  return { field: el('label', { class: 'field' }, [el('span', { class: 'field-label', text: label }), sel]), input: sel };
}

function numberField(label, { min, max, value, step = 1 }) {
  const input = el('input', { class: 'input', type: 'number', min, max, step, value });
  const out = el('span', { class: 'range-out', text: String(value) });
  input.addEventListener('input', () => { out.textContent = input.value; });
  return {
    field: el('label', { class: 'field' }, [
      el('span', { class: 'field-label' }, [label, ' ', out]),
      el('input', { class: 'range', type: 'range', min, max, step, value, oninput: (e) => { input.value = e.target.value; out.textContent = e.target.value; } }),
      input,
    ]),
    input,
  };
}

export async function render(outlet) {
  const cols = state.dataset.columns || [];
  const s = state.summary || {};
  const numeric = s.numeric_columns || cols;
  const cz = state.limits.chart_size || {};
  const types = state.limits.chart_types || ['bar', 'line', 'scatter', 'histogram'];
  const palettes = state.limits.palettes || ['deep'];
  const type = selectField('Chart type', types, types.includes('bar') ? 'bar' : types[0]);
  const x = selectField('X / column', cols, cols[0]);
  const y = selectField('Y', ['— none —', ...cols], '— none —');
  const hue = selectField('Group by (hue)', ['— none —', ...cols], '— none —');
  const palette = selectField('Palette', palettes, palettes[0]);
  const orientation = selectField('Orientation', ['vertical', 'horizontal'], 'vertical');
  const title = el('input', { class: 'input', type: 'text', maxlength: '200', placeholder: 'Optional chart title' });
  const bins = numberField('Bins', { min: 2, max: 100, value: 30 });
  const width = numberField('Width (in)', { min: cz.min_width || 4, max: cz.max_width || 20, value: cz.default_width || 10 });
  const height = numberField('Height (in)', { min: cz.min_height || 3, max: cz.max_height || 14, value: cz.default_height || 6 });
  const dpi = numberField('DPI', { min: cz.min_dpi || 72, max: cz.max_dpi || 200, value: cz.default_dpi || 110 });
  const logChk = el('input', { type: 'checkbox' });
  const donutChk = el('input', { type: 'checkbox' });
  const check = (lbl, input) => el('label', { class: 'check' }, [input, el('span', { text: lbl })]);

  const yWrap = y.field, binsWrap = bins.field, orientWrap = orientation.field;
  const donutWrap = el('div', { class: 'field' }, [check('Donut (ring) style', donutChk)]);
  function sync() {
    const ct = type.input.value;
    y.input.disabled = ignoresY(ct);
    y.field.classList.toggle('is-off', ignoresY(ct));
    y.input.previousSibling.textContent = needsY(ct) ? 'Y (required)' : 'Y';
    binsWrap.classList.toggle('hidden', !['histogram', 'kde'].includes(ct));
    donutWrap.classList.toggle('hidden', ct !== 'pie');
    orientWrap.classList.toggle('hidden', ct !== 'bar');
  }
  type.input.addEventListener('change', sync);
  sync();
  const resultHost = el('div', { class: 'chart-result' }, [emptyState('No chart yet', 'Choose options and hit Render chart.')]);
  const warnHost = el('div', { class: 'warn-host' });
  const historyHost = el('div', { class: 'thumb-grid' });

  function showImage(entry) {
    clear(resultHost);
    resultHost.appendChild(el('img', { class: 'chart-img', src: entry.image, alt: entry.title || entry.chart_type }));
    resultHost.appendChild(el('div', { class: 'chart-result-foot' }, [
      el('a', { class: 'button soft', href: entry.image, download: `${(entry.title || entry.chart_type || 'chart').replace(/\W+/g, '_')}.png` }, ['Download PNG']),
    ]));
  }

  function renderHistory() {
    clear(historyHost);
    if (!state.history.length) { historyHost.appendChild(el('p', { class: 'muted', text: 'Rendered charts collect here.' })); return; }
    state.history.forEach((h) => historyHost.appendChild(el('div', { class: 'thumb-wrap' }, [
      el('button', { class: 'thumb', type: 'button', title: h.title || h.chart_type, onclick: () => showImage(h) }, [el('img', { src: h.thumbnail || h.image, alt: '' })]),
      el('button', { class: 'thumb-x', type: 'button', 'aria-label': 'Remove', onclick: (e) => { e.stopPropagation(); removeHistory(h.id); renderHistory(); } }, ['×']),
    ])));
  }

  async function submit() {
    const ct = type.input.value;
    const none = (v) => (v && v !== '— none —' ? v : null);
    if (needsY(ct) && !none(y.input.value)) return toast(`A ${ct} chart needs a Y column.`, 'info');
    const req = {
      dataset_id: state.dataset.id, chart_type: ct, theme: getTheme(),
      x: none(x.input.value), y: ignoresY(ct) ? null : none(y.input.value), hue: none(hue.input.value),
      title: title.value.trim() || null, palette: palette.input.value,
      bins: ['histogram', 'kde'].includes(ct) ? Number(bins.input.value) : null,
      orientation: orientation.input.value, log_scale: logChk.checked, donut: donutChk.checked,
      width: Number(width.input.value), height: Number(height.input.value), dpi: Number(dpi.input.value),
    };
    setBusy(true, 'Rendering chart…');
    try {
      const res = await api.visualize(req);
      const entry = { id: String(Date.now()), image: res.image, thumbnail: res.thumbnail, chart_type: ct, title: req.title };
      showImage(entry); addHistory(entry); renderHistory();
      clear(warnHost);
      (res.warnings || []).forEach((w) => warnHost.appendChild(el('p', { class: 'warn', text: w })));
    } catch (err) {
      if (err instanceof api.ApiError && err.status === 404) { toast('Dataset expired — please re-import.', 'error'); window.__nav.navigate('/import'); return; }
      toast(err && err.message ? err.message : 'Render failed.', 'error');
    } finally { setBusy(false); }
  }
  const controls = el('div', { class: 'viz-controls' }, [
    type.field, x.field, yWrap, hue.field, palette.field, orientWrap, binsWrap, donutWrap,
    el('label', { class: 'field' }, [el('span', { class: 'field-label', text: 'Title' }), title]),
    el('div', { class: 'field-row' }, [width.field, height.field, dpi.field]),
    el('div', { class: 'check-row' }, [check('Log scale', logChk)]),
    el('button', { class: 'button primary block', type: 'button', onclick: submit }, ['Render chart']),
  ]);

  outlet.appendChild(el('div', { class: 'screen' }, [
    screenHead('Charts', 'Publication-quality matplotlib charts, rendered server-side and theme-matched.'),
    el('div', { class: 'viz-layout' }, [
      panel('Builder', [controls]),
      el('div', { class: 'viz-main' }, [warnHost, resultHost, panel('History', [historyHost])]),
    ]),
  ]));
  renderHistory();
}
