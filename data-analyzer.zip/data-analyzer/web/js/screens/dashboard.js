// screens/dashboard.js — interactive SVG panels over the lightweight /chart-data
// aggregation. Suggested panels can switch chart type or expand; the builder
// previews live as you change controls, and you pin what you like. Pinned panels
// survive tab switches for the current dataset.

import { el, clear, toast, fmtNum, fmtInt, fmtPct, debounce, screenHead, panel, emptyState } from '../ui.js';
import * as api from '../api.js';
import { state } from '../state.js';
import { hbar, vbars, line, donut } from '../svg.js';

const KINDS = { bar: 'Bars', pie: 'Pie', line: 'Line', area: 'Area', histogram: 'Histogram' };
const needsY = (t) => t === 'line' || t === 'area';
const usesY = (t) => needsY(t) || t === 'bar';
let pinned = { id: null, reqs: [] };

function draw(host, type, data) {
  clear(host);
  if (!data || !data.length) return void host.appendChild(emptyState('Nothing to plot', 'This column produced no data.'));
  if (type === 'bar') hbar(host, data.map((d) => ({ label: d.label ?? d.category, value: d.value })), { valueFmt: fmtNum });
  else if (type === 'line' || type === 'area') line(host, data.map((d) => ({ x: d.x, y: d.y })), { area: type === 'area', valueFmt: fmtNum });
  else if (type === 'pie') donut(host, data.map((d) => ({ label: d.label, value: d.value, pct: d.pct })), { valueFmt: fmtNum });
  else if (type === 'histogram') vbars(host, data.map((d) => ({ label: fmtNum(d.start), value: d.count })), { valueFmt: fmtInt });
}

async function loadInto(host, req) {
  const seq = (host._seq = (host._seq || 0) + 1); // newest request wins when controls change fast
  host.classList.add('is-loading');
  try {
    const res = await api.chartData(req);
    if (seq !== host._seq) return;
    draw(host, res.chart_type, res.data);
    if (res.warnings && res.warnings.length) host.appendChild(el('p', { class: 'warn', text: res.warnings.join(' ') }));
  } catch (err) {
    if (seq !== host._seq) return;
    clear(host);
    if (err instanceof api.ApiError && err.status === 404) { toast('Dataset expired — please re-import.', 'error'); window.__nav.navigate('/import'); return; }
    host.appendChild(emptyState('Could not build this panel', err && err.message ? err.message : ''));
  } finally { if (seq === host._seq) host.classList.remove('is-loading'); }
}

const chartHost = () => el('div', { class: 'chart-host' });
const field = (label, input) => el('label', { class: 'field' }, [el('span', { class: 'field-label', text: label }), input]);
const titleOf = (r) => `${KINDS[r.chart_type]} · ${r.x}${r.y ? ` by ${r.y}` : ''}`;

/** A panel with an optional chart-type switcher, expand toggle and remove button. */
function livePanel(title, req, { types = [], onRemove } = {}) {
  const host = chartHost();
  const select = (btn, t) => {
    req.chart_type = t;
    seg.querySelectorAll('button').forEach((b) => { b.classList.toggle('on', b === btn); b.setAttribute('aria-pressed', String(b === btn)); });
    loadInto(host, req);
  };
  const seg = types.length > 1 ? el('div', { class: 'seg', role: 'group', 'aria-label': 'Chart type' }, types.map((t) => el('button', {
    type: 'button', class: `seg-btn${t === req.chart_type ? ' on' : ''}`, 'aria-pressed': String(t === req.chart_type),
    onclick: (e) => select(e.currentTarget, t),
  }, [KINDS[t]]))) : null;
  const expand = el('button', {
    class: 'icon-x', type: 'button', title: 'Expand or shrink', 'aria-label': 'Expand panel',
    onclick: () => { const on = p.classList.toggle('is-wide'); expand.textContent = on ? '⤡' : '⤢'; expand.setAttribute('aria-label', on ? 'Shrink panel' : 'Expand panel'); },
  }, ['⤢']);
  const remove = onRemove ? el('button', { class: 'icon-x', type: 'button', 'aria-label': 'Remove panel', title: 'Remove', onclick: () => { p.remove(); onRemove(); } }, ['×']) : null;
  const p = panel(title, [host], { aside: [seg, expand, remove] });
  loadInto(host, req);
  return p;
}

function kpiStrip(s) {
  const cells = (s.shape?.rows || 0) * (s.shape?.columns || 0);
  const missing = Object.values(s.missing_values || {}).reduce((a, b) => a + Number(b || 0), 0);
  const kpi = (label, value) => el('div', { class: 'kpi' }, [el('div', { class: 'kpi-value', text: value }), el('div', { class: 'kpi-label', text: label })]);
  return el('div', { class: 'kpi-grid' }, [
    kpi('Rows', fmtInt(s.shape?.rows)), kpi('Columns', fmtInt(s.shape?.columns)),
    kpi('Numeric columns', fmtInt((s.numeric_columns || []).length)), kpi('Missing cells', fmtPct(cells ? (missing / cells) * 100 : 0)),
  ]);
}

/** Builder that previews on every change; "Pin to dashboard" keeps the result. */
function builder(cols, numeric, categorical, pin) {
  const typeSel = el('select', { class: 'select' }, Object.entries(KINDS).map(([v, l]) => el('option', { value: v }, [l])));
  const xSel = el('select', { class: 'select' }, cols.map((c) => el('option', { value: c }, [c])));
  const ySel = el('select', { class: 'select' }, ['— none —', ...cols].map((c) => el('option', { value: c }, [c])));
  const bins = el('input', { class: 'input', type: 'number', min: '2', max: '60', value: '20' });
  const yField = field('Value (y)', ySel), binField = field('Bins', bins);
  const preview = el('div', { class: 'preview' });
  xSel.value = categorical[0] || cols[0] || '';

  const current = () => {
    const t = typeSel.value, y = usesY(t) && ySel.value !== '— none —' ? ySel.value : null;
    return { dataset_id: state.dataset.id, chart_type: t, x: xSel.value || null, y, bins: t === 'histogram' ? Number(bins.value) || 20 : null };
  };
  const run = debounce(() => { clear(preview); const h = chartHost(); preview.appendChild(h); loadInto(h, current()); }, 200);
  const sync = () => {
    const t = typeSel.value;
    // Smart defaults: histograms want a numeric x; line/area need a numeric y.
    if (t === 'histogram' && numeric.length && !numeric.includes(xSel.value)) xSel.value = numeric[0];
    if (needsY(t) && ySel.value === '— none —') ySel.value = numeric.find((c) => c !== xSel.value) || '— none —';
    yField.classList.toggle('is-off', !usesY(t)); ySel.disabled = !usesY(t);
    binField.classList.toggle('is-off', t !== 'histogram'); bins.disabled = t !== 'histogram';
    run();
  };
  [typeSel, xSel, ySel, bins].forEach((n) => n.addEventListener('change', sync));
  bins.addEventListener('input', run);
  const pinBtn = el('button', { class: 'button primary', type: 'button', onclick: () => pin(current()) }, ['Pin to dashboard']);
  const wrap = el('div', {}, [el('div', { class: 'toolbar wrap' }, [field('Type', typeSel), field('Column (x)', xSel), yField, binField, pinBtn]), preview]);
  sync();
  return wrap;
}

export async function render(outlet) {
  if (!state.summary) { try { state.summary = await api.analyze(state.dataset.id); } catch { /* non-fatal */ } }
  const cols = state.dataset.columns || [];
  const s = state.summary || {};
  const numeric = s.numeric_columns || [], categorical = s.categorical_columns || [];
  if (pinned.id !== state.dataset.id) pinned = { id: state.dataset.id, reqs: [] };

  const autoHost = el('div', { class: 'panel-grid' });
  const pinHost = el('div', { class: 'panel-grid' });
  const hint = el('p', { class: 'muted', text: 'Nothing pinned yet. Build a chart above and pin it here.' });
  const addPinned = (req) => {
    hint.remove();
    pinHost.prepend(livePanel(titleOf(req), req, {
      types: Object.keys(KINDS),
      onRemove: () => { pinned.reqs = pinned.reqs.filter((r) => r !== req); if (!pinHost.children.length) pinHost.appendChild(hint); },
    }));
  };
  const pin = (req) => { pinned.reqs.push(req); addPinned(req); toast('Pinned to your dashboard.', 'success', 2200); };

  outlet.appendChild(el('div', { class: 'screen' }, [
    screenHead('Interactive Dashboard', 'Hover for exact values, switch a panel’s chart type, or expand it to full width.'),
    kpiStrip(s),
    el('h2', { class: 'section-label', text: 'Suggested panels' }), autoHost,
    panel('Build a panel', [builder(cols, numeric, categorical, pin)]),
    el('h2', { class: 'section-label', text: 'Pinned panels' }), pinHost,
  ]));
  pinHost.appendChild(hint);
  pinned.reqs.forEach(addPinned);

  const autos = [];
  categorical.slice(0, 2).forEach((c) => autos.push({ title: `Count of ${c}`, types: ['bar', 'pie'], req: { dataset_id: state.dataset.id, chart_type: 'bar', x: c } }));
  numeric.slice(0, 2).forEach((c) => autos.push({ title: `Distribution of ${c}`, types: [], req: { dataset_id: state.dataset.id, chart_type: 'histogram', x: c, bins: 20 } }));
  if (!autos.length) return void autoHost.appendChild(emptyState('No suggested panels', 'Add a numeric or categorical column to see automatic charts.'));
  autos.forEach((a) => autoHost.appendChild(livePanel(a.title, a.req, { types: a.types })));
}
