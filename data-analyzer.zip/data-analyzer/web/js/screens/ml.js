// screens/ml.js — three quick models over the current dataset: Predict
// (RandomForest, auto classification/regression), Cluster (KMeans + PCA), and
// Anomalies (IsolationForest). Renders metrics, importances, and SVG diagnostics
// including the regression actual-vs-predicted and cluster PCA projections.

import { el, clear, toast, setBusy, fmtNum, fmtInt, fmtPct, fmtCell, screenHead, panel, emptyState } from '../ui.js';
import * as api from '../api.js';
import { state } from '../state.js';
import { hbar, heatmap, scatter } from '../svg.js';

const field = (label, input) => el('label', { class: 'field' }, [el('span', { class: 'field-label', text: label }), input]);

function metricGrid(pairs) {
  return el('div', { class: 'metric-grid' }, pairs.map(([l, v]) => el('div', { class: 'metric' }, [
    el('div', { class: 'metric-val', text: v }), el('div', { class: 'metric-label', text: l }),
  ])));
}

function dataTable(headers, rows) {
  return el('div', { class: 'table-wrap' }, [el('table', { class: 'data-table' }, [
    el('thead', {}, [el('tr', {}, headers.map((h) => el('th', { class: 'num', text: h })))]),
    el('tbody', {}, rows.map((r) => el('tr', {}, r.map((c, i) => el('td', { class: i === 0 ? 'strong' : 'num', text: c }))))),
  ])]);
}

async function guarded(label, fn) {
  setBusy(true, label);
  try { await fn(); }
  catch (err) {
    if (err instanceof api.ApiError && err.status === 404) { toast('Dataset expired — please re-import.', 'error'); window.__nav.navigate('/import'); return; }
    toast(err && err.message ? err.message : 'That model could not be fit.', 'error');
  } finally { setBusy(false); }
}

const warnings = (list) => (list && list.length ? el('div', { class: 'warn-host' }, list.map((w) => el('p', { class: 'warn', text: w }))) : null);
export async function render(outlet) {
  const tabs = [
    { id: 'predict', label: 'Predict', fn: renderPredict },
    { id: 'cluster', label: 'Cluster', fn: renderCluster },
    { id: 'anomalies', label: 'Anomalies', fn: renderAnomalies },
  ];
  const body = el('div', { class: 'ml-body' });
  const tabBar = el('div', { class: 'subtabs' }, tabs.map((t) =>
    el('button', { class: 'subtab', type: 'button', 'data-tab': t.id, onclick: () => select(t) }, [t.label])));
  function select(t) {
    tabBar.querySelectorAll('.subtab').forEach((x) => x.classList.toggle('active', x.getAttribute('data-tab') === t.id));
    clear(body);
    t.fn(body);
  }
  outlet.appendChild(el('div', { class: 'screen' }, [
    screenHead('Machine Learning', 'RandomForest models, KMeans clustering and IsolationForest anomalies — fit on the fly.'),
    tabBar, body,
  ]));
  select(tabs[0]);
}
function renderPredict(host) {
  const cols = state.dataset.columns || [];
  const target = el('select', { class: 'select' }, cols.map((c) => el('option', { value: c }, [c])));
  const result = el('div', { class: 'ml-result' }, [emptyState('Pick a target', 'Choose a column to predict, then train a model.')]);
  host.appendChild(el('div', { class: 'toolbar' }, [
    field('Target column', target),
    el('button', { class: 'button primary', type: 'button', onclick: () => guarded('Training model…', async () => drawPredict(result, await api.mlTrain(state.dataset.id, target.value))) }, ['Train model']),
  ]));
  host.appendChild(result);
}

function drawPredict(host, res) {
  clear(host);
  const isClf = res.task === 'classification';
  const m = res.metrics || {};
  const metrics = isClf
    ? [['Accuracy', fmtPct((m.accuracy || 0) * 100)], ['F1 (macro)', fmtNum(m.f1_macro, 3)]]
    : [['R²', fmtNum(m.r2, 3)], ['MAE', fmtNum(m.mae)], ['RMSE', fmtNum(m.rmse)]];
  const impHost = el('div', { class: 'chart-host' });
  hbar(impHost, (res.feature_importances || []).slice(0, 12).map((f) => ({ label: f.feature, value: f.importance })), { valueFmt: (v) => fmtNum(v, 3) });

  const diag = el('div', { class: 'chart-host' });
  if (isClf && res.confusion_matrix) {
    const cm = res.confusion_matrix;
    heatmap(diag, { rows: cm.labels, cols: cm.labels, matrix: cm.matrix }, { diverging: false, max: Math.max(1, ...cm.matrix.flat()), valueFmt: fmtInt });
  } else if (!isClf && res.actual_vs_predicted) {
    scatter(diag, res.actual_vs_predicted.map((p) => ({ x: p.actual, y: p.predicted })), { identity: true, xLabel: 'Actual', yLabel: 'Predicted', valueFmt: fmtNum });
  } else {
    diag.appendChild(emptyState('No diagnostic', 'The model returned no diagnostic to plot.'));
  }

  host.appendChild(el('div', { class: 'ml-head' }, [
    el('span', { class: `badge badge-${isClf ? 'clf' : 'reg'}`, text: res.task }),
    el('span', { class: 'muted', text: `target “${res.target}” · ${fmtInt(res.n_rows_used)} rows · ${fmtInt(res.n_features)} features` }),
  ]));
  const w = warnings(res.warnings); if (w) host.appendChild(w);
  host.appendChild(metricGrid(metrics));
  host.appendChild(el('div', { class: 'two-column' }, [
    panel('Feature importances', [impHost]),
    panel(isClf ? 'Confusion matrix' : 'Actual vs predicted', [diag]),
  ]));
}
function renderCluster(host) {
  const kSel = el('select', { class: 'select' }, ['auto', 2, 3, 4, 5, 6, 7, 8].map((k) =>
    el('option', { value: String(k) }, [k === 'auto' ? 'auto (pick by silhouette)' : `k = ${k}`])));
  const result = el('div', { class: 'ml-result' }, [emptyState('Cluster the numeric columns', 'Pick k (2–8) or let silhouette choose, then run KMeans.')]);
  host.appendChild(el('div', { class: 'toolbar' }, [
    field('Clusters (k)', kSel),
    el('button', { class: 'button primary', type: 'button', onclick: () => guarded('Clustering…', async () => {
      const k = kSel.value === 'auto' ? null : Number(kSel.value);
      drawCluster(result, await api.mlCluster(state.dataset.id, k));
    }) }, ['Run KMeans']),
  ]));
  host.appendChild(result);
}

function drawCluster(host, res) {
  clear(host);
  const sizeHost = el('div', { class: 'chart-host' });
  hbar(sizeHost, (res.cluster_sizes || []).map((c) => ({ label: `Cluster ${c.cluster}`, value: c.size })), { valueFmt: fmtInt });
  const projHost = el('div', { class: 'chart-host' });
  scatter(projHost, (res.projection || []).map((p) => ({ x: p.x, y: p.y, group: p.cluster })), { xLabel: 'PC 1', yLabel: 'PC 2', valueFmt: fmtNum });

  const feats = res.features || [];
  const profileTable = (res.profile || []).length
    ? dataTable(['Cluster', ...feats], res.profile.map((p) => [`Cluster ${p.cluster}`, ...feats.map((f) => fmtNum(p[f]))]))
    : emptyState('No profile', 'The cluster profile was empty.');

  host.appendChild(el('div', { class: 'ml-head' }, [
    el('span', { class: 'badge badge-clf', text: `k = ${res.k}` }),
    el('span', { class: 'muted', text: `${res.auto_k ? 'chosen automatically · ' : ''}silhouette ${fmtNum(res.silhouette, 3)} · ${fmtInt(res.n_rows_used)} rows` }),
  ]));
  const w = warnings(res.warnings); if (w) host.appendChild(w);
  host.appendChild(metricGrid([['Clusters', fmtInt(res.k)], ['Silhouette', fmtNum(res.silhouette, 3)], ['Rows used', fmtInt(res.n_rows_used)]]));
  host.appendChild(el('div', { class: 'two-column' }, [
    panel('Cluster sizes', [sizeHost]),
    panel('PCA projection', [
      projHost,
      res.explained_variance ? el('p', { class: 'muted center', text: `PCA captures ${fmtPct((res.explained_variance[0] + res.explained_variance[1]) * 100)} of variance (${res.explained_variance.map((v) => fmtPct(v * 100)).join(' + ')}).` }) : null,
    ]),
  ]));
  host.appendChild(panel('Cluster profile (feature means)', [profileTable]));
}
function renderAnomalies(host) {
  const cont = el('input', { class: 'input', type: 'number', min: '0.01', max: '0.5', step: '0.01', placeholder: 'auto (e.g. 0.05)' });
  const result = el('div', { class: 'ml-result' }, [emptyState('Flag unusual rows', 'Optionally set a contamination fraction (0–0.5), then scan the numeric columns.')]);
  host.appendChild(el('div', { class: 'toolbar' }, [
    field('Contamination', cont),
    el('button', { class: 'button primary', type: 'button', onclick: () => guarded('Scanning…', async () => {
      const c = cont.value ? Number(cont.value) : null;
      drawAnomalies(result, await api.mlAnomalies(state.dataset.id, c));
    }) }, ['Detect anomalies']),
  ]));
  host.appendChild(result);
}

function drawAnomalies(host, res) {
  clear(host);
  const top = res.top_anomalies || [];
  const valueKeys = top.length ? Object.keys(top[0].values || {}).slice(0, 6) : [];
  const headers = ['Row', 'Score', ...valueKeys];
  const rows = top.map((a) => [fmtInt(a.index), fmtNum(a.score, 3), ...valueKeys.map((k) => fmtCell(a.values[k]))]);
  const share = res.n_rows_used ? (res.n_flagged / res.n_rows_used) * 100 : 0;

  const w = warnings(res.warnings); if (w) host.appendChild(w);
  host.appendChild(metricGrid([
    ['Flagged rows', fmtInt(res.n_flagged)],
    ['Share', fmtPct(share)],
    ['Threshold', fmtNum(res.threshold, 3)],
    ['Contamination', fmtNum(res.contamination, 3)],
  ]));
  host.appendChild(panel('Most anomalous rows', [rows.length ? dataTable(headers, rows) : emptyState('None flagged', 'No rows crossed the anomaly threshold.')]));
}
