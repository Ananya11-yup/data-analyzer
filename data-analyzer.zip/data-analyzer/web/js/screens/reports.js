// screens/reports.js — one consolidated, printable report: dataset meta, KPIs,
// numeric summary, strongest correlations and the saved-chart gallery. Export
// CSV/JSON and Print / Save-as-PDF (a print stylesheet hides the app chrome).

import { el, fmtInt, fmtNum, fmtPct, screenHead, panel, emptyState } from '../ui.js';
import * as api from '../api.js';
import { state, setSummary } from '../state.js';

async function ensureSummary() {
  if (state.summary) return state.summary;
  const s = await api.analyze(state.dataset.id);
  setSummary(s);
  return s;
}

const STAT_KEYS = ['count', 'mean', 'std', 'min', '25%', '50%', '75%', 'max'];

function kpiGrid(s) {
  const cells = s.shape.rows * s.shape.columns;
  const missing = Object.values(s.missing_values || {}).reduce((a, b) => a + Number(b || 0), 0);
  const pairs = [
    ['Rows', fmtInt(s.shape.rows)], ['Columns', fmtInt(s.shape.columns)],
    ['Numeric', fmtInt((s.numeric_columns || []).length)], ['Categorical', fmtInt((s.categorical_columns || []).length)],
    ['Duplicate rows', fmtInt(s.duplicate_rows || 0)], ['Missing cells', fmtPct(cells ? (missing / cells) * 100 : 0)],
  ];
  return el('div', { class: 'kpi-grid' }, pairs.map(([l, v]) => el('div', { class: 'kpi' }, [
    el('div', { class: 'kpi-value', text: v }), el('div', { class: 'kpi-label', text: l }),
  ])));
}

function describeTable(s) {
  const cols = Object.keys(s.describe || {});
  if (!cols.length) return emptyState('No numeric columns', 'Nothing to summarise.');
  return el('div', { class: 'table-wrap' }, [el('table', { class: 'data-table' }, [
    el('thead', {}, [el('tr', {}, [el('th', { text: 'Column' }), ...STAT_KEYS.map((k) => el('th', { class: 'num', text: k }))])]),
    el('tbody', {}, cols.map((c) => el('tr', {}, [
      el('td', { class: 'strong', text: c }),
      ...STAT_KEYS.map((k) => el('td', { class: 'num', text: k === 'count' ? fmtInt(s.describe[c][k]) : fmtNum(s.describe[c][k]) })),
    ]))),
  ])]);
}
function topCorr(s) {
  const corr = s.correlation || {};
  const labels = Object.keys(corr);
  const out = [];
  for (let i = 0; i < labels.length; i++) {
    for (let j = i + 1; j < labels.length; j++) {
      const r = Number(corr[labels[i]][labels[j]]);
      if (Number.isFinite(r)) out.push({ a: labels[i], b: labels[j], r });
    }
  }
  return out.sort((x, y) => Math.abs(y.r) - Math.abs(x.r)).slice(0, 10);
}

export async function render(outlet) {
  const s = await ensureSummary();
  const d = state.dataset || { source: 'dataset' };
  const pairs = topCorr(s);
  const corrBlock = pairs.length
    ? el('ul', { class: 'corr-report' }, pairs.map((p) => el('li', {}, [
        el('span', { class: 'strong', text: `${p.a} × ${p.b}` }),
        el('span', { class: `pair-val ${p.r < 0 ? 'neg' : 'pos'}`, text: fmtNum(p.r, 2) }),
      ])))
    : emptyState('No correlations', 'Correlation needs at least two numeric columns.');
  const charts = state.history || [];
  const gallery = charts.length
    ? el('div', { class: 'report-gallery' }, charts.map((h) => el('figure', { class: 'report-fig' }, [
        el('img', { src: h.image, alt: h.title || h.chart_type }),
        el('figcaption', { text: h.title || h.chart_type }),
      ])))
    : emptyState('No saved charts', 'Render charts on the Charts screen and they will appear here.');

  const actions = [
    el('a', { class: 'button soft', href: api.exportUrl(d.id, 'csv'), download: '' }, ['Export CSV']),
    el('a', { class: 'button soft', href: api.exportUrl(d.id, 'json'), download: '' }, ['Export JSON']),
    el('button', { class: 'button primary', type: 'button', onclick: () => window.print() }, ['Print / Save PDF']),
  ];

  outlet.appendChild(el('div', { class: 'screen report' }, [
    screenHead('Report', `${d.source || 'dataset'} · generated ${new Date().toLocaleString()}`, actions),
    panel('Dataset', [
      el('div', { class: 'meta-line', text: `${fmtInt(s.shape.rows)} rows × ${fmtInt(s.shape.columns)} columns${s.sampled ? ` · analysed a ${fmtInt(s.sample_rows)}-row sample` : ''}` }),
      kpiGrid(s),
    ]),
    panel('Numeric summary', [describeTable(s)]),
    panel('Strongest correlations', [corrBlock]),
    panel('Saved charts', [gallery]),
  ]));
}
