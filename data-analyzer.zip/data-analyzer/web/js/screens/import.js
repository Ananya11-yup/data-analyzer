// screens/import.js — the entry screen: upload / scrape / paste, a one-click
// sample dataset, and the API-base override card. On any successful ingest we
// store the dataset, pull its summary, and route to Overview.

import { $, el, toast, setBusy, escapeHtml } from '../ui.js';
import * as api from '../api.js';
import { state, setDataset, setSummary } from '../state.js';

// Deterministic sample so every visitor sees the same figures. Enough rows for
// the ML screen's train/test split, with numeric + categorical + a 0/1 target.
function makeSampleCsv() {
  const regions = ['North', 'South', 'East', 'West'];
  const segments = ['SMB', 'Mid-Market', 'Enterprise'];
  let seed = 7;
  const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
  const rows = [['region', 'segment', 'units', 'unit_price', 'discount', 'revenue', 'satisfaction', 'churned']];
  for (let i = 0; i < 140; i++) {
    const region = regions[Math.floor(rnd() * regions.length)];
    const segment = segments[Math.floor(rnd() * segments.length)];
    const units = 5 + Math.floor(rnd() * 95);
    const unitPrice = +(20 + rnd() * 180).toFixed(2);
    const discount = +(rnd() * 0.3).toFixed(3);
    const revenue = +(units * unitPrice * (1 - discount)).toFixed(2);
    const satisfaction = +(2.5 + rnd() * 2.5).toFixed(2);
    const churned = satisfaction < 3.4 && discount < 0.12 ? 1 : rnd() < 0.15 ? 1 : 0;
    rows.push([region, segment, units, unitPrice, discount, revenue, satisfaction, churned]);
  }
  return rows.map((r) => r.join(',')).join('\n');
}

async function afterIngest(resp) {
  setDataset(resp);
  try {
    const summary = await api.analyze(resp.dataset_id);
    setSummary(summary);
  } catch { /* Overview will retry; ingest itself succeeded. */ }
  toast(`Loaded ${resp.shape.rows.toLocaleString()} rows × ${resp.shape.columns} columns.`, 'success');
  window.__nav.navigate('/overview');
}

async function guarded(label, fn) {
  setBusy(true, label);
  try { await fn(); }
  catch (err) {
    if (err && err.message === api.CANCELLED) return;
    toast(err && err.message ? err.message : 'That failed.', 'error');
  } finally { setBusy(false); }
}
export async function render(outlet) {
  const fileInput = el('input', { type: 'file', class: 'hidden-file', accept: '.csv,.tsv,.txt,.json,.xlsx,.xls' });
  const progress = el('div', { class: 'progress', hidden: true }, [el('span', { class: 'progress-bar' })]);
  const setProg = (p) => { progress.hidden = (p == null); if (p != null) progress.firstChild.style.width = `${p}%`; };

  const doUpload = (file) => {
    if (!file) return;
    guarded('Uploading…', async () => {
      setProg(0);
      const resp = await api.uploadFile(file, setProg);
      setProg(null);
      await afterIngest(resp);
    });
  };

  const drop = el('div', { class: 'dropzone', tabindex: '0', role: 'button', 'aria-label': 'Upload a data file' }, [
    el('div', { class: 'dropzone-icon', 'aria-hidden': 'true', text: '↑' }),
    el('div', { class: 'dropzone-title', text: 'Drop a file or click to browse' }),
    el('div', { class: 'dropzone-hint', text: 'CSV · TSV · JSON · Excel — up to the server limit' }),
  ]);
  drop.addEventListener('click', () => fileInput.click());
  drop.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fileInput.click(); } });
  ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('dragover'); }));
  ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('dragover'); }));
  drop.addEventListener('drop', (e) => doUpload(e.dataTransfer.files && e.dataTransfer.files[0]));
  fileInput.addEventListener('change', () => doUpload(fileInput.files[0]));

  const sampleBtn = el('button', {
    class: 'button soft', type: 'button',
    onclick: () => guarded('Loading sample…', async () => afterIngest(await api.paste(makeSampleCsv()))),
  }, ['Load sample dataset']);

  const uploadCard = card('Upload', 'A file from your computer', [drop, fileInput, progress,
    el('div', { class: 'card-foot' }, [el('span', { class: 'hint', text: 'No account needed — data stays on your machine.' }), sampleBtn])]);
  const urlInput = el('input', { class: 'input', type: 'url', placeholder: 'https://en.wikipedia.org/wiki/List_of_countries_by_population' });
  const scrapeSecs = (state.limits.scrape_worst_case_seconds || 150) + 15;
  const scrapeCard = card('Fetch from a web page', 'Pulls the tables out of a public URL', [
    el('div', { class: 'field' }, [urlInput]),
    el('button', {
      class: 'button primary', type: 'button',
      onclick: () => {
        const u = urlInput.value.trim();
        if (!u) return toast('Enter a URL first.', 'info');
        guarded('Fetching page…', async () => afterIngest(await api.scrape(u, undefined, scrapeSecs * 1000)));
      },
    }, ['Fetch tables']),
    el('p', { class: 'hint', text: 'Largest table on the page wins. Respects robots.txt; can take a moment.' }),
  ]);

  const ta = el('textarea', { class: 'textarea', rows: '7', placeholder: 'Paste CSV, TSV, JSON, or a Markdown table…' });
  const pasteCard = card('Paste data', 'CSV, TSV, JSON or a Markdown table', [
    el('div', { class: 'field' }, [ta]),
    el('button', {
      class: 'button primary', type: 'button',
      onclick: () => {
        const t = ta.value.trim();
        if (!t) return toast('Paste some data first.', 'info');
        guarded('Parsing…', async () => afterIngest(await api.paste(t)));
      },
    }, ['Parse text']),
  ]);

  const apiInput = el('input', { class: 'input mono', type: 'text', value: api.getApiBase(), spellcheck: 'false' });
  const apiCard = el('section', { class: 'card api-box' }, [
    el('div', { class: 'card-header' }, [el('div', { class: 'card-title', text: 'API endpoint' }),
      el('div', { class: 'card-subtitle', text: 'Only change this if the backend runs elsewhere. Blank = same origin.' })]),
    el('div', { class: 'card-body toolbar' }, [
      el('div', { class: 'field grow' }, [apiInput]),
      el('button', { class: 'button soft', type: 'button', onclick: () => { api.setApiBase(apiInput.value); toast('Saved API endpoint.', 'success'); } }, ['Save']),
      el('button', { class: 'button ghost', type: 'button', onclick: () => { api.setApiBase(''); apiInput.value = api.getApiBase(); toast('Reset to same origin.', 'info'); } }, ['Reset']),
    ]),
  ]);

  outlet.appendChild(el('div', { class: 'screen' }, [
    el('header', { class: 'hero' }, [
      el('div', { class: 'eyebrow', text: 'Data Analyzer' }),
      el('h1', { class: 'hero-title', text: 'Bring your data in.' }),
      el('p', { class: 'hero-sub', text: 'Upload a file, scrape a page, or paste a table. Everything runs locally — explore, chart, and model it in seconds.' }),
    ]),
    el('div', { class: 'import-grid' }, [uploadCard, scrapeCard, pasteCard]),
    apiCard,
  ]));
}

function card(title, subtitle, body) {
  return el('section', { class: 'card source-card' }, [
    el('div', { class: 'card-header' }, [
      el('div', { class: 'card-title', text: title }),
      subtitle ? el('div', { class: 'card-subtitle', text: subtitle }) : null,
    ]),
    el('div', { class: 'card-body' }, body),
  ]);
}
