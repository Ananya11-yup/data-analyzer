// screens/table.js — the full dataset, searched / sorted / paged server-side so
// what's on screen always matches an export. Reads /rows, links /export.

import { el, clear, fmtCell, fmtInt, toast, setBusy, debounce, screenHead } from '../ui.js';
import * as api from '../api.js';
import { state } from '../state.js';

export async function render(outlet) {
  const d = state.dataset;
  const cols = d.columns || [];
  const t = state.table; // preserved across visits to this screen

  const search = el('input', { class: 'input', type: 'search', placeholder: 'Search all columns…', value: t.search || '' });
  const sizeSel = el('select', { class: 'select' },
    [10, 25, 50, 100].map((n) => el('option', { value: String(n), selected: n === t.limit ? true : null }, [`${n} / page`])));
  const prev = el('button', { class: 'button ghost', type: 'button', text: '‹ Prev' });
  const next = el('button', { class: 'button ghost', type: 'button', text: 'Next ›' });
  const pageInfo = el('span', { class: 'pager-info' });
  const tableHost = el('div', { class: 'table-wrap' });

  const exportBtn = (fmt) => el('a', {
    class: 'button soft', href: api.exportUrl(d.id, fmt), download: '',
  }, [`Export ${fmt.toUpperCase()}`]);

  function renderTable() {
    clear(tableHost);
    if (!t.rows.length) {
      tableHost.appendChild(el('p', { class: 'muted pad', text: t.search ? 'No rows match your search.' : 'No rows to show.' }));
      return;
    }
    const thead = el('thead', {}, [el('tr', {}, cols.map((c) => {
      const active = t.sort_by === c;
      const arrow = active ? (t.sort_dir === 'asc' ? ' ▲' : ' ▼') : '';
      const th = el('th', { class: `sortable${active ? ' active' : ''}`, title: `Sort by ${c}` }, [c + arrow]);
      th.addEventListener('click', () => {
        if (t.sort_by === c) t.sort_dir = t.sort_dir === 'asc' ? 'desc' : 'asc';
        else { t.sort_by = c; t.sort_dir = 'asc'; }
        t.offset = 0;
        load();
      });
      return th;
    }))]);
    const tbody = el('tbody', {}, t.rows.map((row) => el('tr', {},
      cols.map((c) => el('td', { class: typeof row[c] === 'number' ? 'num' : null, text: fmtCell(row[c]) })))));
    tableHost.appendChild(el('table', { class: 'data-table' }, [thead, tbody]));
  }
  function renderPager() {
    const from = t.total ? t.offset + 1 : 0;
    const to = Math.min(t.offset + t.limit, t.total);
    pageInfo.textContent = `${fmtInt(from)}–${fmtInt(to)} of ${fmtInt(t.total)}`;
    prev.disabled = t.offset <= 0;
    next.disabled = t.offset + t.limit >= t.total;
  }

  async function load() {
    setBusy(true, 'Loading rows…');
    try {
      const res = await api.fetchRows(d.id, {
        search: t.search, sort_by: t.sort_by, sort_dir: t.sort_dir, offset: t.offset, limit: t.limit,
      });
      t.total = res.total; t.rows = res.rows || []; t.offset = res.offset; t.limit = res.limit;
      renderTable();
      renderPager();
    } catch (err) {
      if (err instanceof api.ApiError && err.status === 404) { toast('Dataset expired — please re-import.', 'error'); window.__nav.navigate('/import'); return; }
      toast(err && err.message ? err.message : 'Could not load rows.', 'error');
    } finally { setBusy(false); }
  }

  search.addEventListener('input', debounce(() => { t.search = search.value.trim(); t.offset = 0; load(); }, 300));
  sizeSel.addEventListener('change', () => { t.limit = Number(sizeSel.value) || 25; t.offset = 0; load(); });
  prev.addEventListener('click', () => { t.offset = Math.max(0, t.offset - t.limit); load(); });
  next.addEventListener('click', () => { t.offset += t.limit; load(); });

  outlet.appendChild(el('div', { class: 'screen' }, [
    screenHead('Data Table', `${fmtInt(d.shape ? d.shape.rows : 0)} rows × ${cols.length} columns`, [exportBtn('csv'), exportBtn('json')]),
    el('div', { class: 'toolbar' }, [
      el('div', { class: 'field grow' }, [search]),
      el('div', { class: 'toolbar-group' }, [sizeSel, prev, pageInfo, next]),
    ]),
    tableHost,
  ]));

  await load();
}
