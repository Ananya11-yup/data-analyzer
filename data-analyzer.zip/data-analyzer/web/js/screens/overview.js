// screens/overview.js — dataset profile at a glance: KPI strip, missingness &
// dtype breakdown, and the numeric describe() table. Reads /analyze (summary).

import { el, fmtInt, fmtNum, fmtPct, emptyState, screenHead, panel } from '../ui.js';
import * as api from '../api.js';
import { state, setSummary } from '../state.js';

async function ensureSummary() {
  if (state.summary) return state.summary;
  const s = await api.analyze(state.dataset.id);
  setSummary(s);
  return s;
}

const kpi = (label, value, sub) => el('div', { class: 'kpi' }, [
  el('div', { class: 'kpi-value', text: value }),
  el('div', { class: 'kpi-label', text: label }),
  sub != null ? el('div', { class: 'kpi-sub', text: sub }) : null,
]);

function kpiStrip(s) {
  const cells = s.shape.rows * s.shape.columns;
  const missing = Object.values(s.missing_values || {}).reduce((a, b) => a + Number(b || 0), 0);
  return el('div', { class: 'kpi-grid' }, [
    kpi('Rows', fmtInt(s.shape.rows)),
    kpi('Columns', fmtInt(s.shape.columns)),
    kpi('Numeric', fmtInt((s.numeric_columns || []).length)),
    kpi('Categorical', fmtInt((s.categorical_columns || []).length)),
    kpi('Duplicate rows', fmtInt(s.duplicate_rows || 0)),
    kpi('Missing cells', fmtPct(cells ? (missing / cells) * 100 : 0), `${fmtInt(missing)} of ${fmtInt(cells)}`),
  ]);
}
function missingness(s) {
  const rows = Object.entries(s.missing_pct || {})
    .map(([c, p]) => ({ c, p: Number(p) }))
    .filter((x) => x.p > 0)
    .sort((a, b) => b.p - a.p)
    .slice(0, 8);
  if (!rows.length) return el('p', { class: 'muted', text: 'No missing values — every cell is populated.' });
  return el('div', { class: 'meter-list' }, rows.map((x) => el('div', { class: 'meter-row' }, [
    el('div', { class: 'meter-label', text: x.c }),
    el('div', { class: 'meter' }, [el('span', { class: 'meter-fill', style: `width:${Math.max(2, x.p).toFixed(1)}%` })]),
    el('div', { class: 'meter-val', text: fmtPct(x.p) }),
  ])));
}

function dtypes(s) {
  const counts = {};
  Object.values(s.dtypes || {}).forEach((t) => { counts[t] = (counts[t] || 0) + 1; });
  const entries = Object.entries(counts).sort((a, b) => b[1] - a[1]);
  if (!entries.length) return el('p', { class: 'muted', text: 'No column type information.' });
  return el('div', { class: 'chip-list' }, entries.map(([t, n]) => el('span', { class: 'chip' }, [
    el('span', { class: 'chip-key', text: t }), el('span', { class: 'chip-val', text: String(n) }),
  ])));
}

const STAT_KEYS = ['count', 'mean', 'std', 'min', '25%', '50%', '75%', 'max'];
function describeTable(s) {
  const cols = Object.keys(s.describe || {});
  if (!cols.length) return emptyState('No numeric columns', 'The describe() summary needs at least one numeric column.');
  const head = el('tr', {}, [el('th', { text: 'Column' }), ...STAT_KEYS.map((k) => el('th', { class: 'num', text: k }))]);
  const body = cols.map((c) => el('tr', {}, [
    el('td', { class: 'strong', text: c }),
    ...STAT_KEYS.map((k) => el('td', { class: 'num', text: k === 'count' ? fmtInt(s.describe[c][k]) : fmtNum(s.describe[c][k]) })),
  ]));
  return el('div', { class: 'table-wrap' }, [el('table', { class: 'data-table' }, [el('thead', {}, [head]), el('tbody', {}, body)])]);
}

export async function render(outlet) {
  const s = await ensureSummary();
  const d = state.dataset || { source: 'dataset' };
  const sub = `${d.source || 'dataset'} · ${fmtInt(s.shape.rows)} rows × ${fmtInt(s.shape.columns)} columns${s.sampled ? ` · analysed a ${fmtInt(s.sample_rows)}-row sample` : ''}`;
  outlet.appendChild(el('div', { class: 'screen' }, [
    screenHead('Overview', sub),
    kpiStrip(s),
    el('div', { class: 'two-column' }, [
      panel('Missing values', [missingness(s)]),
      panel('Column types', [dtypes(s)]),
    ]),
    panel('Numeric summary', [describeTable(s)]),
  ]));
}
