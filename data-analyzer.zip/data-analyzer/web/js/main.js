// main.js — bootstrap. Restores theme + API base, builds the nav from the route
// registry, polls /health for the status pill, loads server limits, rehydrates
// a dataset saved in this tab (re-analysing it), then starts the router.

import { $, el, toast, setBusy } from './ui.js';
import * as api from './api.js';
import {
  state, on, getTheme, setThemePref, setLimits,
  setDatasetMeta, setSummary, clearDataset, hasDataset, restoreDatasetMeta,
} from './state.js';
import { ROUTES, startRouter, navigate, refresh } from './router.js';

// ---- Theme ----
function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  const btn = $('#themeToggle');
  if (btn) {
    btn.textContent = theme === 'dark' ? '☾' : '☀';
    btn.setAttribute('aria-label', theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme');
    btn.title = btn.getAttribute('aria-label');
  }
}
function toggleTheme() {
  const next = getTheme() === 'dark' ? 'light' : 'dark';
  setThemePref(next);
  applyTheme(next);
}

// ---- Nav ----
function buildNav() {
  const nav = $('#nav');
  if (!nav) return;
  nav.innerHTML = '';
  ROUTES.forEach((r) => {
    const a = el('a', {
      class: 'tab', 'data-route': r.path, href: '#' + r.path,
    }, [el('span', { class: 'tab-icon', 'aria-hidden': 'true', text: r.icon }), r.label]);
    nav.appendChild(a);
  });
  syncNavLocks();
}

/** Grey out data-requiring tabs until a dataset is loaded (router still guards). */
function syncNavLocks() {
  const ok = hasDataset();
  document.querySelectorAll('#nav .tab').forEach((a) => {
    const route = ROUTES.find((r) => r.path === a.getAttribute('data-route'));
    a.classList.toggle('locked', !!(route && route.needsData && !ok));
  });
}

// ---- Health pill ----
function setStatus(kind, label) {
  const pill = $('#statusPill');
  if (!pill) return;
  pill.className = `status-pill status-${kind}`;
  const t = $('#statusText');
  if (t) t.textContent = label;
}
async function pollHealth() {
  try {
    await api.health();
    setStatus('ok', 'Backend online');
  } catch {
    setStatus('down', 'Backend offline');
  }
}

// ---- Dataset rehydrate ----
async function restoreDataset() {
  const meta = restoreDatasetMeta();
  if (!meta) return;
  setDatasetMeta(meta);
  try {
    const summary = await api.analyze(meta.id);
    setSummary(summary);
  } catch (err) {
    // Dataset expired server-side (1h TTL) → drop it and land on Import.
    if (err instanceof api.ApiError && err.status === 404) {
      clearDataset();
      toast('Your previous dataset expired. Please load it again.', 'info');
      if (location.hash && location.hash !== '#/import') navigate('/import');
    }
  }
}

async function boot() {
  applyTheme(getTheme());
  buildNav();

  const themeBtn = $('#themeToggle');
  if (themeBtn) themeBtn.addEventListener('click', toggleTheme);

  // React to dataset changes anywhere in the app.
  on('dataset', () => { syncNavLocks(); });
  on('summary', () => { syncNavLocks(); });

  // Limits + health can load in parallel; neither blocks first paint.
  api.fetchLimits().then(setLimits).catch(() => { /* keep DEFAULT_LIMITS */ });
  pollHealth();
  setInterval(pollHealth, 15000);

  // Rehydrate before routing so a deep-link like #/overview has its data.
  setBusy(true, 'Restoring session…');
  try { await restoreDataset(); } finally { setBusy(false); }

  startRouter($('#view'), () => syncNavLocks());
}

// expose a couple of helpers screens use to move between routes / re-render.
window.__nav = { navigate, refresh };

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();
