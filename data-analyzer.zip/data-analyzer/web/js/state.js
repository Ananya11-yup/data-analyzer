// state.js — shared in-memory app state, persistence, and a tiny pub/sub.

export const DEFAULT_LIMITS = {
  max_upload_mb: 500,
  max_scrape_mb: 5,
  scrape_worst_case_seconds: 150,
  preview_rows: 50,
  palettes: ['deep', 'pastel', 'muted', 'Blues', 'mako', 'viridis', 'coolwarm',
    'rocket', 'flare', 'crest', 'magma', 'cubehelix', 'Set2', 'husl'],
  chart_types: ['bar', 'line', 'scatter', 'histogram', 'kde', 'box', 'violin',
    'area', 'heatmap', 'pie', 'count', 'pairplot'],
  chart_types_needing_y: ['area', 'line', 'scatter'],
  chart_types_ignoring_y: ['count', 'heatmap', 'histogram', 'kde', 'pairplot', 'pie'],
  chart_size: {
    min_width: 4, max_width: 20, default_width: 10,
    min_height: 3, max_height: 14, default_height: 6,
    min_dpi: 72, max_dpi: 200, default_dpi: 110,
  },
};

const DATASET_KEY = 'dataAnalyzerDataset'; // sessionStorage (per-tab)
const THEME_KEY = 'dataAnalyzerTheme';     // localStorage

const freshTable = () => ({ search: '', sort_by: null, sort_dir: 'asc', offset: 0, limit: 25, total: 0, rows: [] });

export const state = {
  dataset: null,  // {id, source, columns[], shape:{rows,columns}, preview[], preview_rows}
  summary: null,  // /analyze response
  limits: DEFAULT_LIMITS,
  table: freshTable(),
  history: [],    // saved matplotlib charts (Charts screen → Reports gallery)
};

// ---- pub/sub: screens & nav react to 'dataset' / 'summary' / 'limits' / 'history' ----
const listeners = new Map();
export function on(evt, fn) {
  if (!listeners.has(evt)) listeners.set(evt, new Set());
  listeners.get(evt).add(fn);
  return () => listeners.get(evt)?.delete(fn);
}
export function emit(evt, data) {
  (listeners.get(evt) || []).forEach((fn) => { try { fn(data); } catch (e) { console.error(e); } });
}

export const hasDataset = () => !!(state.dataset && state.dataset.id);
export function setDataset(ingest) {
  state.dataset = {
    id: ingest.dataset_id,
    source: ingest.source,
    columns: ingest.columns || [],
    shape: ingest.shape || { rows: 0, columns: 0 },
    preview: ingest.preview || [],
    preview_rows: ingest.preview_rows || 0,
  };
  state.summary = null;
  state.table = freshTable();
  state.history = [];
  persistDataset();
  emit('dataset', state.dataset);
}

/** Merge extra fields into the current dataset (used when restoring a tab). */
export function setDatasetMeta(meta) {
  state.dataset = { ...(state.dataset || {}), ...meta };
  persistDataset();
  emit('dataset', state.dataset);
}

export function clearDataset() {
  state.dataset = null;
  state.summary = null;
  state.history = [];
  state.table = freshTable();
  try { sessionStorage.removeItem(DATASET_KEY); } catch { /* ignore */ }
  emit('dataset', null);
}

export function setSummary(summary) { state.summary = summary; emit('summary', summary); }
export function setLimits(limits) { state.limits = { ...DEFAULT_LIMITS, ...limits }; emit('limits', state.limits); }

export function addHistory(entry) {
  state.history.unshift(entry);
  if (state.history.length > 24) state.history.length = 24;
  emit('history', state.history);
}
export function removeHistory(id) {
  state.history = state.history.filter((h) => h.id !== id);
  emit('history', state.history);
}

function persistDataset() {
  if (!state.dataset) return;
  try {
    sessionStorage.setItem(DATASET_KEY, JSON.stringify({
      id: state.dataset.id,
      source: state.dataset.source,
      columns: state.dataset.columns,
      shape: state.dataset.shape,
    }));
  } catch { /* storage disabled — restore just won't work, no crash */ }
}

/** Returns {id, source, columns, shape} from a previous load in this tab, or null. */
export function restoreDatasetMeta() {
  try {
    const d = JSON.parse(sessionStorage.getItem(DATASET_KEY) || 'null');
    return d && d.id ? d : null;
  } catch { return null; }
}

export const getTheme = () => localStorage.getItem(THEME_KEY) || 'light';
export const setThemePref = (t) => localStorage.setItem(THEME_KEY, t);
