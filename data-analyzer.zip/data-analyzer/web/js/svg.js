// svg.js — dependency-free, theme-aware chart primitives. Inline SVG inherits
// CSS custom properties (var(--series-N) etc.), so charts recolour instantly
// when the theme toggles — no re-render, no external chart library, works
// fully offline. All renderers clear the container and append one <svg>.

const NS = 'http://www.w3.org/2000/svg';

function svgEl(tag, attrs = {}) {
  const n = document.createElementNS(NS, tag);
  for (const [k, v] of Object.entries(attrs)) if (v != null) n.setAttribute(k, String(v));
  return n;
}

function text(x, y, str, attrs = {}) {
  const t = svgEl('text', { x, y, ...attrs });
  t.textContent = str;
  return t;
}

/** Categorical series colour (defined as --series-1..8 in styles.css). */
export const seriesColor = (i) => `var(--series-${(Number(i) % 8) + 1})`;


// ---- Shared hover layer: one floating tooltip per chart, hot-mark focus ----
// Each mark carries a <title>; on first hover it is moved into data-tip so the
// slow native tooltip never competes with ours. Works for every renderer below.
const tips = new WeakMap();
function tipFor(container) {
  if (getComputedStyle(container).position === 'static') container.style.position = 'relative';
  let t = tips.get(container);
  if (!t || !t.isConnected) {
    t = document.createElement('div');
    t.className = 'chart-tip'; t.setAttribute('role', 'tooltip'); t.hidden = true;
    container.appendChild(t); tips.set(container, t);
  }
  return t;
}
export function showTip(container, text, e) {
  const t = tipFor(container), b = container.getBoundingClientRect();
  t.textContent = text; t.hidden = false;
  let x = e.clientX - b.left + 14;
  if (x + t.offsetWidth > b.width) x = e.clientX - b.left - t.offsetWidth - 14;
  t.style.transform = `translate(${Math.max(0, x)}px, ${Math.max(0, e.clientY - b.top + 14)}px)`;
}
export function hideTip(container) { const t = tips.get(container); if (t) t.hidden = true; }
function bindTip(container, svg) {
  let hot = null;
  const clearHot = () => { if (hot) hot.classList.remove('is-hot'); hot = null; svg.classList.remove('has-hot'); hideTip(container); };
  svg.addEventListener('pointermove', (e) => {
    const t = e.target;
    if (t.classList && t.classList.contains('chart-hit')) return;
    const ti = t.querySelector && t.querySelector(':scope > title');
    if (ti) { t.dataset.tip = ti.textContent; ti.remove(); }
    const n = t.dataset && t.dataset.tip ? t : null;
    if (n !== hot) { if (hot) hot.classList.remove('is-hot'); hot = n; svg.classList.toggle('has-hot', !!n); if (n) n.classList.add('is-hot'); }
    if (n) showTip(container, n.dataset.tip, e); else hideTip(container);
  });
  svg.addEventListener('pointerleave', clearHot);
}

function frame(container, { w = 640, h = 360, m = { t: 14, r: 16, b: 42, l: 54 } } = {}) {
  container.innerHTML = '';
  const svg = svgEl('svg', {
    viewBox: `0 0 ${w} ${h}`, class: 'chart-svg',
    preserveAspectRatio: 'xMidYMid meet', role: 'img',
  });
  container.appendChild(svg);
  bindTip(container, svg);
  return { svg, w, h, m, iw: w - m.l - m.r, ih: h - m.t - m.b };
}

function empty(container, msg) {
  container.innerHTML = `<p class="chart-empty">${msg || 'Nothing to plot.'}</p>`;
}

/** Round a positive max up to a friendly 1/2/5×10ⁿ value for axis scaling. */
function niceMax(v) {
  if (!Number.isFinite(v) || v <= 0) return 1;
  const mag = Math.pow(10, Math.floor(Math.log10(v)));
  const n = v / mag;
  const step = n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10;
  return step * mag;
}

const axisTicks = (max, count = 4) => Array.from({ length: count + 1 }, (_, i) => (max * i) / count);

const truncate = (s, n = 18) => { s = String(s); return s.length > n ? s.slice(0, n - 1) + '…' : s; };

/** Horizontal bars — the workhorse for category counts, feature importances,
 *  cluster sizes. Long category labels read far better on the y-axis. */
export function hbar(container, data, opts = {}) {
  const { valueFmt = String, color = 'var(--accent)', empty: msg } = opts;
  if (!data || !data.length) return empty(container, msg);
  const rows = data.slice(0, 25);
  const h = Math.max(180, 34 + rows.length * 30);
  const { svg, m, iw, ih } = frame(container, { w: 640, h, m: { t: 12, r: 54, b: 30, l: 132 } });
  const max = niceMax(Math.max(0, ...rows.map((d) => Number(d.value) || 0)));
  const g = svgEl('g', { transform: `translate(${m.l},${m.t})` });
  svg.appendChild(g);

  axisTicks(max).forEach((tv) => {
    const x = (tv / max) * iw;
    g.appendChild(svgEl('line', { x1: x, y1: 0, x2: x, y2: ih, class: 'chart-grid' }));
    g.appendChild(text(x, ih + 18, valueFmt(tv), { class: 'chart-axis', 'text-anchor': 'middle' }));
  });

  const band = ih / rows.length;
  const bh = Math.min(24, band * 0.68);
  rows.forEach((d, i) => {
    const v = Number(d.value) || 0;
    const y = i * band + (band - bh) / 2;
    const bw = Math.max(0, (v / max) * iw);
    const bar = svgEl('rect', { x: 0, y, width: bw, height: bh, rx: 3, fill: d.color || color, class: 'chart-bar' });
    bar.appendChild(svgEl('title', {})).textContent = `${d.label}: ${valueFmt(v)}`;
    g.appendChild(bar);
    g.appendChild(text(-10, y + bh / 2 + 4, truncate(d.label), { class: 'chart-axis', 'text-anchor': 'end' }));
    g.appendChild(text(bw + 6, y + bh / 2 + 4, valueFmt(v), { class: 'chart-val' }));
  });
  return svg;
}
/** Vertical bars — histograms and short-label counts. Labels thin out
 *  automatically so a 60-bin histogram doesn't smear its x-axis. */
export function vbars(container, data, opts = {}) {
  const { valueFmt = String, color = 'var(--accent)', empty: msg } = opts;
  if (!data || !data.length) return empty(container, msg);
  const { svg, m, iw, ih } = frame(container, { w: 640, h: 340, m: { t: 14, r: 14, b: 46, l: 54 } });
  const max = niceMax(Math.max(0, ...data.map((d) => Number(d.value) || 0)));
  const g = svgEl('g', { transform: `translate(${m.l},${m.t})` });
  svg.appendChild(g);

  axisTicks(max).forEach((tv) => {
    const y = ih - (tv / max) * ih;
    g.appendChild(svgEl('line', { x1: 0, y1: y, x2: iw, y2: y, class: 'chart-grid' }));
    g.appendChild(text(-8, y + 4, valueFmt(tv), { class: 'chart-axis', 'text-anchor': 'end' }));
  });

  const band = iw / data.length;
  const bw = Math.max(1, band * (data.length > 30 ? 0.9 : 0.72));
  const step = Math.ceil(data.length / 10);
  data.forEach((d, i) => {
    const v = Number(d.value) || 0;
    const bh = Math.max(0, (v / max) * ih);
    const x = i * band + (band - bw) / 2;
    const bar = svgEl('rect', { x, y: ih - bh, width: bw, height: bh, rx: 2, fill: color, class: 'chart-bar' });
    bar.appendChild(svgEl('title', {})).textContent = `${d.label}: ${valueFmt(v)}`;
    g.appendChild(bar);
    if (i % step === 0) g.appendChild(text(x + bw / 2, ih + 18, truncate(d.label, 10), { class: 'chart-axis', 'text-anchor': 'middle' }));
  });
  return svg;
}
/** Line / area over an ordered series. x is positional (evenly spaced by
 *  index), so it takes numeric, date-string or category x without parsing. */
export function line(container, series, opts = {}) {
  const { area = false, valueFmt = String, color = 'var(--accent)', empty: msg } = opts;
  const pts = (series || []).filter((p) => Number.isFinite(Number(p.y)));
  if (pts.length < 2) return empty(container, msg || 'Need at least two points.');
  const { svg, m, iw, ih } = frame(container, { w: 640, h: 340, m: { t: 16, r: 18, b: 44, l: 58 } });
  const ys = pts.map((p) => Number(p.y));
  const lo = Math.min(0, ...ys);
  const hi = niceMax(Math.max(...ys, 0.0001));
  const span = hi - lo || 1;
  const X = (i) => (pts.length === 1 ? iw / 2 : (i / (pts.length - 1)) * iw);
  const Y = (v) => ih - ((v - lo) / span) * ih;
  const g = svgEl('g', { transform: `translate(${m.l},${m.t})` });
  svg.appendChild(g);

  axisTicks(hi - lo).forEach((t0) => {
    const v = lo + t0;
    const y = Y(v);
    g.appendChild(svgEl('line', { x1: 0, y1: y, x2: iw, y2: y, class: 'chart-grid' }));
    g.appendChild(text(-10, y + 4, valueFmt(v), { class: 'chart-axis', 'text-anchor': 'end' }));
  });
  const step = Math.ceil(pts.length / 8);
  pts.forEach((p, i) => {
    if (i % step === 0 || i === pts.length - 1) g.appendChild(text(X(i), ih + 18, truncate(p.x, 10), { class: 'chart-axis', 'text-anchor': 'middle' }));
  });

  const d = pts.map((p, i) => `${i ? 'L' : 'M'}${X(i).toFixed(1)},${Y(Number(p.y)).toFixed(1)}`).join(' ');
  if (area) g.appendChild(svgEl('path', { d: `${d} L${X(pts.length - 1)},${Y(lo)} L${X(0)},${Y(lo)} Z`, fill: color, 'fill-opacity': 0.16 }));
  g.appendChild(svgEl('path', { d, fill: 'none', stroke: color, 'stroke-width': 2.2, 'stroke-linejoin': 'round', class: 'chart-line' }));
  pts.forEach((p, i) => {
    const dot = svgEl('circle', { cx: X(i), cy: Y(Number(p.y)), r: pts.length > 60 ? 0 : 3, fill: color });
    dot.appendChild(svgEl('title', {})).textContent = `${p.x}: ${valueFmt(Number(p.y))}`;
    g.appendChild(dot);
  });
  // Crosshair: snaps to the nearest point anywhere in the plot, even at 1000+ points.
  const guide = svgEl('line', { y1: 0, y2: ih, class: 'chart-guide', visibility: 'hidden' });
  const mark = svgEl('circle', { r: 5, fill: color, class: 'chart-mark', visibility: 'hidden' });
  const hit = svgEl('rect', { x: 0, y: 0, width: iw, height: ih, fill: 'transparent', class: 'chart-hit' });
  hit.addEventListener('pointermove', (e) => {
    const r = hit.getBoundingClientRect();
    const i = Math.max(0, Math.min(pts.length - 1, Math.round(((e.clientX - r.left) / r.width) * (pts.length - 1))));
    guide.setAttribute('x1', X(i)); guide.setAttribute('x2', X(i));
    mark.setAttribute('cx', X(i)); mark.setAttribute('cy', Y(Number(pts[i].y)));
    guide.removeAttribute('visibility'); mark.removeAttribute('visibility');
    showTip(container, `${pts[i].x}: ${valueFmt(Number(pts[i].y))}`, e);
  });
  hit.addEventListener('pointerleave', () => { guide.setAttribute('visibility', 'hidden'); mark.setAttribute('visibility', 'hidden'); hideTip(container); });
  g.append(guide, mark, hit);
  return svg;
}
const polar = (cx, cy, r, a) => [cx + r * Math.cos(a), cy + r * Math.sin(a)];
function arc(cx, cy, r, r0, a0, a1) {
  const large = a1 - a0 > Math.PI ? 1 : 0;
  const [x0, y0] = polar(cx, cy, r, a0), [x1, y1] = polar(cx, cy, r, a1);
  if (!r0) return `M${cx},${cy} L${x0},${y0} A${r},${r} 0 ${large} 1 ${x1},${y1} Z`;
  const [xi0, yi0] = polar(cx, cy, r0, a1), [xi1, yi1] = polar(cx, cy, r0, a0);
  return `M${x0},${y0} A${r},${r} 0 ${large} 1 ${x1},${y1} L${xi0},${yi0} A${r0},${r0} 0 ${large} 0 ${xi1},${yi1} Z`;
}

/** Pie / donut with a side legend. data = [{label, value, pct?}]. */
export function donut(container, data, opts = {}) {
  const { donut: hole = true, valueFmt = String, empty: msg } = opts;
  const rows = (data || []).filter((d) => Number(d.value) > 0).slice(0, 8);
  if (!rows.length) return empty(container, msg);
  const { svg } = frame(container, { w: 640, h: 340, m: { t: 0, r: 0, b: 0, l: 0 } });
  const cx = 160, cy = 170, r = 128, r0 = hole ? 66 : 0;
  const total = rows.reduce((s, d) => s + Number(d.value), 0) || 1;
  let a = -Math.PI / 2;
  rows.forEach((d, i) => {
    const frac = Number(d.value) / total;
    const a1 = a + frac * Math.PI * 2;
    const path = svgEl('path', { d: arc(cx, cy, r, r0, a, a1 - 0.004), fill: seriesColor(i), class: 'chart-slice' });
    const pct = d.pct != null ? Number(d.pct) : frac * 100;
    path.appendChild(svgEl('title', {})).textContent = `${d.label}: ${valueFmt(Number(d.value))} (${pct.toFixed(1)}%)`;
    svg.appendChild(path);
    a = a1;
  });
  if (hole) svg.appendChild(text(cx, cy + 5, valueFmt(total), { class: 'chart-center', 'text-anchor': 'middle' }));

  const lx = 340;
  rows.forEach((d, i) => {
    const ly = 44 + i * 34;
    svg.appendChild(svgEl('rect', { x: lx, y: ly - 11, width: 14, height: 14, rx: 3, fill: seriesColor(i) }));
    const pct = d.pct != null ? Number(d.pct) : (Number(d.value) / total) * 100;
    svg.appendChild(text(lx + 22, ly, `${truncate(d.label, 22)}  ·  ${pct.toFixed(1)}%`, { class: 'chart-legend' }));
  });
  return svg;
}
/** Heatmap for correlations (diverging −1..+1) and confusion matrices
 *  (sequential 0..max). Cell opacity encodes magnitude over the themed card
 *  background, so it reads correctly in both light and dark without a JS
 *  colour ramp. rows/cols are label arrays; matrix is rows×cols. */
export function heatmap(container, { rows, cols, matrix }, opts = {}) {
  const { diverging = true, valueFmt = (v) => v, max = 1, empty: msg } = opts;
  if (!rows || !cols || !matrix || !rows.length || !cols.length) return empty(container, msg);
  const cell = Math.max(26, Math.min(52, Math.floor(520 / cols.length)));
  const padL = 108, padT = 92;
  const w = padL + cols.length * cell + 12;
  const h = padT + rows.length * cell + 12;
  const { svg } = frame(container, { w, h, m: { t: 0, r: 0, b: 0, l: 0 } });
  const small = cell < 34;

  cols.forEach((c, j) => {
    const x = padL + j * cell + cell / 2;
    svg.appendChild(text(x, padT - 8, truncate(c, small ? 6 : 10), {
      class: 'chart-axis', 'text-anchor': 'start', transform: `rotate(-42 ${x} ${padT - 8})`,
    }));
  });
  rows.forEach((rlab, i) => {
    svg.appendChild(text(padL - 8, padT + i * cell + cell / 2 + 4, truncate(rlab, 13), { class: 'chart-axis', 'text-anchor': 'end' }));
    (matrix[i] || []).forEach((raw, j) => {
      const v = Number(raw);
      const x = padL + j * cell, y = padT + i * cell;
      const mag = diverging ? Math.min(1, Math.abs(v)) : Math.min(1, (v || 0) / (max || 1));
      const fill = diverging ? (v < 0 ? 'var(--coral)' : 'var(--teal)') : 'var(--teal)';
      const r = svgEl('rect', { x: x + 1, y: y + 1, width: cell - 2, height: cell - 2, rx: 3, fill, 'fill-opacity': Number.isFinite(v) ? (0.08 + mag * 0.86).toFixed(3) : 0 });
      r.appendChild(svgEl('title', {})).textContent = `${rlab} × ${cols[j]}: ${valueFmt(v)}`;
      svg.appendChild(r);
      if (!small && Number.isFinite(v)) svg.appendChild(text(x + cell / 2, y + cell / 2 + 4, valueFmt(v), {
        'text-anchor': 'middle', class: mag > 0.55 ? 'chart-cell-strong' : 'chart-cell',
      }));
    });
  });
  return svg;
}
/** Scatter for PCA projections (coloured by cluster) and actual-vs-predicted
 *  (single group + y=x identity line). points = [{x, y, group?}]. */
export function scatter(container, points, opts = {}) {
  const { xLabel = '', yLabel = '', identity = false, valueFmt = String, empty: msg } = opts;
  const pts = (points || []).filter((p) => Number.isFinite(Number(p.x)) && Number.isFinite(Number(p.y)));
  if (!pts.length) return empty(container, msg);
  const { svg, m, iw, ih } = frame(container, { w: 640, h: 380, m: { t: 16, r: 18, b: 48, l: 60 } });
  const xs = pts.map((p) => Number(p.x)), ys = pts.map((p) => Number(p.y));
  let xlo = Math.min(...xs), xhi = Math.max(...xs), ylo = Math.min(...ys), yhi = Math.max(...ys);
  if (identity) { const lo = Math.min(xlo, ylo), hi = Math.max(xhi, yhi); xlo = ylo = lo; xhi = yhi = hi; }
  const padX = (xhi - xlo) * 0.05 || 1, padY = (yhi - ylo) * 0.05 || 1;
  xlo -= padX; xhi += padX; ylo -= padY; yhi += padY;
  const X = (v) => ((v - xlo) / (xhi - xlo)) * iw;
  const Y = (v) => ih - ((v - ylo) / (yhi - ylo)) * ih;
  const g = svgEl('g', { transform: `translate(${m.l},${m.t})` });
  svg.appendChild(g);

  for (let i = 0; i <= 4; i++) {
    const gy = ylo + ((yhi - ylo) * i) / 4, y = Y(gy);
    g.appendChild(svgEl('line', { x1: 0, y1: y, x2: iw, y2: y, class: 'chart-grid' }));
    g.appendChild(text(-10, y + 4, valueFmt(gy), { class: 'chart-axis', 'text-anchor': 'end' }));
    const gx = xlo + ((xhi - xlo) * i) / 4;
    g.appendChild(text(X(gx), ih + 18, valueFmt(gx), { class: 'chart-axis', 'text-anchor': 'middle' }));
  }
  if (identity) g.appendChild(svgEl('line', { x1: X(Math.max(xlo, ylo)), y1: Y(Math.max(xlo, ylo)), x2: X(Math.min(xhi, yhi)), y2: Y(Math.min(xhi, yhi)), class: 'chart-identity' }));

  pts.forEach((p) => {
    const c = svgEl('circle', { cx: X(Number(p.x)), cy: Y(Number(p.y)), r: 4, fill: p.group != null ? seriesColor(p.group) : 'var(--accent)', 'fill-opacity': 0.78, class: 'chart-dot' });
    c.appendChild(svgEl('title', {})).textContent = `(${valueFmt(Number(p.x))}, ${valueFmt(Number(p.y))})${p.group != null ? ` · group ${p.group}` : ''}`;
    g.appendChild(c);
  });
  if (xLabel) g.appendChild(text(iw / 2, ih + 40, xLabel, { class: 'chart-axis-title', 'text-anchor': 'middle' }));
  if (yLabel) svg.appendChild(text(16, m.t + ih / 2, yLabel, { class: 'chart-axis-title', 'text-anchor': 'middle', transform: `rotate(-90 16 ${m.t + ih / 2})` }));
  return svg;
}
