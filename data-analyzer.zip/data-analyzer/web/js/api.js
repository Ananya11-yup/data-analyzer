// api.js — same-origin fetch wrapper + one function per backend endpoint.
// The UI is served by FastAPI itself, so requests are same-origin and CORS
// never applies. A stored override is kept for anyone opening the file directly.

const API_KEY = 'dataAnalyzerApi';
const DEFAULT_TIMEOUT = 30000;

export const CANCELLED = 'cancelled';

export class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

export function getApiBase() {
  const stored = (localStorage.getItem(API_KEY) || '').trim();
  if (stored) return stored.replace(/\/+$/, '');
  // file:// has no usable origin to call, so fall back to the default port.
  if (location.protocol === 'file:') return 'http://localhost:8010/api';
  return `${location.origin}/api`;
}

export function setApiBase(value) {
  const v = (value || '').trim().replace(/\/+$/, '');
  if (v) localStorage.setItem(API_KEY, v);
  else localStorage.removeItem(API_KEY);
}

/** FastAPI/Pydantic 422 returns `detail` as an array of {loc,msg,type}; the old
 *  UI rendered that as "[object Object]". Flatten it to a readable sentence. */
function readableDetail(detail, fallback) {
  if (Array.isArray(detail)) {
    const msgs = detail
      .map((d) => {
        const loc = Array.isArray(d.loc) ? d.loc.filter((p) => p !== 'body').join('.') : '';
        return loc ? `${loc}: ${d.msg}` : d.msg;
      })
      .filter(Boolean);
    return msgs.join('; ') || fallback;
  }
  if (typeof detail === 'string') return detail;
  return fallback;
}
export async function api(path, opts = {}) {
  const { method = 'GET', body, timeout = DEFAULT_TIMEOUT, signal, form } = opts;
  const ctrl = new AbortController();
  const onAbort = () => ctrl.abort();
  if (signal) {
    if (signal.aborted) ctrl.abort();
    else signal.addEventListener('abort', onAbort);
  }
  const timer = timeout ? setTimeout(() => ctrl.abort('timeout'), timeout) : null;

  const headers = {};
  let payload;
  if (form) payload = form;
  else if (body !== undefined) {
    headers['Content-Type'] = 'application/json';
    payload = JSON.stringify(body);
  }

  try {
    const res = await fetch(getApiBase() + path, { method, headers, body: payload, signal: ctrl.signal });
    let data = null;
    if ((res.headers.get('Content-Type') || '').includes('application/json')) {
      try { data = await res.json(); } catch { data = null; }
    }
    if (!res.ok) {
      throw new ApiError(readableDetail(data && data.detail, `Request failed (${res.status}).`), res.status);
    }
    return data;
  } catch (err) {
    if (err instanceof ApiError) throw err;
    if (err && (err.name === 'AbortError' || ctrl.signal.aborted)) {
      const viaTimeout = ctrl.signal.reason === 'timeout';
      throw new ApiError(viaTimeout ? 'That took longer than expected and was stopped.' : CANCELLED);
    }
    throw new ApiError(err.message || 'Network error — is the backend running?');
  } finally {
    if (timer) clearTimeout(timer);
    if (signal) signal.removeEventListener('abort', onAbort);
  }
}

/** Upload via XHR so we get real progress events and abort support. */
export function uploadFile(file, onProgress, signal) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', getApiBase() + '/upload');
    xhr.responseType = 'json';
    xhr.upload.onprogress = (e) => {
      if (onProgress && e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100));
    };
    xhr.onload = () => {
      const data = xhr.response;
      if (xhr.status >= 200 && xhr.status < 300) resolve(data);
      else reject(new ApiError(readableDetail(data && data.detail, `Upload failed (${xhr.status}).`), xhr.status));
    };
    xhr.onerror = () => reject(new ApiError('Network error during upload.'));
    xhr.onabort = () => reject(new ApiError(CANCELLED));
    if (signal) {
      if (signal.aborted) xhr.abort();
      else signal.addEventListener('abort', () => xhr.abort());
    }
    const form = new FormData();
    form.append('file', file);
    xhr.send(form);
  });
}
// ---- One function per endpoint (see backend/main.py for the contract) ----

export const health = (signal) => api('/health', { timeout: 8000, signal });
export const fetchLimits = () => api('/limits', { timeout: 8000 });

export const scrape = (url, signal, timeout) =>
  api('/scrape', { method: 'POST', body: { url }, timeout, signal });

export const paste = (text, signal) =>
  api('/paste', { method: 'POST', body: { text }, timeout: 60000, signal });

export const analyze = (datasetId, signal) =>
  api('/analyze', { method: 'POST', body: { dataset_id: datasetId }, timeout: 120000, signal });

export function fetchRows(datasetId, q = {}, signal) {
  const p = new URLSearchParams();
  if (q.search) p.set('search', q.search);
  if (q.sort_by) p.set('sort_by', q.sort_by);
  p.set('sort_dir', q.sort_dir || 'asc');
  p.set('offset', String(q.offset ?? 0));
  p.set('limit', String(q.limit ?? 25));
  return api(`/rows/${encodeURIComponent(datasetId)}?${p.toString()}`, { signal });
}

export const visualize = (req, signal, timeout = 120000) =>
  api('/visualize', { method: 'POST', body: req, timeout, signal });

export const chartData = (req, signal) =>
  api('/chart-data', { method: 'POST', body: req, timeout: 30000, signal });

export const mlTrain = (datasetId, target, signal) =>
  api('/ml/train', { method: 'POST', body: { dataset_id: datasetId, target }, timeout: 120000, signal });

export const mlCluster = (datasetId, k, signal) =>
  api('/ml/cluster', { method: 'POST', body: { dataset_id: datasetId, k: k ?? undefined }, timeout: 120000, signal });

export const mlAnomalies = (datasetId, contamination, signal) =>
  api('/ml/anomalies', {
    method: 'POST',
    body: { dataset_id: datasetId, contamination: contamination ?? undefined },
    timeout: 120000,
    signal,
  });

export const exportUrl = (datasetId, fmt) =>
  `${getApiBase()}/export/${encodeURIComponent(datasetId)}?fmt=${encodeURIComponent(fmt)}`;
