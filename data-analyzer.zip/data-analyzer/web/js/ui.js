// ui.js — DOM helpers, formatting, toast + busy overlay. Zero dependencies.

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

export function clear(node) {
  while (node && node.firstChild) node.removeChild(node.firstChild);
  return node;
}

/** Tiny hyperscript: el('div', {class:'card', onclick:fn}, [child, 'text']). */
export function el(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') node.className = v;
    else if (k === 'html') node.innerHTML = v;
    else if (k === 'text') node.textContent = v;
    else if (k === 'dataset') Object.assign(node.dataset, v);
    else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2).toLowerCase(), v);
    else node.setAttribute(k, v === true ? '' : String(v));
  }
  for (const child of [].concat(children)) {
    if (child == null || child === false) continue;
    node.appendChild(child.nodeType ? child : document.createTextNode(String(child)));
  }
  return node;
}

export function escapeHtml(value) {
  if (value == null) return '';
  return String(value)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

const NUM = new Intl.NumberFormat('en-US');
export const fmtInt = (n) => (n == null || Number.isNaN(Number(n)) ? '—' : NUM.format(Math.round(Number(n))));
export function fmtNum(n, digits = 2) {
  if (n == null || n === '' || Number.isNaN(Number(n))) return '—';
  const x = Number(n);
  if (!Number.isFinite(x)) return '—';
  if (x !== 0 && (Math.abs(x) >= 1e6 || Math.abs(x) < 1e-4)) return x.toExponential(2);
  return x.toLocaleString('en-US', { maximumFractionDigits: digits });
}

export const fmtPct = (n, digits = 1) =>
  (n == null || Number.isNaN(Number(n)) ? '—' : `${Number(n).toFixed(digits)}%`);

export function fmtCompact(n) {
  if (n == null || Number.isNaN(Number(n))) return '—';
  return new Intl.NumberFormat('en-US', { notation: 'compact', maximumFractionDigits: 1 }).format(Number(n));
}

/** Render any cell value for a table (null → em dash, objects → JSON). */
export function fmtCell(v) {
  if (v == null) return '—';
  if (typeof v === 'number') return Number.isInteger(v) ? NUM.format(v) : fmtNum(v, 4);
  if (typeof v === 'boolean') return v ? 'true' : 'false';
  if (typeof v === 'object') { try { return JSON.stringify(v); } catch { return String(v); } }
  return String(v);
}

export function debounce(fn, ms = 250) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

// ---- Toast ----
let toastHost;
export function toast(message, kind = 'info', timeout = 4200) {
  if (!toastHost) {
    toastHost = el('div', { class: 'toast-host', id: 'toastHost' });
    document.body.appendChild(toastHost);
  }
  const item = el('div', { class: `toast toast-${kind}`, role: 'status' }, [
    el('span', { class: 'toast-msg', text: message }),
    el('button', { class: 'toast-x', 'aria-label': 'Dismiss', onclick: () => item.remove() }, ['×']),
  ]);
  toastHost.appendChild(item);
  if (timeout) setTimeout(() => { item.classList.add('leaving'); setTimeout(() => item.remove(), 200); }, timeout);
  return item;
}
// ---- Busy overlay (ref-counted, so overlapping calls don't flicker) ----
let busyEl;
let busyCount = 0;
export function setBusy(on, label = 'Working…') {
  if (!busyEl) {
    busyEl = el('div', { class: 'busy-overlay', id: 'busyOverlay' }, [
      el('div', { class: 'busy-card' }, [
        el('div', { class: 'spinner' }),
        el('div', { class: 'busy-label', id: 'busyLabel' }),
      ]),
    ]);
    document.body.appendChild(busyEl);
  }
  busyCount = Math.max(0, busyCount + (on ? 1 : -1));
  if (on) $('#busyLabel', busyEl).textContent = label;
  busyEl.classList.toggle('show', busyCount > 0);
}

/** A titled empty-state / hint block. */
export function emptyState(title, detail) {
  return el('div', { class: 'empty-state' }, [
    el('div', { class: 'empty-title', text: title }),
    detail ? el('p', { class: 'empty-detail', text: detail }) : null,
  ]);
}

/** Standard screen header: title, optional subtitle, optional right-side actions. */
export function screenHead(title, subtitle, actions) {
  return el('header', { class: 'screen-head' }, [
    el('div', { class: 'screen-head-text' }, [
      el('h1', { class: 'screen-title', text: title }),
      subtitle ? el('p', { class: 'screen-sub', text: subtitle }) : null,
    ]),
    actions ? el('div', { class: 'screen-actions' }, [].concat(actions)) : null,
  ]);
}

/** A titled card/panel wrapping arbitrary children. */
export function panel(title, children, opts = {}) {
  return el('section', { class: `panel${opts.class ? ' ' + opts.class : ''}` }, [
    title ? el('div', { class: 'panel-head' }, [
      el('h2', { class: 'panel-title', text: title }),
      opts.aside ? el('div', { class: 'panel-aside' }, [].concat(opts.aside)) : null,
    ]) : null,
    el('div', { class: 'panel-body' }, [].concat(children)),
  ]);
}
