// router.js — tiny hash router. Owns the screen registry (which also drives the
// nav tabs), guards data-requiring screens, and renders the active screen into
// <main id="view">. Screens export `async render(outlet)` and manage their own
// busy state; a throw is caught here and shown as a toast + inline error.

import { hasDataset } from './state.js';
import { toast, emptyState, clear } from './ui.js';

import * as importScreen from './screens/import.js';
import * as overview from './screens/overview.js';
import * as table from './screens/table.js';
import * as visualize from './screens/visualize.js';
import * as dashboard from './screens/dashboard.js';
import * as correlations from './screens/correlations.js';
import * as ml from './screens/ml.js';
import * as reports from './screens/reports.js';

// Order here is the order of the nav tabs.
export const ROUTES = [
  { path: '/import', label: 'Import', icon: '↑', mod: importScreen, needsData: false },
  { path: '/overview', label: 'Overview', icon: '▦', mod: overview, needsData: true },
  { path: '/table', label: 'Data Table', icon: '▤', mod: table, needsData: true },
  { path: '/charts', label: 'Charts', icon: '◔', mod: visualize, needsData: true },
  { path: '/dashboard', label: 'Dashboard', icon: '◈', mod: dashboard, needsData: true },
  { path: '/correlations', label: 'Correlations', icon: '▨', mod: correlations, needsData: true },
  { path: '/ml', label: 'Machine Learning', icon: '◉', mod: ml, needsData: true },
  { path: '/reports', label: 'Reports', icon: '❐', mod: reports, needsData: true },
];

const DEFAULT = '/import';
const routeFor = (path) => ROUTES.find((r) => r.path === path);
const currentPath = () => (location.hash || '#' + DEFAULT).replace(/^#/, '') || DEFAULT;

export function navigate(path) {
  const target = '#' + path;
  if (location.hash === target) renderCurrent();
  else location.hash = target;
}

let outlet;
let onChange = () => {};

function setActive(path) {
  document.querySelectorAll('[data-route]').forEach((a) => {
    a.classList.toggle('active', a.getAttribute('data-route') === path);
    if (a.getAttribute('data-route') === path) a.setAttribute('aria-current', 'page');
    else a.removeAttribute('aria-current');
  });
}

async function renderCurrent() {
  let path = currentPath();
  let route = routeFor(path);
  if (!route) { navigate(DEFAULT); return; }

  // Guard: screens that need a dataset bounce to Import until one is loaded.
  if (route.needsData && !hasDataset()) {
    toast('Load a dataset first.', 'info');
    navigate(DEFAULT);
    return;
  }

  setActive(path);
  onChange(route);
  document.title = `${route.label} · Data Analyzer`;
  clear(outlet);
  window.scrollTo(0, 0);
  try {
    await route.mod.render(outlet);
  } catch (err) {
    console.error(err);
    clear(outlet);
    outlet.appendChild(emptyState('Could not render this screen.', err && err.message ? err.message : String(err)));
    toast(err && err.message ? err.message : 'Something went wrong rendering this screen.', 'error');
  }
}

/** Start routing. `outletEl` is the <main>; `changeCb` fires per navigation
 *  (main.js uses it to sync any header state). */
export function startRouter(outletEl, changeCb) {
  outlet = outletEl;
  if (typeof changeCb === 'function') onChange = changeCb;
  window.addEventListener('hashchange', renderCurrent);
  if (!location.hash) location.replace('#' + DEFAULT);
  renderCurrent();
}

/** Re-render the active screen in place (used after the dataset changes). */
export function refresh() { renderCurrent(); }
