@echo off
cd /d "%~dp0"
REM Use "python -m pip" / "-m streamlit": the .exe launchers inside a moved venv
REM have the old absolute path baked in and fail after the folder is relocated.
if not exist backend\venv\Scripts\python.exe (
  python -m venv backend\venv
)
backend\venv\Scripts\python.exe -m pip install -q -r backend\requirements.txt
backend\venv\Scripts\python.exe -m streamlit run streamlit_app.py
pause
