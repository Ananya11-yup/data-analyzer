"""Data Analyzer - pure-Python web frontend (Streamlit).

Features beyond the basic screens:
  * Login (users from .streamlit/secrets.toml or APP_USERS env var), with
    brute-force lockout and expiring sessions.
  * Workspace persistence: dataset, charts, ML results and screen settings are
    saved server-side under a session token kept in the URL (?s=...), so a
    browser reload (or reopening the same URL) restores everything.
  * Large-data safety: row caps for charts / ML / pairplots, and cached
    heavy computations.

Run:  streamlit run streamlit_app.py
"""
import base64
import hashlib
import hmac
import json
import os
import pickle
import re
import shutil
import sys
import threading
import time
import uuid
from datetime import date
from pathlib import Path

import numpy as np
import pandas as pd
import streamlit as st

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT / "backend"))
sys.path.insert(0, str(ROOT))

from analysis import (  # noqa: E402
    ChartDataError, build_chart_data, build_summary, compute_correlation, query_rows,
)
from charts import (  # noqa: E402
    CHART_TYPES_IGNORING_Y, ChartError, VALID_CHART_TYPES, VALID_PALETTES, generate_chart,
)
from dashboard_pro import render_dashboard  # noqa: E402
from ml import MLError, cluster, detect_anomalies, train_model  # noqa: E402
from parsing import ParsingError, parse_pasted_text, parse_upload, scrape_url  # noqa: E402

st.set_page_config(page_title="Data Analyzer", page_icon="◆", layout="wide")

WORKDIR = Path(os.environ.get("WORKSPACE_DIR", ROOT / ".workspaces"))
SESSION_TTL = int(os.environ.get("SESSION_TTL_HOURS", "12")) * 3600
TOKEN_RE = re.compile(r"^[0-9a-f]{32}$")
MAX_FAILS, LOCK_SECONDS = 5, 300
PLACEHOLDER_PW = "change-me"


# ================================================================== auth
def load_users() -> dict:
    users = {}
    try:
        users.update({str(k): str(v) for k, v in dict(st.secrets.get("users", {})).items()})
    except Exception:
        pass
    for pair in filter(None, os.environ.get("APP_USERS", "").split(",")):
        if ":" in pair:
            u, p = pair.split(":", 1)
            users[u.strip()] = p.strip()
    return users


def verify_password(pw: str, stored: str) -> bool:
    if stored.startswith("pbkdf2$"):
        try:
            _, salt, digest = stored.split("$")
            calc = hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 200_000).hex()
            return hmac.compare_digest(calc, digest)
        except Exception:
            return False
    return hmac.compare_digest(pw.encode(), stored.encode())


@st.cache_resource
def _fail_log() -> dict:
    return {"lock": threading.Lock(), "fails": {}}


def locked_for(name: str) -> int:
    log = _fail_log()
    now = time.time()
    with log["lock"]:
        recent = [t for t in log["fails"].get(name, []) if now - t < LOCK_SECONDS]
        log["fails"][name] = recent
        return int(LOCK_SECONDS - (now - recent[0])) if len(recent) >= MAX_FAILS else 0


def record_fail(name: str):
    log = _fail_log()
    with log["lock"]:
        log["fails"].setdefault(name, []).append(time.time())


# ================================================================== workspace persistence
def ws_dir(token: str) -> Path:
    if not TOKEN_RE.match(token or ""):
        raise ValueError("bad token")
    return WORKDIR / token


def _atomic_write(path: Path, data: bytes):
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_bytes(data)
    os.replace(tmp, path)


def write_auth(token: str, user: str):
    d = ws_dir(token)
    d.mkdir(parents=True, exist_ok=True)
    _atomic_write(d / "auth.json", json.dumps({"user": user, "expires": time.time() + SESSION_TTL}).encode())


def read_auth(token: str):
    try:
        data = json.loads((ws_dir(token) / "auth.json").read_text())
        return data if data["expires"] > time.time() else None
    except Exception:
        return None


def sweep_expired():
    if not WORKDIR.exists():
        return
    for d in WORKDIR.iterdir():
        try:
            if TOKEN_RE.match(d.name) and read_auth(d.name) is None:
                shutil.rmtree(d, ignore_errors=True)
        except Exception:
            pass


STATE_KEYS = ("name", "summary", "ds_id", "loaded_at", "saved_charts", "last_chart", "ml")


def save_df(df: pd.DataFrame):
    _atomic_write(ws_dir(st.session_state.token) / "df.pkl", pickle.dumps(df, protocol=4))


def save_state():
    """Persist light state every run. Widget values are mirrored in `_cfg`
    because Streamlit drops a widget's value while its screen isn't shown."""
    ss = st.session_state
    cfg = dict(ss.get("_cfg", {}))
    cfg.update({k: v for k, v in ss.items() if (k.startswith("cfg_") or k == "page")
                and isinstance(v, (str, int, float, bool, type(None), list, tuple, date))})
    ss["_cfg"] = cfg
    payload = {k: ss[k] for k in STATE_KEYS if k in ss}
    payload["_cfg"] = cfg
    try:
        _atomic_write(ws_dir(ss.token) / "state.pkl", pickle.dumps(payload, protocol=4))
        write_auth(ss.token, ss.user)  # sliding expiry
    except Exception:
        pass


def restore_workspace(token: str):
    d = ws_dir(token)
    try:
        if (d / "df.pkl").exists():
            st.session_state.df = pickle.loads((d / "df.pkl").read_bytes())
        if (d / "state.pkl").exists():
            for k, v in pickle.loads((d / "state.pkl").read_bytes()).items():
                st.session_state[k] = v
    except Exception:
        st.session_state.pop("df", None)  # corrupt file: start clean rather than crash


def apply_cfg():
    for k, v in st.session_state.get("_cfg", {}).items():
        if k not in st.session_state:
            st.session_state[k] = v


def logout():
    tok = st.session_state.get("token")
    if tok and TOKEN_RE.match(tok):
        shutil.rmtree(WORKDIR / tok, ignore_errors=True)
    st.session_state.clear()
    st.query_params.clear()
    st.rerun()


def login_screen():
    users = load_users()
    _, mid, _ = st.columns([1, 1.2, 1])
    with mid:
        st.title("◆ Data Analyzer")
        st.caption("Please sign in to continue.")
        if not users:
            st.error("No users are configured. Add a `[users]` section to `.streamlit/secrets.toml` "
                     "(see `secrets.toml.example`) or set the `APP_USERS` environment variable.")
            st.stop()
        with st.form("login"):
            name = st.text_input("Username")
            pw = st.text_input("Password", type="password")
            go = st.form_submit_button("Sign in", type="primary")
        if go:
            wait = locked_for(name.lower())
            if wait:
                st.error(f"Too many failed attempts. Try again in {wait // 60 + 1} min.")
            else:
                stored = users.get(name)
                ok = verify_password(pw, stored if stored is not None else "pbkdf2$00$00")
                if stored is not None and ok:
                    sweep_expired()
                    tok = uuid.uuid4().hex
                    write_auth(tok, name)
                    st.session_state.update(user=name, token=tok)
                    st.query_params["s"] = tok
                    st.rerun()
                record_fail(name.lower())
                st.error("Incorrect username or password.")
        if any(v == PLACEHOLDER_PW for v in users.values()):
            st.warning("A user still has the placeholder password. Change it in `.streamlit/secrets.toml`.")
    st.stop()


# ---- gate: nothing below runs unless signed in
if "user" not in st.session_state:
    tok = st.query_params.get("s", "")
    info = read_auth(tok) if TOKEN_RE.match(tok or "") else None
    if info:
        st.session_state.update(user=info["user"], token=tok)
        restore_workspace(tok)
    else:
        login_screen()
apply_cfg()


# ================================================================== helpers
def sample_df() -> pd.DataFrame:
    rng = np.random.default_rng(42)
    n = 300
    units = rng.integers(1, 40, n)
    price = rng.normal(500, 150, n).round(2).clip(50)
    discount = rng.uniform(0, 0.3, n).round(3)
    return pd.DataFrame({
        "date": pd.date_range("2025-01-01", periods=n, freq="D").strftime("%Y-%m-%d"),
        "region": rng.choice(["North", "South", "East", "West"], n),
        "product": rng.choice(["Laptop", "Phone", "Tablet", "Watch"], n),
        "units": units, "price": price, "discount": discount,
        "revenue": (units * price * (1 - discount)).round(2),
        "rating": rng.integers(1, 6, n),
    })


def set_data(df: pd.DataFrame, name: str):
    ss = st.session_state
    ss.df, ss.name, ss.ds_id = df, name, uuid.uuid4().hex
    ss.loaded_at = time.strftime("%Y-%m-%d %H:%M")
    ss.summary = build_summary(df)
    ss.saved_charts, ss.ml = [], {}
    ss.pop("last_chart", None)
    ss["_cfg"] = {k: v for k, v in ss.get("_cfg", {}).items() if k in ("cfg_theme", "cfg_max_chart", "cfg_max_ml")}
    ss.pop("_pdf", None); ss.pop("_dash_anom", None)
    for k in [k for k in ss if k.startswith("cfg_") and k not in ("cfg_theme", "cfg_max_chart", "cfg_max_ml")]:
        del ss[k]
    ss["_goto"] = "Overview"
    save_df(df)


def safe_df(d: pd.DataFrame) -> pd.DataFrame:
    """Arrow (st.dataframe) rejects mixed-type object columns; stringify those."""
    d = d.copy()
    for c in d.columns:
        if d[c].dtype == object and d[c].dropna().map(type).nunique() > 1:
            d[c] = d[c].map(lambda v: None if pd.isna(v) else str(v))
    return d


def show_warnings(items):
    for w in items or []:
        st.warning(w)


def pick(label, options, key, container=st, **kw):
    """selectbox that survives restored/stale state."""
    options = list(options)
    if st.session_state.get(key) not in options:
        st.session_state.pop(key, None)
        if options:
            st.session_state[key] = options[0]
    return container.selectbox(label, options, key=key, **kw)


def val(key, default):
    st.session_state.setdefault(key, default)
    return key


def cap_rows(d: pd.DataFrame, limit: int):
    if len(d) > limit:
        return d.sample(limit, random_state=0), True
    return d, False


# cached heavy work (keyed by dataset id, not by hashing the whole frame)
@st.cache_data(show_spinner=False, max_entries=64, ttl=3600)
def cached_rows(ds_id, _df, search, sort_by, sort_dir, offset, limit):
    return query_rows(_df, search, sort_by, sort_dir, offset, limit)


@st.cache_data(show_spinner=False, max_entries=16, ttl=3600)
def cached_corr(ds_id, _df, method):
    return compute_correlation(_df, method)


def _sampled(d, max_rows, r):
    if len(d) > max_rows:
        r["warnings"] = [f"Large dataset: used a random sample of {max_rows:,} of {len(d):,} rows "
                         "(change this in the sidebar → Performance)."] + list(r.get("warnings", []))
    return r


@st.cache_data(show_spinner=False, max_entries=16, ttl=3600)
def run_train(ds_id, _df, target, max_rows):
    d, _ = cap_rows(_df, max_rows)
    return _sampled(_df, max_rows, train_model(d, target))


@st.cache_data(show_spinner=False, max_entries=16, ttl=3600)
def run_cluster(ds_id, _df, k, max_rows):
    d, _ = cap_rows(_df, max_rows)
    return _sampled(_df, max_rows, cluster(d, k))


@st.cache_data(show_spinner=False, max_entries=16, ttl=3600)
def run_anoms(ds_id, _df, contam, max_rows):
    d, _ = cap_rows(_df, max_rows)
    return _sampled(_df, max_rows, detect_anomalies(d, contam))


# ================================================================== sidebar
ss = st.session_state
ss.setdefault("saved_charts", [])
ss.setdefault("ml", {})
has_data = "df" in ss
pages = ["Import"] + (["Overview", "Data Table", "Charts", "Dashboard",
                       "Correlations", "Machine Learning", "Report"] if has_data else [])
if "_goto" in ss:
    ss["page"] = ss.pop("_goto")
if ss.get("page") not in pages:
    ss["page"] = pages[0]

st.sidebar.title("◆ Data Analyzer")
page = st.sidebar.radio("Screens", pages, key="page", label_visibility="collapsed")
chart_theme = pick("Chart theme", ["light", "dark"], "cfg_theme", st.sidebar)
with st.sidebar.expander("Performance"):
    max_chart = st.number_input("Max rows per chart", 1000, 2_000_000, step=10_000, key=val("cfg_max_chart", 100_000))
    max_ml = st.number_input("Max rows for ML", 1000, 1_000_000, step=10_000, key=val("cfg_max_ml", 20_000))
    st.caption("Bigger datasets are randomly sampled to the limits above.")
if has_data:
    d0 = ss.df
    st.sidebar.success(f"**{ss.name}**\n\n{len(d0):,} rows × {d0.shape[1]} cols")
    if st.sidebar.button("Clear dataset"):
        for k in ("df", "name", "summary", "ds_id", "last_chart"):
            ss.pop(k, None)
        ss.saved_charts, ss.ml, ss["_cfg"] = [], {}, {}
        try:
            (ws_dir(ss.token) / "df.pkl").unlink(missing_ok=True)
        except Exception:
            pass
        st.rerun()
st.sidebar.divider()
st.sidebar.caption(f"Signed in as **{ss.user}**")
if st.sidebar.button("Sign out"):
    logout()

df: pd.DataFrame = ss.get("df")
summary: dict = ss.get("summary", {})
ds_id = ss.get("ds_id", "")
num_cols = summary.get("numeric_columns", [])
all_cols = list(df.columns) if df is not None else []

# ================================================================== screens
if page == "Import":
    st.title("Import data")
    t1, t2, t3, t4 = st.tabs(["Upload file", "Scrape URL", "Paste text", "Sample"])
    with t1:
        f = st.file_uploader("CSV, TSV or Excel", type=["csv", "tsv", "xlsx", "xls"])
        if f and st.button("Load file", type="primary"):
            try:
                with st.spinner("Parsing…"):
                    set_data(parse_upload(f.name, f.getvalue()), f.name)
                st.rerun()
            except ParsingError as e:
                st.error(str(e))
    with t2:
        url = st.text_input("Page URL containing a table")
        if url and st.button("Scrape", type="primary"):
            with st.spinner("Fetching…"):
                try:
                    set_data(scrape_url(url), url)
                    st.rerun()
                except Exception as e:
                    st.error(str(e))
    with t3:
        txt = st.text_area("Paste CSV / TSV / JSON", height=200)
        if txt and st.button("Parse", type="primary"):
            try:
                set_data(parse_pasted_text(txt), "pasted data")
                st.rerun()
            except ParsingError as e:
                st.error(str(e))
    with t4:
        st.write("A 300-row synthetic sales dataset to try the app.")
        if st.button("Load sample dataset", type="primary"):
            set_data(sample_df(), "sample sales")
            st.rerun()
    if has_data:
        st.info("Dataset loaded — pick a screen from the sidebar.")

elif page == "Overview":
    st.title("Overview")
    s = summary
    total = s["shape"]["rows"] * s["shape"]["columns"]
    miss_pct = 100 * sum(s["missing_values"].values()) / total if total else 0
    c = st.columns(6)
    c[0].metric("Rows", f"{s['shape']['rows']:,}")
    c[1].metric("Columns", s["shape"]["columns"])
    c[2].metric("Numeric", len(s["numeric_columns"]))
    c[3].metric("Categorical", len(s["categorical_columns"]))
    c[4].metric("Duplicates", f"{s['duplicate_rows']:,}")
    c[5].metric("Missing", f"{miss_pct:.1f}%")
    if s.get("sampled"):
        st.warning(f"Statistics computed on a {s['sample_rows']:,}-row sample.")
    st.subheader("Columns")
    st.dataframe(pd.DataFrame({"dtype": s["dtypes"], "missing": s["missing_values"],
                               "missing %": s["missing_pct"]}), use_container_width=True)
    if s["describe"]:
        st.subheader("Numeric summary")
        st.dataframe(pd.DataFrame(s["describe"]), use_container_width=True)
    if s["value_counts"]:
        st.subheader("Top values")
        cols = st.columns(2)
        for i, (col, vc) in enumerate(s["value_counts"].items()):
            with cols[i % 2]:
                st.caption(col)
                st.bar_chart(pd.Series(vc))

elif page == "Data Table":
    st.title("Data table")
    c1, c2, c3, c4 = st.columns([3, 2, 1, 1])
    search = c1.text_input("Search", placeholder="Search all columns…", key=val("cfg_tbl_search", ""))
    sort_by = pick("Sort by", ["(none)"] + all_cols, "cfg_tbl_sort", c2)
    sort_dir = pick("Direction", ["asc", "desc"], "cfg_tbl_dir", c3)
    page_size = pick("Rows / page", [25, 50, 100, 250], "cfg_tbl_size", c4)
    sb = None if sort_by == "(none)" else sort_by
    total = cached_rows(ds_id, df, search, None, "asc", 0, 1)["total"]
    pages_n = max(1, -(-total // page_size))
    if ss.get("cfg_tbl_page", 1) > pages_n:
        ss["cfg_tbl_page"] = pages_n
    pg = st.number_input("Page", 1, pages_n, key=val("cfg_tbl_page", 1))
    res = cached_rows(ds_id, df, search, sb, sort_dir, (pg - 1) * page_size, page_size)
    st.caption(f"Showing {(pg - 1) * page_size + 1:,}–{min(pg * page_size, total):,} of {total:,} rows")
    st.dataframe(safe_df(pd.DataFrame(res["rows"])), use_container_width=True, hide_index=True)
    e1, e2, _ = st.columns([1, 1, 6])
    e1.download_button("Download CSV", df.to_csv(index=False).encode(), "data.csv", "text/csv")
    e2.download_button("Download JSON", df.to_json(orient="records").encode(), "data.json", "application/json")

elif page == "Charts":
    st.title("Charts")
    left, right = st.columns([1, 2])
    with left:
        types = sorted(VALID_CHART_TYPES)
        ss.setdefault("cfg_ctype", "bar")
        ctype = pick("Chart type", types, "cfg_ctype")
        needs_xy = ctype not in ("heatmap", "pairplot")
        x = pick("X", all_cols, "cfg_cx") if needs_xy else None
        y = None
        if needs_xy and ctype not in CHART_TYPES_IGNORING_Y:
            y = pick("Y", ["(none)"] + all_cols, "cfg_cy")
            y = None if y == "(none)" else y
        hue = pick("Colour by", ["(none)"] + all_cols, "cfg_chue")
        hue = None if hue == "(none)" else hue
        palette = pick("Palette", VALID_PALETTES, "cfg_cpal")
        title = st.text_input("Title", key=val("cfg_ctitle", ""))
        bins = st.slider("Bins", 5, 100, key=val("cfg_cbins", 30)) if ctype == "histogram" else None
        horiz = st.checkbox("Horizontal", key=val("cfg_chor", False)) if ctype == "bar" else False
        log = st.checkbox("Log scale", key=val("cfg_clog", False))
        donut = st.checkbox("Donut", key=val("cfg_cdonut", False)) if ctype == "pie" else False
        go = st.button("Generate", type="primary")
    with right:
        if go:
            try:
                work, sampled = cap_rows(df, int(max_chart))
                if ctype == "pairplot":
                    keep = list(dict.fromkeys(num_cols[:6] + ([hue] if hue else [])))
                    work, s2 = cap_rows(work[keep], 2000)
                    sampled = sampled or s2
                with st.spinner("Rendering…"):
                    res = generate_chart(
                        work, ctype, chart_theme, x=x, y=y, hue=hue, title=title or None,
                        palette=palette, bins=bins, orientation="horizontal" if horiz else "vertical",
                        log_scale=log, donut=donut)
                png = base64.b64decode(res["image"].split(",", 1)[1])
                warns = list(res["warnings"])
                if sampled:
                    warns.insert(0, f"Large dataset: chart drawn from a random sample of {len(work):,} rows"
                                    + (" and the first 6 numeric columns." if ctype == "pairplot" else "."))
                cap = f"{ctype}: {x or ''} {y or ''}".strip()
                ss.last_chart = (cap, png, warns)
                ss.saved_charts.append((cap, png))
                ss.saved_charts = ss.saved_charts[-20:]
            except (ChartError, ValueError) as e:
                ss.pop("last_chart", None)
                st.error(str(e))
        if "last_chart" in ss:
            cap, png, warns = ss.last_chart
            show_warnings(warns)
            st.image(png, caption=cap, use_container_width=True)
            st.download_button("Download PNG", png, "chart.png", "image/png")
        elif not go:
            st.info("Choose options and press Generate.")

elif page == "Dashboard":
    render_dashboard(df, summary, ds_id, ss.name, ss.get("loaded_at"), chart_theme,
                     lambda key, d, c: run_anoms(key, d, c, int(max_ml)), safe_df, ws_dir(ss.token))

elif page == "Correlations":
    st.title("Correlations")
    if len(num_cols) < 2:
        st.warning("Need at least two numeric columns.")
    else:
        method = st.radio("Method", ["pearson", "spearman", "kendall"], horizontal=True, key=val("cfg_cmethod", "pearson"))
        work, sampled = (df, False) if method == "pearson" else cap_rows(df, 100_000)
        if sampled:
            st.info("Large dataset: rank correlations use a 100,000-row sample.")
        r = cached_corr(ds_id + ("s" if sampled else ""), work, method)
        mat = pd.DataFrame(r["matrix"]).loc[r["columns"], r["columns"]].astype(float)
        import seaborn as sns
        from matplotlib.figure import Figure
        fig = Figure(figsize=(7, 5.5))
        ax = fig.subplots()
        sns.heatmap(mat, annot=len(mat) <= 12, fmt=".2f", cmap="coolwarm", vmin=-1, vmax=1, ax=ax)
        st.pyplot(fig)
        st.subheader("Strongest pairs")
        st.dataframe(pd.DataFrame(r["top_pairs"]), use_container_width=True, hide_index=True)
        if r["categorical_association"]:
            st.subheader("Categorical association (Cramér's V)")
            st.dataframe(pd.DataFrame(r["categorical_association"]), use_container_width=True, hide_index=True)

elif page == "Machine Learning":
    st.title("Machine learning")
    ml = ss.ml
    t1, t2, t3 = st.tabs(["Predict", "Cluster", "Anomalies"])
    mr = int(max_ml)
    with t1:
        target = pick("Target column", all_cols, "cfg_ml_target")
        if st.button("Train model", type="primary"):
            try:
                with st.spinner("Training RandomForest…"):
                    ml["train"] = (target, run_train(ds_id, df, target, mr))
            except MLError as e:
                ml.pop("train", None)
                st.error(str(e))
        if "train" in ml:
            tgt, r = ml["train"]
            st.success(f"{r['task'].title()} on '{tgt}' — {r['n_rows_used']:,} rows, {r['n_features']} features")
            show_warnings(r["warnings"])
            cols = st.columns(len(r["metrics"]))
            for c, (k, v) in zip(cols, r["metrics"].items()):
                c.metric(k.upper(), f"{v:.4f}")
            st.subheader("Feature importances")
            st.bar_chart(pd.DataFrame(r["feature_importances"]).set_index("feature")["importance"])
            if r["confusion_matrix"]:
                cm = r["confusion_matrix"]
                st.subheader("Confusion matrix")
                st.dataframe(pd.DataFrame(cm["matrix"], index=cm["labels"], columns=cm["labels"]))
            if r["actual_vs_predicted"]:
                st.subheader("Actual vs predicted")
                st.scatter_chart(pd.DataFrame(r["actual_vs_predicted"]), x="actual", y="predicted")
    with t2:
        auto = st.checkbox("Auto-pick k (silhouette)", key=val("cfg_ml_auto", True))
        k = None if auto else st.slider("Clusters (k)", 2, 8, key=val("cfg_ml_k", 3))
        if st.button("Run clustering", type="primary"):
            try:
                with st.spinner("Clustering…"):
                    ml["cluster"] = run_cluster(ds_id, df, k, mr)
            except MLError as e:
                ml.pop("cluster", None)
                st.error(str(e))
        if "cluster" in ml:
            r = ml["cluster"]
            show_warnings(r["warnings"])
            m = st.columns(3)
            m[0].metric("Clusters", r["k"])
            m[1].metric("Silhouette", r["silhouette"] if r["silhouette"] is not None else "n/a")
            m[2].metric("Rows used", f"{r['n_rows_used']:,}")
            if r["projection"]:
                p = pd.DataFrame(r["projection"])
                p["cluster"] = p["cluster"].astype(str)
                st.scatter_chart(p, x="x", y="y", color="cluster")
            st.subheader("Cluster profile (feature means)")
            st.dataframe(pd.DataFrame(r["profile"]).set_index("cluster"), use_container_width=True)
            st.subheader("Sizes")
            st.bar_chart(pd.DataFrame(r["cluster_sizes"]).set_index("cluster")["size"])
    with t3:
        contam = st.slider("Expected outlier share", 0.01, 0.30, step=0.01, key=val("cfg_ml_contam", 0.05))
        if st.button("Detect anomalies", type="primary"):
            try:
                with st.spinner("Scanning…"):
                    ml["anom"] = run_anoms(ds_id, df, contam, mr)
            except MLError as e:
                ml.pop("anom", None)
                st.error(str(e))
        if "anom" in ml:
            r = ml["anom"]
            show_warnings(r["warnings"])
            m = st.columns(3)
            m[0].metric("Flagged", f"{r['n_flagged']:,}")
            m[1].metric("% flagged", f"{r['pct_flagged']:.2f}%")
            m[2].metric("Rows used", f"{r['n_rows_used']:,}")
            rows = [{"row": a["index"], "score": a["score"], **a["values"]} for a in r["top_anomalies"]]
            st.dataframe(safe_df(pd.DataFrame(rows)), use_container_width=True, hide_index=True)

elif page == "Report":
    st.title(f"Report — {ss.name}")
    s = summary
    st.write(f"**{s['shape']['rows']:,} rows × {s['shape']['columns']} columns**, "
             f"{len(s['numeric_columns'])} numeric, {len(s['categorical_columns'])} categorical, "
             f"{s['duplicate_rows']:,} duplicate rows.")
    if s["describe"]:
        st.subheader("Numeric summary")
        st.dataframe(pd.DataFrame(s["describe"]), use_container_width=True)
    if len(num_cols) >= 2:
        st.subheader("Top correlations")
        st.dataframe(pd.DataFrame(cached_corr(ds_id, df, "pearson")["top_pairs"]),
                     use_container_width=True, hide_index=True)
    if ss.saved_charts:
        st.subheader("Charts generated this session")
        cols = st.columns(2)
        for i, (cap, png) in enumerate(ss.saved_charts):
            cols[i % 2].image(png, caption=cap, use_container_width=True)
    st.caption("Tip: use your browser's Print → Save as PDF to export this page.")

save_state()
