"""Business dashboard for the Streamlit app: global filters, KPI cards with
period comparison + targets, multi-panel grid (aggregation, moving average,
growth, forecast, drill-down), plain-English insights, data-quality panel,
anomaly highlights, saved dashboards and PDF export.

Aggregations always run on the FULL filtered data (never a sample), so totals
are exact. Only the anomaly scan is capped (it is ML)."""
import hashlib
import io
import json
import time
from datetime import date, timedelta

import numpy as np
import pandas as pd
import streamlit as st
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.figure import Figure

from analysis import coerce_numeric_like

AGGS = ["sum", "mean", "median", "max", "min", "count"]
PERIODS = {"Day": "D", "Week": "W", "Month": "ME", "Quarter": "QE"}
PANEL_TYPES = ["bar", "line", "area", "pie", "histogram"]
PAL = ["#4f46e5", "#0ea5e9", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#ec4899", "#14b8a6"]
THEMES = {
    "light": dict(bg="#ffffff", ink="#0f172a", muted="#64748b", grid="#e2e8f0"),
    "dark": dict(bg="#1e293b", ink="#f1f5f9", muted="#94a3b8", grid="#334155"),
}


# ---------------------------------------------------------------- pure helpers
def fmt(v) -> str:
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return "–"
    a = abs(v)
    if a >= 1e9: return f"{v/1e9:.2f}B"
    if a >= 1e6: return f"{v/1e6:.2f}M"
    if a >= 1e4: return f"{v/1e3:.1f}k"
    return f"{v:,.0f}" if float(v).is_integer() else f"{v:,.2f}"


def _resample(s: pd.Series, period: str, agg: str) -> pd.Series:
    rule = PERIODS[period]
    try:
        r = s.resample(rule)
    except ValueError:  # pandas < 2.2 spells these "M"/"Q"
        r = s.resample(rule.rstrip("E"))
    return getattr(r, agg)()


def kpi_value(d: pd.DataFrame, col: str, agg: str):
    if col == "(rows)":
        return float(len(d))
    s = pd.to_numeric(d[col], errors="coerce")
    return float(getattr(s, agg)()) if s.notna().any() else None


def make_panel_fig(cdf, dt, cfg, theme):
    """cfg: type,x,y,agg,top,bins,period,ma,fc. Returns (fig, summary_line, drill_values)."""
    t = THEMES[theme]
    fig = Figure(figsize=(6.2, 3.7), facecolor=t["bg"])
    ax = fig.subplots()
    ax.set_facecolor(t["bg"])
    for sp in ("top", "right"): ax.spines[sp].set_visible(False)
    for sp in ("left", "bottom"): ax.spines[sp].set_color(t["grid"])
    ax.tick_params(colors=t["muted"], labelsize=8)
    ax.grid(axis="y", color=t["grid"], lw=.7); ax.set_axisbelow(True)
    typ, x, y, agg = cfg["type"], cfg["x"], cfg.get("y"), cfg.get("agg", "sum")
    y = None if y in (None, "(count)") else y
    note, drill = "", []
    title = f"{typ.title()}: {y + ' by ' if y else 'count by '}{x}" if typ != "histogram" else f"Distribution of {x}"
    if typ in ("bar", "pie"):
        g = (cdf.groupby(x, dropna=False)[y].agg(agg) if y else cdf.groupby(x, dropna=False).size()).dropna()
        g = g.sort_values(ascending=False)
        drill = [str(i) for i in g.head(cfg["top"]).index]
        if typ == "bar":
            g = g.head(cfg["top"])
            ax.bar([str(i) for i in g.index], g.values, color=PAL[0], width=.65)
            ax.tick_params(axis="x", rotation=30 if len(g) > 5 else 0)
            fig.axes[0].yaxis.set_major_formatter(lambda v, _: fmt(v))
            if len(g): note = f"Top: {g.index[0]} ({fmt(g.iloc[0])})"
        else:
            g = g[g > 0]
            if len(g) > 7: g = pd.concat([g.head(7), pd.Series({"Other": g.iloc[7:].sum()})])
            ax.grid(False)
            _, _, txt = ax.pie(g.values, labels=[str(i) for i in g.index], colors=PAL, autopct="%1.0f%%",
                               startangle=90, wedgeprops=dict(width=.45, edgecolor=t["bg"]),
                               textprops=dict(color=t["ink"], fontsize=8), pctdistance=.78)
            for tx in txt: tx.set_color("white")
    elif typ in ("line", "area"):
        if cfg["x_is_date"] and dt is not None:
            vals = pd.to_numeric(cdf[y], errors="coerce") if y else pd.Series(1.0, index=cdf.index)
            base = pd.Series(vals.values, index=dt.loc[cdf.index].values)
            base = base[base.index.notna()].sort_index()
            s = _resample(base, cfg["period"], agg if y else "sum") if len(base) else base
        else:
            s = (cdf.groupby(x)[y].agg(agg) if y else cdf.groupby(x).size()).sort_index()
        if len(s):
            xv = s.index
            (ax.fill_between if typ == "area" else ax.plot)(xv, s.values, **({"color": PAL[1], "alpha": .25} if typ == "area" else {"color": PAL[1], "lw": 1.6}))
            if typ == "area": ax.plot(xv, s.values, color=PAL[1], lw=1.2)
            if cfg["ma"] > 1 and len(s) >= cfg["ma"]:
                ax.plot(xv, s.rolling(cfg["ma"]).mean().values, color=PAL[3], lw=1.8, label=f"{cfg['ma']}-pt moving avg")
            if cfg["fc"] > 0 and len(s) >= 4 and cfg["x_is_date"]:
                k = min(len(s), 24); yy = s.values[-k:].astype(float)
                m, b = np.polyfit(np.arange(k), yy, 1)
                step = (s.index[-1] - s.index[-2]) if len(s) > 1 else timedelta(days=1)
                fx = [s.index[-1] + step * (i + 1) for i in range(cfg["fc"])]
                fy = [m * (k + i) + b for i in range(cfg["fc"])]
                ax.plot([s.index[-1]] + fx, [s.values[-1]] + fy, color=PAL[4], lw=1.6, ls="--", label=f"forecast ({cfg['fc']})")
            if len(s) >= 2 and pd.notna(s.iloc[-2]) and s.iloc[-2] != 0:
                note = f"Latest vs previous: {(s.iloc[-1] / s.iloc[-2] - 1) * 100:+.1f}%"
            ax.yaxis.set_major_formatter(lambda v, _: fmt(v))
            fig.autofmt_xdate(rotation=0, ha="center") if cfg["x_is_date"] else None
            if ax.get_legend_handles_labels()[0]:
                ax.legend(fontsize=7.5, frameon=False, labelcolor=t["ink"])
    else:  # histogram
        v = pd.to_numeric(cdf[x], errors="coerce").dropna()
        if len(v):
            ax.hist(v, bins=cfg["bins"], color=PAL[3], edgecolor=t["bg"])
            note = f"Median {fmt(v.median())}, mean {fmt(v.mean())}"
    ax.set_title(title, loc="left", fontsize=10.5, fontweight="600", color=t["ink"], pad=8)
    return fig, note, drill


def make_panel_plotly(cdf, dt, cfg, theme):
    """Interactive twin of make_panel_fig: hover tooltips, zoom/pan, date range
    buttons + slider, legend toggles. Returns (fig, summary_line)."""
    import plotly.graph_objects as go
    t = THEMES[theme]
    typ, x, y, agg = cfg["type"], cfg["x"], cfg.get("y"), cfg.get("agg", "sum")
    y = None if y in (None, "(count)") else y
    title = f"{typ.title()}: {y + ' by ' if y else 'count by '}{x}" if typ != "histogram" else f"Distribution of {x}"
    fig, note, hover, legend = go.Figure(), "", "closest", False
    if typ in ("bar", "pie"):
        g = (cdf.groupby(x, dropna=False)[y].agg(agg) if y else cdf.groupby(x, dropna=False).size()).dropna().sort_values(ascending=False)
        if typ == "bar":
            g = g.head(cfg["top"])
            fig.add_bar(x=[str(i) for i in g.index], y=g.values, marker_color=PAL[0],
                        hovertemplate="<b>%{x}</b><br>%{y:,.2f}<extra></extra>")
            fig.update_xaxes(type="category")
            if len(g): note = f"Top: {g.index[0]} ({fmt(g.iloc[0])})"
        else:
            g = g[g > 0]
            if len(g) > 7: g = pd.concat([g.head(7), pd.Series({"Other": g.iloc[7:].sum()})])
            fig.add_pie(labels=[str(i) for i in g.index], values=g.values, hole=.55, marker=dict(colors=PAL, line=dict(color=t["bg"], width=2)),
                        hovertemplate="<b>%{label}</b><br>%{value:,.2f} (%{percent})<extra></extra>", textinfo="percent")
            legend = True
    elif typ in ("line", "area"):
        if cfg["x_is_date"] and dt is not None:
            vals = pd.to_numeric(cdf[y], errors="coerce") if y else pd.Series(1.0, index=cdf.index)
            base = pd.Series(vals.values, index=dt.loc[cdf.index].values)
            base = base[base.index.notna()].sort_index()
            s = _resample(base, cfg["period"], agg if y else "sum") if len(base) else base
        else:
            s = (cdf.groupby(x)[y].agg(agg) if y else cdf.groupby(x).size()).sort_index()
        if len(s):
            fig.add_scatter(x=s.index, y=s.values, mode="lines", name=y or "count", line=dict(color=PAL[1], width=2),
                            fill="tozeroy" if typ == "area" else None, hovertemplate="%{y:,.2f}<extra>%{fullData.name}</extra>")
            if cfg["ma"] > 1 and len(s) >= cfg["ma"]:
                fig.add_scatter(x=s.index, y=s.rolling(cfg["ma"]).mean().values, mode="lines", name=f"{cfg['ma']}-pt moving avg", line=dict(color=PAL[3], width=2))
            if cfg["fc"] > 0 and len(s) >= 4 and cfg["x_is_date"]:
                k = min(len(s), 24); m, b = np.polyfit(np.arange(k), s.values[-k:].astype(float), 1)
                step = (s.index[-1] - s.index[-2]) if len(s) > 1 else timedelta(days=1)
                fx = [s.index[-1] + step * (i + 1) for i in range(cfg["fc"])]
                fig.add_scatter(x=[s.index[-1]] + fx, y=[s.values[-1]] + [m * (k + i) + b for i in range(cfg["fc"])], mode="lines",
                                name=f"forecast ({cfg['fc']})", line=dict(color=PAL[4], width=2, dash="dash"))
            if len(s) >= 2 and pd.notna(s.iloc[-2]) and s.iloc[-2] != 0:
                note = f"Latest vs previous: {(s.iloc[-1] / s.iloc[-2] - 1) * 100:+.1f}%"
            hover, legend = "x unified", len(fig.data) > 1
            if cfg["x_is_date"]:
                fig.update_xaxes(rangeslider=dict(visible=True, thickness=.07), rangeselector=dict(
                    bgcolor=t["bg"], buttons=[dict(count=1, label="1m", step="month", stepmode="backward"),
                                              dict(count=6, label="6m", step="month", stepmode="backward"),
                                              dict(count=1, label="1y", step="year", stepmode="backward"), dict(step="all", label="All")]))
    else:  # histogram
        v = pd.to_numeric(cdf[x], errors="coerce").dropna()
        if len(v):
            fig.add_histogram(x=v, nbinsx=cfg["bins"], marker=dict(color=PAL[3], line=dict(color=t["bg"], width=1)),
                              hovertemplate="%{x}<br>%{y:,} rows<extra></extra>")
            note = f"Median {fmt(v.median())}, mean {fmt(v.mean())}"
    fig.update_layout(template="plotly_dark" if theme == "dark" else "plotly_white", paper_bgcolor=t["bg"], plot_bgcolor=t["bg"],
                      font=dict(color=t["ink"], size=12), margin=dict(l=8, r=8, t=44, b=8), height=380 if typ in ("line", "area") else 340,
                      title=dict(text=title, x=0, font=dict(size=14)), hovermode=hover, clickmode="event+select",
                      showlegend=legend, legend=dict(orientation="h", y=-.15), bargap=.25)
    fig.update_xaxes(gridcolor=t["grid"]); fig.update_yaxes(gridcolor=t["grid"], tickformat="~s")
    return fig, note


def _click_filters(ss, df, n_pan):
    """Bars clicked on a bar panel last run -> {panel_index: (column, {values})}."""
    out = {}
    for i in range(n_pan):
        x = ss.get(f"cfg_dash_p{i}x")
        if ss.get(f"cfg_dash_p{i}t") != "bar" or x not in df.columns: continue
        try: pts = ss[f"dash_chart{i}_{ss.get('_xfv', 0)}"]["selection"]["points"]
        except Exception: continue
        vals = {str(p["x"]) for p in pts if p.get("x") is not None}
        if vals: out[i] = (x, vals)
    return out


def quality_table(df: pd.DataFrame, cdf: pd.DataFrame, skip_id=()) -> pd.DataFrame:
    rows, n = [], len(df)
    for c in df.columns:
        s, miss, uniq = df[c], df[c].isna().mean() * 100, df[c].nunique(dropna=True)
        out, issues = 0, []
        if pd.api.types.is_numeric_dtype(cdf[c]):
            v = cdf[c].dropna()
            if len(v) > 8:
                q1, q3 = v.quantile([.25, .75]); iqr = q3 - q1
                out = int(((v < q1 - 1.5 * iqr) | (v > q3 + 1.5 * iqr)).sum()) if iqr > 0 else 0
            if s.dtype == object or pd.api.types.is_string_dtype(s): issues.append("numbers stored as text")
        if miss > 20: issues.append("many missing values")
        if uniq <= 1 and n > 1: issues.append("constant column")
        if c not in skip_id and n > 20 and uniq == n and (s.dtype == object or pd.api.types.is_string_dtype(s)): issues.append("looks like an ID")
        if n and out / n > .05: issues.append("many outliers")
        rows.append({"column": c, "dtype": str(s.dtype), "missing %": round(miss, 1), "unique": int(uniq),
                     "outliers": out, "issues": ", ".join(issues) or "ok"})
    return pd.DataFrame(rows)


def build_pdf(title, lines, figs) -> bytes:
    buf = io.BytesIO()
    with PdfPages(buf) as pdf:
        f = Figure(figsize=(8.27, 11.69))
        f.text(.08, .95, title, fontsize=20, fontweight="bold", va="top")
        f.text(.08, .915, time.strftime("Generated %Y-%m-%d %H:%M"), fontsize=9, color="#64748b", va="top")
        y = .87
        for ln in lines[:40]:
            f.text(.08, y, ln[:105], fontsize=9.5, va="top"); y -= .024
        pdf.savefig(f)
        for fg in figs:
            pdf.savefig(fg, bbox_inches="tight")
    return buf.getvalue()


# ---------------------------------------------------------------- streamlit bits
@st.cache_data(show_spinner=False, max_entries=16, ttl=3600)
def date_columns(ds_id, _df):
    out = []
    for c in _df.columns:
        s = _df[c]
        if pd.api.types.is_datetime64_any_dtype(s):
            out.append(c)
        elif s.dtype == object or pd.api.types.is_string_dtype(s):
            smp = s.dropna().astype(str).head(200)
            if len(smp) and smp.str.contains(r"\d{4}[-/]\d{1,2}|\d{1,2}[-/]\d{1,2}[-/]\d{2,4}").mean() > .9 \
                    and pd.to_datetime(smp, errors="coerce").notna().mean() > .9:
                out.append(c)
    return out


@st.cache_data(show_spinner=False, max_entries=16, ttl=3600)
def parsed_dates(ds_id, _df, col):
    return pd.to_datetime(_df[col], errors="coerce")


@st.cache_data(show_spinner=False, max_entries=16, ttl=3600)
def coerced(ds_id, _df):
    return coerce_numeric_like(_df)


def _dpick(label, options, key, default=None, container=st):
    options = list(options)
    if st.session_state.get(key) not in options:
        st.session_state[key] = default if default in options else (options[0] if options else None)
    return container.selectbox(label, options, key=key)


def _val(key, default):
    st.session_state.setdefault(key, default)
    return key


def _ser(v):
    if isinstance(v, date): return {"__d": v.isoformat()}
    if isinstance(v, (list, tuple)): return [_ser(i) for i in v]
    return v


def _de(v):
    if isinstance(v, dict) and "__d" in v: return date.fromisoformat(v["__d"])
    if isinstance(v, list): return tuple(_de(i) for i in v) if v and isinstance(v[0], dict) else [_de(i) for i in v]
    return v


def render_dashboard(df, summary, ds_id, name, loaded_at, theme, run_anoms, safe_df, store_dir):
    ss = st.session_state
    dash_file = store_dir / "dashboards.json"

    # saved-dashboard load must happen before any widget is created
    if "_dash_load" in ss:
        saved = json.loads(dash_file.read_text()).get(ss.pop("_dash_load"), {})
        for k in [k for k in ss if k.startswith("cfg_dash_")]: del ss[k]
        ss["_cfg"] = {k: v for k, v in ss.get("_cfg", {}).items() if not k.startswith("cfg_dash_")}
        for k, v in saved.items():
            v = _de(v)
            ss[k] = tuple(v) if k == "cfg_dash_nrng" and isinstance(v, list) else v

    cdf_all = coerced(ds_id, df)
    num_cols = [c for c in cdf_all.columns if pd.api.types.is_numeric_dtype(cdf_all[c])]
    dcols = [c for c in date_columns(ds_id, df) if parsed_dates(ds_id, df, c).notna().any()]
    cat_cols = [c for c in df.columns if c not in num_cols and c not in dcols and df[c].nunique() <= 50]

    st.title("Dashboard")
    st.caption(f"Source: **{name}**  ·  loaded {loaded_at or 'n/a'}  ·  {len(df):,} rows")

    # ---------------- filters
    with st.expander("🔎 Filters (apply to everything below)", expanded=True):
        fc = st.columns(3)
        dcol = None; rng = None
        if dcols:
            dcol = _dpick("Date column", dcols, "cfg_dash_dcol", container=fc[0])
            dts = parsed_dates(ds_id, df, dcol)
            mn, mx = dts.min().date(), dts.max().date()
            cur = ss.get("cfg_dash_range")
            if not (isinstance(cur, tuple) and len(cur) == 2 and mn <= cur[0] <= cur[1] <= mx):
                ss["cfg_dash_range"] = (mn, mx)
            r = fc[1].date_input("Date range", min_value=mn, max_value=mx, key="cfg_dash_range")
            rng = r if isinstance(r, tuple) and len(r) == 2 else (mn, mx)
        base = pd.Series(True, index=df.index)
        for i, col in enumerate(cat_cols[:3]):
            opts = sorted(df[col].dropna().astype(str).unique())
            key = f"cfg_dash_cat{i}"
            ss[key] = [v for v in ss.get(key, []) if v in opts]
            sel = fc[i % 3].multiselect(col, opts, key=key)
            if sel: base &= df[col].astype(str).isin(sel)
        if num_cols:
            nc = _dpick("Numeric filter column", ["(none)"] + num_cols, "cfg_dash_ncol", "(none)", fc[2])
            if nc != "(none)":
                v = cdf_all[nc]; lo, hi = float(v.min()), float(v.max())
                if lo < hi:
                    cur = ss.get("cfg_dash_nrng")
                    if not (isinstance(cur, tuple) and lo <= cur[0] <= cur[1] <= hi):
                        ss["cfg_dash_nrng"] = (lo, hi)
                    a, b = st.slider(f"{nc} range", lo, hi, key="cfg_dash_nrng")
                    base &= v.between(a, b)
    cur0 = base.copy()
    if dcol:
        cur0 &= (dts >= pd.Timestamp(rng[0])) & (dts < pd.Timestamp(rng[1]) + pd.Timedelta(days=1))
    # click filters: bars selected on bar panels narrow everything except their own panel
    xf = _click_filters(ss, df, ss.get("cfg_dash_np", 4))

    def xmask(skip=None):
        m = pd.Series(True, index=df.index)
        for i, (c, v) in xf.items():
            if i != skip: m &= df[c].astype(str).isin(v)
        return m
    cur_mask = cur0 & xmask()
    fdf, fcdf = df[cur_mask], cdf_all[cur_mask]
    if xf:
        cc = st.columns([6, 1])
        cc[0].info("Click filters: " + "  ·  ".join(f"**{c}** = {', '.join(sorted(v))}" for c, v in xf.values()))
        if cc[1].button("Clear", key="_xf_clear"):
            ss["_xfv"] = ss.get("_xfv", 0) + 1; st.rerun()
    else:
        st.caption("Tip: click a bar to filter the whole dashboard (shift-click to pick several). Drag to zoom, double-click to reset.")
    st.caption(f"Showing **{len(fdf):,}** of {len(df):,} rows")
    if fdf.empty:
        st.warning("No rows match the filters."); return
    prev = None
    if dcol:
        span = (rng[1] - rng[0]).days + 1
        ps, pe = pd.Timestamp(rng[0]) - pd.Timedelta(days=span), pd.Timestamp(rng[0])
        pm = base & xmask() & (dts >= ps) & (dts < pe)
        prev = cdf_all[pm] if pm.any() else None

    # ---------------- KPI cards
    kdefs = [("(rows)", "sum")] + [(c, "sum") for c in num_cols[:3]]
    with st.expander("⚙ KPI settings (columns, aggregation, targets)"):
        kc = st.columns(4)
        for i in range(4):
            d = kdefs[i] if i < len(kdefs) else ("(rows)", "sum")
            _dpick(f"KPI {i+1} column", ["(rows)"] + num_cols, f"cfg_dash_k{i}c", d[0], kc[i])
            _dpick("Aggregation", AGGS[:5], f"cfg_dash_k{i}a", d[1], kc[i])
            kc[i].number_input("Target (0 = none)", key=_val(f"cfg_dash_k{i}t", 0.0))
    kpi_lines, kcols = [], st.columns(4)
    kpis = []
    for i in range(4):
        col, agg, tgt = ss[f"cfg_dash_k{i}c"], ss[f"cfg_dash_k{i}a"], ss.get(f"cfg_dash_k{i}t", 0.0)
        v = kpi_value(fcdf, col, agg); pv = kpi_value(prev, col, agg) if prev is not None else None
        delta = f"{(v - pv) / abs(pv) * 100:+.1f}% vs prev period" if v is not None and pv not in (None, 0) else None
        label = "Rows" if col == "(rows)" else f"{agg.title()} of {col}"
        kpis.append((label, v, pv))
        with kcols[i]:
            st.metric(label, fmt(v), delta)
            if tgt:
                ok = v is not None and v >= tgt
                st.caption(f":{'green' if ok else 'red'}[{'On target' if ok else 'Below target'} ({fmt(tgt)}) — {fmt(v)}]")
        kpi_lines.append(f"{label}: {fmt(v)}" + (f"  ({delta})" if delta else ""))

    # ---------------- plain-English insights
    ins = [f"The current view covers {len(fdf):,} of {len(df):,} rows ({len(fdf)/len(df):.0%})."]
    for label, v, pv in kpis:
        if v is not None and pv not in (None, 0):
            ch = (v - pv) / abs(pv) * 100
            ins.append(f"{label} is {'up' if ch >= 0 else 'down'} {abs(ch):.1f}% versus the previous period ({fmt(pv)} → {fmt(v)}).")
    if cat_cols and num_cols:
        c0, n0 = cat_cols[0], next((n for n in num_cols if n != ss["cfg_dash_k0c"]), num_cols[0])
        g = fcdf.groupby(fdf[c0].astype(str))[n0].sum().sort_values(ascending=False)
        if len(g) > 1 and g.sum() > 0:
            ins.append(f"{g.index[0]} leads on {n0} by {c0} with {g.iloc[0] / g.sum():.0%} of the total; {g.index[-1]} is lowest at {g.iloc[-1] / g.sum():.0%}.")
    miss = fdf.isna().mean().sort_values(ascending=False)
    if miss.iloc[0] > .05:
        ins.append(f"Data note: '{miss.index[0]}' is {miss.iloc[0]:.0%} empty in this view.")
    with st.container(border=True):
        st.markdown("**Summary**")
        for t_ in ins: st.markdown(f"- {t_}")

    # ---------------- panel grid
    st.subheader("Panels")
    n_pan = st.slider("Number of panels", 1, 6, key=_val("cfg_dash_np", 4))
    dd = {0: ("bar", 0), 1: ("line", 0), 2: ("pie", 1), 3: ("histogram", 0), 4: ("bar", 1), 5: ("area", 0)}
    figs, cols2 = [], st.columns(2)
    for i in range(n_pan):
        with cols2[i % 2], st.container(border=True):
            dtype_, ci = dd[i]
            with st.expander(f"⚙ Panel {i+1} settings"):
                typ = _dpick("Type", PANEL_TYPES, f"cfg_dash_p{i}t", dtype_)
                c1, c2 = st.columns(2)
                if typ in ("line", "area"):
                    xopts = dcols + [c for c in df.columns if c not in dcols]
                    xdef = dcols[0] if dcols else xopts[0]
                elif typ == "histogram":
                    xopts, xdef = num_cols, (num_cols[0] if num_cols else None)
                else:
                    xopts = cat_cols or list(df.columns); xdef = xopts[min(ci, len(xopts) - 1)]
                if not xopts:
                    st.warning("No suitable columns."); continue
                x = _dpick("X / column", xopts, f"cfg_dash_p{i}x", xdef, c1)
                y = None
                if typ != "histogram":
                    y = _dpick("Value", ["(count)"] + num_cols, f"cfg_dash_p{i}y", num_cols[0] if num_cols else "(count)", c2)
                    agg = _dpick("Aggregation", AGGS, f"cfg_dash_p{i}a", "sum", c1)
                else:
                    agg = "sum"
                period = _dpick("Period", list(PERIODS), f"cfg_dash_p{i}p", "Month", c2) if typ in ("line", "area") and x in dcols else "Month"
                top = st.slider("Top N", 3, 30, key=_val(f"cfg_dash_p{i}n", 10)) if typ in ("bar", "pie") else 10
                bins = st.slider("Bins", 5, 80, key=_val(f"cfg_dash_p{i}b", 25)) if typ == "histogram" else 25
                ma = st.slider("Moving average (points)", 0, 12, key=_val(f"cfg_dash_p{i}m", 0)) if typ in ("line", "area") else 0
                fc_ = st.slider("Forecast periods", 0, 12, key=_val(f"cfg_dash_p{i}f", 0)) if typ in ("line", "area") and x in dcols else 0
            cfg = dict(type=typ, x=x, y=y, agg=agg, top=top, bins=bins, period=period, ma=ma, fc=fc_, x_is_date=x in dcols)
            try:
                pmask = cur0 & xmask(skip=i)  # a panel ignores its own click selection so it keeps its context
                dtx = parsed_dates(ds_id, df, x) if x in dcols else None
                fig, _, drill = make_panel_fig(cdf_all[pmask], dtx, cfg, theme)  # static copy for the PDF
                figs.append(fig)
                pfig, note = make_panel_plotly(cdf_all[pmask], dtx, cfg, theme)
                ckey = f"dash_chart{i}_{ss.get('_xfv', 0)}"
                pcfg = {"displaylogo": False, "modeBarButtonsToRemove": ["lasso2d"]}
                if typ == "bar":
                    st.plotly_chart(pfig, use_container_width=True, theme=None, key=ckey, on_select="rerun", selection_mode="points", config=pcfg)
                else:
                    st.plotly_chart(pfig, use_container_width=True, theme=None, key=ckey, config=pcfg)
                if note: st.caption(note)
                if drill:
                    pick = st.selectbox("Drill into", ["(none)"] + drill, key=f"cfg_dash_p{i}d")
                    if pick != "(none)":
                        sub = fdf[fdf[x].astype(str) == pick]
                        with st.expander(f"{len(sub):,} rows where {x} = {pick}", expanded=True):
                            st.dataframe(safe_df(sub.head(200)), use_container_width=True, hide_index=True)
            except Exception as e:
                st.error(f"Could not draw this panel: {e}")

    # ---------------- data quality + anomalies
    with st.expander("🩺 Data quality"):
        q = quality_table(fdf, fcdf, dcols)
        st.dataframe(q, use_container_width=True, hide_index=True)
        dups = int(fdf.duplicated().sum())
        st.caption(f"{dups:,} duplicate rows in this view." + (" Consider removing them." if dups else ""))
    with st.expander("🚨 Anomaly highlights"):
        contam = st.slider("Expected outlier share", 0.01, 0.20, key=_val("cfg_dash_contam", 0.03), step=0.01)
        if st.button("Scan this view for anomalies"):
            fkey = ds_id + hashlib.md5(pd.util.hash_pandas_object(fdf.index).values.tobytes()).hexdigest()
            try:
                with st.spinner("Scanning…"):
                    ss["_dash_anom"] = run_anoms(fkey, fdf, contam)
            except Exception as e:
                ss.pop("_dash_anom", None); st.error(str(e))
        r = ss.get("_dash_anom")
        if r:
            st.write(f"**{r['n_flagged']:,}** rows flagged ({r['pct_flagged']:.2f}%) among {r['n_rows_used']:,} scanned.")
            st.dataframe(safe_df(pd.DataFrame([{"row": a["index"], "score": a["score"], **a["values"]} for a in r["top_anomalies"][:10]])),
                         use_container_width=True, hide_index=True)

    # ---------------- save / export
    st.subheader("Save & export")
    s1, s2 = st.columns(2)
    with s1, st.container(border=True):
        st.markdown("**Saved dashboards** (filters, KPIs, panels)")
        saved = json.loads(dash_file.read_text()) if dash_file.exists() else {}
        nm = st.text_input("Name", key="_dash_name")
        if st.button("Save current") and nm.strip():
            cfg_now = {**ss.get("_cfg", {}), **{k: v for k, v in ss.items() if k.startswith("cfg_dash_")}}
            saved[nm.strip()[:60]] = {k: _ser(v) for k, v in cfg_now.items() if k.startswith("cfg_dash_")}
            dash_file.write_text(json.dumps(saved)); st.success("Saved.")
        if saved:
            choice = st.selectbox("Saved", list(saved), key="_dash_choice")
            b1, b2 = st.columns(2)
            if b1.button("Load"):
                ss["_dash_load"] = choice; st.rerun()
            if b2.button("Delete"):
                saved.pop(choice, None); dash_file.write_text(json.dumps(saved)); st.rerun()
    with s2, st.container(border=True):
        st.markdown("**Export**")
        if st.button("Prepare PDF report"):
            ss["_pdf"] = build_pdf(f"Dashboard — {name}", kpi_lines + [""] + ins, figs)
        if ss.get("_pdf"):
            st.download_button("Download PDF", ss["_pdf"], "dashboard.pdf", "application/pdf")
        st.download_button("Download filtered data (CSV)", fdf.to_csv(index=False).encode(), "filtered.csv", "text/csv")
