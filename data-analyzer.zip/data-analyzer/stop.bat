@echo off
title Data Analyzer - Stop

REM Must match BACKEND_PORT in start.bat.
set BACKEND_PORT=8010

echo Stopping Data Analyzer server...

REM Kill the backend window by its title, and free the port as backup.
taskkill /fi "WindowTitle eq Data Analyzer - Backend*" /t /f >nul 2>nul

for /f "tokens=5" %%p in ('netstat -ano ^| findstr :%BACKEND_PORT% ^| findstr LISTENING') do taskkill /pid %%p /f >nul 2>nul

echo Done.
pause
